package com.winlator;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.winlator.box64.Box64Preset;
import com.winlator.container.Container;
import com.winlator.container.ContainerManager;
import com.winlator.container.DXWrappers;
import com.winlator.container.GraphicsDrivers;
import com.winlator.container.Shortcut;
import com.winlator.inputcontrols.ControlsProfile;
import com.winlator.inputcontrols.InputControlsManager;
import com.winlator.projectk11.GameProfileManager;
import com.winlator.projectk11.SmartOptimizer;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * ProjetK11 Game Library: an original game-library UI inspired by modern PC launchers.
 * It indexes the existing .desktop shortcuts, keeps favorites/categories locally,
 * remembers recent launches and local play time, and launches the existing Winlator runner.
 */
public class ProjectK11GameCenterActivity extends AppCompatActivity {
    private static final String PREFS = "projectk11_library";
    private final ArrayList<Shortcut> games = new ArrayList<>();
    private final String[] categories = {"Tous", "Action", "Aventure", "RPG", "FPS", "Course", "Stratégie", "Autre"};
    private LinearLayout list;
    private LinearLayout recentList;
    private EditText search;
    private Spinner categoryFilter;
    private Spinner sortFilter;
    private boolean favoritesOnly;
    private String currentKey;
    private long launchStarted;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.projectk11_game_center);
        list = findViewById(R.id.k11_game_list);
        recentList = findViewById(R.id.k11_recent_list);
        search = findViewById(R.id.k11_game_search);
        categoryFilter = findViewById(R.id.k11_game_category);
        sortFilter = findViewById(R.id.k11_game_sort);

        categoryFilter.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, categories));
        String[] sorts = {"Récents", "Nom A → Z", "Nom Z → A", "Favoris"};
        sortFilter.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, sorts));

        findViewById(R.id.k11_game_favorites).setOnClickListener(v -> {
            favoritesOnly = !favoritesOnly;
            ((Button) v).setText(favoritesOnly ? "★ Favoris actifs" : "☆ Favoris");
            render();
        });
        findViewById(R.id.k11_game_refresh).setOnClickListener(v -> loadGames());
        findViewById(R.id.k11_game_close).setOnClickListener(v -> finish());
        search.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int before, int count) { render(); }
            public void afterTextChanged(android.text.Editable e) {}
        });
        categoryFilter.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(android.widget.AdapterView<?> p) {}
            public void onItemSelected(android.widget.AdapterView<?> p, View v, int pos, long id) { render(); }
        });
        sortFilter.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(android.widget.AdapterView<?> p) {}
            public void onItemSelected(android.widget.AdapterView<?> p, View v, int pos, long id) { render(); }
        });
        loadGames();
    }

    @Override protected void onResume() {
        super.onResume();
        if (currentKey != null && launchStarted > 0) {
            long elapsed = Math.max(0, (System.currentTimeMillis() - launchStarted) / 1000L);
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putLong("time_" + currentKey, getPlayTime(currentKey) + elapsed)
                    .apply();
            currentKey = null;
            launchStarted = 0;
        }
        if (list != null) loadGames();
    }

    private void loadGames() {
        games.clear();
        ContainerManager manager = new ContainerManager(this);
        for (Container c : manager.getContainers()) scan(c, new File(c.getUserDir(), "Desktop"), 0);
        render();
    }

    private void scan(Container c, File dir, int depth) {
        if (depth > 4 || dir == null || !dir.isDirectory()) return;
        File[] files = dir.listFiles();
        if (files == null) return;
        for (File f : files) {
            if (f.isDirectory()) scan(c, f, depth + 1);
            else if (f.getName().endsWith(".desktop")) games.add(new Shortcut(c, f));
        }
    }

    private void render() {
        String q = search == null ? "" : search.getText().toString().trim().toLowerCase(Locale.US);
        String cat = categoryFilter == null ? "Tous" : String.valueOf(categoryFilter.getSelectedItem());
        ArrayList<Shortcut> filtered = new ArrayList<>();
        for (Shortcut s : games) {
            if (!q.isEmpty() && !s.name.toLowerCase(Locale.US).contains(q)
                    && !s.container.getName().toLowerCase(Locale.US).contains(q)) continue;
            if (favoritesOnly && !isFavorite(s)) continue;
            if (!"Tous".equals(cat) && !getCategory(s).equals(cat)) continue;
            filtered.add(s);
        }
        final String sort = sortFilter == null ? "Récents" : String.valueOf(sortFilter.getSelectedItem());
        Collections.sort(filtered, (a, b) -> {
            if ("Nom A → Z".equals(sort)) return a.name.compareToIgnoreCase(b.name);
            if ("Nom Z → A".equals(sort)) return b.name.compareToIgnoreCase(a.name);
            if ("Favoris".equals(sort)) {
                int fav = Boolean.compare(isFavorite(b), isFavorite(a));
                if (fav != 0) return fav;
            }
            return Long.compare(getLastPlayed(b), getLastPlayed(a));
        });

        renderRecent();
        list.removeAllViews();
        int shown = 0;
        for (Shortcut s : filtered) {
            shown++;
            list.addView(createGameCard(s));
        }
        TextView count = findViewById(R.id.k11_game_count);
        count.setText(shown + " jeu(x) • " + games.size() + " installé(s)");
        if (shown == 0) {
            TextView empty = new TextView(this);
            empty.setText(games.isEmpty()
                    ? "Aucun jeu installé. Utilise « Installer un jeu / logiciel PC » pour ajouter un .exe/.msi."
                    : "Aucun résultat pour ces filtres.");
            empty.setTextColor(Color.LTGRAY);
            empty.setTextSize(17);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(24, 50, 24, 50);
            list.addView(empty, new LinearLayout.LayoutParams(-1, -2));
        }
    }

    private void renderRecent() {
        recentList.removeAllViews();
        ArrayList<Shortcut> recent = new ArrayList<>(games);
        Collections.sort(recent, (a, b) -> Long.compare(getLastPlayed(b), getLastPlayed(a)));
        int added = 0;
        for (Shortcut s : recent) {
            if (getLastPlayed(s) <= 0) continue;
            recentList.addView(createRecentCard(s));
            if (++added >= 5) break;
        }
        if (added == 0) {
            TextView t = new TextView(this);
            t.setText("Tes jeux récemment lancés apparaîtront ici");
            t.setTextColor(0xFFB9C1CE); t.setTextSize(14); t.setPadding(8, 8, 8, 8);
            recentList.addView(t);
        }
    }

    private View createRecentCard(Shortcut s) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(8, 8, 8, 8);
        card.setBackground(roundBg(0xFF1B2030, 0xFF34405A, 12));
        ImageView icon = new ImageView(this);
        if (s.icon != null) icon.setImageBitmap(s.icon);
        else icon.setImageResource(com.winlator.R.drawable.logo);
        icon.setScaleType(ImageView.ScaleType.CENTER_CROP);
        card.addView(icon, new LinearLayout.LayoutParams(86, 60));
        TextView title = new TextView(this);
        title.setText(s.name);
        title.setTextColor(Color.WHITE); title.setTextSize(12); title.setGravity(Gravity.CENTER);
        card.addView(title, new LinearLayout.LayoutParams(100, 38));
        card.setOnClickListener(v -> launch(s));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(108, 112);
        lp.setMargins(0, 0, 10, 0);
        card.setLayoutParams(lp);
        return card;
    }

    private View createGameCard(Shortcut s) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(12, 12, 12, 12);
        card.setBackground(roundBg(0xFF181D29, 0xFF303A52, 14));

        ImageView icon = new ImageView(this);
        if (s.icon != null) icon.setImageBitmap(s.icon);
        else icon.setImageResource(com.winlator.R.drawable.logo);
        icon.setScaleType(ImageView.ScaleType.CENTER_CROP);
        card.addView(icon, new LinearLayout.LayoutParams(88, 88));

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(14, 0, 8, 0);
        TextView title = new TextView(this);
        title.setText(s.name);
        title.setTextColor(Color.WHITE); title.setTextSize(18); title.setTypeface(null, android.graphics.Typeface.BOLD);
        info.addView(title, new LinearLayout.LayoutParams(-1, -2));
        TextView meta = new TextView(this);
        meta.setText(getCategory(s) + "  •  " + s.container.getName() + "\n" + formatTime(getPlayTime(s)) + " jouées");
        meta.setTextColor(0xFFB9C1CE); meta.setTextSize(13);
        info.addView(meta, new LinearLayout.LayoutParams(-1, -2));
        card.addView(info, new LinearLayout.LayoutParams(0, -2, 1));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.VERTICAL);
        Button favorite = new Button(this);
        favorite.setText(isFavorite(s) ? "★" : "☆");
        favorite.setTextSize(20);
        favorite.setOnClickListener(v -> { toggleFavorite(s); render(); });
        actions.addView(favorite, new LinearLayout.LayoutParams(58, 48));
        Button play = new Button(this);
        play.setText("Jouer");
        play.setOnClickListener(v -> launch(s));
        actions.addView(play, new LinearLayout.LayoutParams(90, 50));
        Button profile = new Button(this);
        profile.setText("Profil");
        profile.setOnClickListener(v -> editProfile(s));
        actions.addView(profile, new LinearLayout.LayoutParams(90, 50));
        card.addView(actions);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, 10);
        card.setLayoutParams(lp);
        return card;
    }

    private GradientDrawable roundBg(int fill, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill); d.setCornerRadius(radius); d.setStroke(1, stroke);
        return d;
    }

    private void launch(Shortcut s) {
        currentKey = gameKey(s);
        launchStarted = System.currentTimeMillis();
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putLong("last_" + currentKey, launchStarted).apply();
        Intent i = new Intent(this, XServerDisplayActivity.class);
        i.putExtra("container_id", s.container.id);
        i.putExtra("shortcut_path", s.file.getPath());
        GameProfileManager.markLaunched(this, s);
        startActivity(i);
    }

    private void editProfile(Shortcut s) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL); box.setPadding(20, 4, 20, 4);

        InputControlsManager icm = new InputControlsManager(this);
        ArrayList<ControlsProfile> profiles = icm.getProfiles(true);
        ArrayList<String> profileNames = new ArrayList<>();
        profileNames.add("Automatique");
        for (ControlsProfile p : profiles) profileNames.add(p.getName());
        Spinner controls = spinner(profileNames);
        String currentControls = s.getExtra("controls_profile", "");
        int selected = 0;
        for (int i = 0; i < profiles.size(); i++) if (profiles.get(i).getName().equals(currentControls)) selected = i + 1;
        controls.setSelection(selected);
        box.addView(label("Contrôles")); box.addView(controls);

        ArrayList<String> presets = new ArrayList<>();
        presets.add("Performance"); presets.add("Équilibré"); presets.add("Stabilité"); presets.add("Conservateur");
        Spinner box64 = spinner(presets);
        box64.setSelection(presetIndex(s.getExtra("box64Preset", s.container.getBox64Preset())));
        box.addView(label("Box64")); box.addView(box64);

        ArrayList<String> drivers = new ArrayList<>();
        drivers.add("Turnip + Gladio"); drivers.add("Vortek + Gladio"); drivers.add("Vortek + VirGL");
        Spinner graphics = spinner(drivers);
        graphics.setSelection(graphicsIndex(s.getExtra("graphicsDriver", s.container.getGraphicsDriver())));
        box.addView(label("Graphismes")); box.addView(graphics);

        ArrayList<String> dx = new ArrayList<>(); dx.add("DXVK"); dx.add("WineD3D");
        Spinner dxw = spinner(dx);
        dxw.setSelection("wined3d".equals(s.getExtra("dxwrapper", s.container.getDXWrapper())) ? 1 : 0);
        box.addView(label("DirectX")); box.addView(dxw);

        ArrayList<String> sizes = new ArrayList<>(); sizes.add("1280x720"); sizes.add("1600x900"); sizes.add("1920x1080");
        Spinner size = spinner(sizes);
        String currentSize = s.getExtra("screenSize", s.container.getScreenSize());
        for (int i = 0; i < sizes.size(); i++) if (sizes.get(i).equals(currentSize)) size.setSelection(i);
        box.addView(label("Résolution")); box.addView(size);

        ArrayList<String> cats = new ArrayList<>();
        for (int i = 1; i < categories.length; i++) cats.add(categories[i]);
        Spinner category = spinner(cats);
        String currentCategory = getCategory(s);
        for (int i = 0; i < cats.size(); i++) if (cats.get(i).equals(currentCategory)) category.setSelection(i);
        box.addView(label("Collection")); box.addView(category);

        new AlertDialog.Builder(this).setTitle("Profil — " + s.name).setView(box)
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Enregistrer", (d, w) -> {
                String cp = controls.getSelectedItemPosition() == 0 ? "" : profiles.get(controls.getSelectedItemPosition()-1).getName();
                s.putExtra("controls_profile", cp.isEmpty() ? null : cp);
                s.putExtra("box64Preset", presetId((String) box64.getSelectedItem()));
                s.putExtra("graphicsDriver", graphicsId(graphics.getSelectedItemPosition()));
                s.putExtra("dxwrapper", dxw.getSelectedItemPosition() == 1 ? DXWrappers.WINED3D : DXWrappers.DXVK);
                s.putExtra("screenSize", (String) size.getSelectedItem());
                s.putExtra("library_category", (String) category.getSelectedItem());
                s.saveData();
                Toast.makeText(this, "Profil et collection enregistrés", Toast.LENGTH_SHORT).show();
                render();
            }).show();
    }

    private TextView label(String t) { TextView v = new TextView(this); v.setText(t); v.setTextColor(0xFFE8EAF0); v.setTextSize(14); v.setPadding(0, 10, 0, 4); return v; }
    private Spinner spinner(List<String> items) { Spinner s = new Spinner(this); s.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items)); return s; }
    private int presetIndex(String id) { if (Box64Preset.PERFORMANCE.equals(id)) return 0; if (Box64Preset.STABILITY.equals(id)) return 2; if (Box64Preset.CONSERVATIVE.equals(id)) return 3; return 1; }
    private String presetId(String name) { if (name.startsWith("Performance")) return Box64Preset.PERFORMANCE; if (name.startsWith("Stabilité")) return Box64Preset.STABILITY; if (name.startsWith("Conservateur")) return Box64Preset.CONSERVATIVE; return Box64Preset.INTERMEDIATE; }
    private int graphicsIndex(String id) { if (id != null && id.startsWith(GraphicsDrivers.TURNIP)) return 0; if (id != null && id.contains(GraphicsDrivers.VIRGL)) return 2; return 1; }
    private String graphicsId(int i) { if (i == 0) return GraphicsDrivers.TURNIP+","+GraphicsDrivers.GLADIO; if (i == 2) return GraphicsDrivers.VORTEK+","+GraphicsDrivers.VIRGL; return GraphicsDrivers.VORTEK+","+GraphicsDrivers.GLADIO; }

    private String gameKey(Shortcut s) { return Integer.toHexString((s.container.id + "|" + s.file.getPath()).hashCode()); }
    private boolean isFavorite(Shortcut s) { return getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean("fav_" + gameKey(s), false); }
    private void toggleFavorite(Shortcut s) { String k = gameKey(s); getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("fav_" + k, !isFavorite(s)).apply(); }
    private long getLastPlayed(Shortcut s) { return getLastPlayed(gameKey(s)); }
    private long getLastPlayed(String k) { return getSharedPreferences(PREFS, MODE_PRIVATE).getLong("last_" + k, 0); }
    private long getPlayTime(Shortcut s) { return getPlayTime(gameKey(s)); }
    private long getPlayTime(String k) { return getSharedPreferences(PREFS, MODE_PRIVATE).getLong("time_" + k, 0); }
    private String getCategory(Shortcut s) { String c = s.getExtra("library_category", "Autre"); return c.isEmpty() ? "Autre" : c; }
    private String formatTime(long seconds) {
        long h = seconds / 3600; long m = (seconds % 3600) / 60;
        return h > 0 ? h + " h " + m + " min" : m + " min";
    }
}
