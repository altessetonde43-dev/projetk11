# ProjetK11

ProjetK11 est une interface Android de type bureau Windows construite sur la base open-source Winlator. Le projet conserve les composants et mécanismes du moteur sous-jacent tout en refaisant l'expérience utilisateur.

## APK léger + runtime à la demande
L'APK ne contient plus les gros fichiers runtime compressés. Au premier lancement, **ProjetK11 — Composants** demande de télécharger ou d'importer `ProjetK11-runtime-v1.zip`, puis l'installe dans l'espace privé de l'application.

Le runtime contient notamment le RootFS, les composants graphiques et les wrappers nécessaires au fonctionnement complet. Le gestionnaire permet aussi de conserver une URL de distribution pour les futures mises à jour.

### Important
Le projet fournit le mécanisme de téléchargement, de vérification minimale et d'installation du runtime, mais il ne publie pas lui-même un serveur de fichiers. Il faut héberger `ProjetK11-runtime-v1.zip` et renseigner son URL dans l'écran **Composants / Téléchargements**, ou importer le ZIP localement.

Les composants optionnels Winlator (Box64, Turnip, DXVK, VKD3D, WineD3D) restent également compatibles avec le gestionnaire natif de composants.
