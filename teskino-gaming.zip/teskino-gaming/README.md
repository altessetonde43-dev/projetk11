# Teskino Gaming – réseau social gaming (Expo + Firebase)

Recherche d'équipe, clips, communautés par jeu avec salon de discussion, amis, messages privés,
notifications, niveaux/XP et classement, photos, signalement et blocage.

## 1. Firebase (gratuit, ~5 min)
1. console.firebase.google.com > Ajouter un projet.
2. Authentication > Sign-in method > **E-mail/Mot de passe**.
3. Firestore Database > Créer une base > Règles > colle `firestore.rules` > Publier.
4. Paramètres du projet > Tes applications > icône Web `</>` > copie la config dans `src/firebase.js`.
   (Tant que la config n'est pas remplie, l'app affiche un écran « Dernière étape ».)

## 2. Lancer
    npm install
    npx expo install --fix
    npx expo start        # scanne le QR avec Expo Go

## 3. Compiler APK / IPA
    npm i -g eas-cli && eas login
    eas init
    eas build -p android --profile preview      # APK installable
    eas build -p ios --profile production       # compte Apple Developer requis

## 4. Notifications push hors-app (optionnel)
Nécessite `eas init` (fait ci-dessus) et le plan Firebase Blaze (paiement à l'usage, quota gratuit).
    npm i -g firebase-tools && firebase login
    cd functions && npm install && cd ..
    firebase deploy --only functions

Sur Android, le push demande aussi des identifiants FCM : `eas credentials` (voir la doc Expo « Push notifications setup »).

## Publication sur les stores
Déjà inclus : signalement, blocage, suppression de compte, mot de passe oublié, conditions à l'inscription.
Il te faudra en plus une politique de confidentialité (URL) et, pour Apple, un compte développeur.
Les signalements arrivent dans la collection `reports` de Firestore (à consulter dans la console).

## Limites connues
- Photos compressées et stockées dans Firestore (évite Firebase Storage, payant).
- Le classement lit les 200 premiers comptes : à remplacer par une requête triée quand la base grossit.
