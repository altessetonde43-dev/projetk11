# Teskino Gaming – réseau social gaming (Expo + Firebase)

Recherche d'équipe, clips, communautés par jeu avec salon, amis, messages privés (non lus + « Vu »),
notifications, niveaux/XP et classement, photos, signalement, blocage, modération.

## 1. Firebase (plan Blaze requis pour Storage et Functions)
Le plan Blaze est « paiement à l'usage » avec un quota gratuit large : une carte est demandée, mais un petit projet reste à 0 €.
1. console.firebase.google.com > Ajouter un projet, puis passer au plan **Blaze**.
2. Authentication > Sign-in method > **E-mail/Mot de passe**.
3. Firestore Database > Créer une base. Storage > Commencer.
4. Paramètres du projet > Tes applications > icône Web `</>` > copie la config dans `src/firebase.js`.
   (Tant que ce n'est pas fait, l'app affiche un écran « Dernière étape ».)
5. Déployer règles, index et fonctions :

       npm i -g firebase-tools && firebase login && firebase use --add
       cd functions && npm install && cd ..
       firebase deploy --only firestore,storage,functions

## 2. Lancer
    npm install
    npx expo install --fix
    npx expo start        # scanne le QR avec Expo Go

## 3. Compiler APK / IPA
    npm i -g eas-cli && eas login && eas init
    eas build -p android --profile preview      # APK installable
    eas build -p ios --profile production       # compte Apple Developer requis

## 4. Devenir administrateur (modération)
Dans Firestore, crée la collection `admins` avec un document dont l'ID est **ton UID**
(visible dans Authentication > Utilisateurs). Ton profil affiche alors le bouton « Modération »
(signalements, suppression, bannissement) et « Bannir » sur les autres profils.

## Coach IA (assistant dans l'app)
Icône étincelles en haut du fil. La clé API reste sur le serveur (Cloud Function `aiChat`), jamais dans l'app.
1. Crée une clé sur console.anthropic.com (le service est payant à l'usage ; le modèle par défaut est le plus économique).
2. Enregistre-la : `firebase functions:secrets:set ANTHROPIC_API_KEY`
3. Déploie : `firebase deploy --only functions`
Réglages dans `functions/index.js` : `AI_MODEL`, `AI_DAILY_LIMIT` (30 messages/joueur/jour), `AI_SYSTEM` (personnalité et règles).
Pour limiter les coûts, surveille l'usage dans la console Anthropic et fixe un plafond de dépenses.

## À compléter avant de publier
- **Textes légaux** : remplace `[NOM DE L'ÉDITEUR]` et `[E-MAIL DE CONTACT]` dans `src/legalText.js` (affiché dans l'app)
  et dans `legal/conditions-et-confidentialite.txt` (à héberger sur une page web : les stores demandent une URL). Fais relire par un juriste.
- **Âge minimum** : 15 ans (`src/config.js` + `firestore.rules`). Seule l'année de naissance est stockée.
- **E-mail vérifié** : obligatoire pour publier, commenter, écrire, demander un ami (Authentication > Modèles : personnalise le mail en français).
- **Modération des images** (optionnelle) : active l'API « Cloud Vision » dans Google Cloud ; les images LIKELY adultes/violentes sont masquées automatiquement.

## Ce qui est sécurisé côté serveur
- **XP** : uniquement écrit par les Cloud Functions (plafond de 200 XP/jour, 1 XP par like et par publication).
  Sans les fonctions déployées, l'XP reste à 0.
- **Amis, likes, groupes** : les règles Firestore interdisent de modifier les données d'un autre joueur.
- **Anti-spam** : 1 publication / 10 s, 1 commentaire / 3 s, 1 demande d'ami / 20 s, notifications dédoublonnées, textes limités en taille.
- **Suppression de compte** : la fonction `cleanupUser` efface aussi commentaires, messages, notifications, photos Storage et appartenances aux groupes.
- **Photos** : envoyées dans Storage en 2 tailles (miniature + complète).

## Notifications push hors-app (optionnel)
Ajoute des identifiants FCM avec `eas credentials` (Android). Les fonctions les envoient déjà.

## Publication sur les stores
Inclus : signalement, blocage, bannissement, suppression de compte, mot de passe oublié, conditions à l'inscription.
Il te faut en plus une politique de confidentialité (URL) et, pour Apple, un compte développeur.
