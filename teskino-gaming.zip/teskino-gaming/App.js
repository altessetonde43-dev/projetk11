import React, { useEffect, useState } from 'react';
import { View, ActivityIndicator, Pressable, Text, ScrollView, Image } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import { NavigationContainer, DarkTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { onAuthStateChanged } from 'firebase/auth';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { auth, db, isConfigured } from './src/firebase';
import { registerForPush } from './src/push';
import AuthScreen from './src/AuthScreen';
import VerifyScreen from './src/VerifyScreen';
import OfflineBanner from './src/OfflineBanner';
import { Feed, Communities, CreateGroup, Community } from './src/screens/Communities';
import Comments from './src/screens/Comments';
import People from './src/screens/People';
import UserProfile from './src/screens/Profile';
import Notifications from './src/screens/Notifications';
import { Chats, Chat } from './src/screens/Chats';
import Admin from './src/screens/Admin';
import AIChat from './src/screens/AIChat';
import { chatUnread } from './src/data';
import { C } from './src/ui';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();
const header = { headerStyle: { backgroundColor: C.bg }, headerTintColor: C.text, headerTitleStyle: { fontWeight: '800' } };
const ICONS = { Fil: 'home', Groupes: 'game-controller', Amis: 'people', Notifs: 'notifications', Profil: 'person' };

function Tabs() {
  const [unread, setUnread] = useState(0);
  const [unreadChats, setUnreadChats] = useState(false);
  useEffect(() => onSnapshot(query(collection(db, 'notifications'), where('to', '==', auth.currentUser.uid), where('read', '==', false)),
    (sn) => setUnread(sn.size), () => {}), []);
  useEffect(() => {
    const me = auth.currentUser.uid;
    return onSnapshot(query(collection(db, 'chats'), where('members', 'array-contains', me)),
      (sn) => setUnreadChats(sn.docs.some((d) => chatUnread(d.data(), me))), () => {});
  }, []);
  return (
    <Tab.Navigator screenOptions={({ route }) => ({
      ...header,
      tabBarStyle: { backgroundColor: C.card, borderTopColor: C.line },
      tabBarActiveTintColor: C.accent, tabBarInactiveTintColor: C.dim,
      tabBarLabelStyle: { fontSize: 12, fontWeight: '700' },
      tabBarIcon: ({ color, size, focused }) => <Ionicons name={focused ? ICONS[route.name] : `${ICONS[route.name]}-outline`} size={size} color={color} />,
    })}>
      <Tab.Screen name="Fil" component={Feed} options={({ navigation }) => ({
        title: 'Teskino Gaming',
        headerRight: () => (
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <Pressable onPress={() => navigation.navigate('AIChat')} style={{ paddingHorizontal: 8 }}>
            <Ionicons name="sparkles-outline" size={24} color={C.accent} />
          </Pressable>
          <Pressable onPress={() => navigation.navigate('Chats')} style={{ paddingHorizontal: 16 }}>
            <Ionicons name="chatbubbles-outline" size={24} color={C.accent} />
            {unreadChats && <View style={{ position: 'absolute', top: -2, right: 12, width: 10, height: 10, borderRadius: 5, backgroundColor: C.accent }} />}
          </Pressable>
          </View>),
      })} />
      <Tab.Screen name="Groupes" component={Communities} />
      <Tab.Screen name="Amis" component={People} />
      <Tab.Screen name="Notifs" component={Notifications} options={{ tabBarBadge: unread || undefined }} />
      <Tab.Screen name="Profil" component={UserProfile} />
    </Tab.Navigator>
  );
}

function Setup() {
  return (
    <ScrollView style={{ flex: 1, backgroundColor: C.bg }} contentContainerStyle={{ padding: 24, paddingTop: 80, gap: 12 }}>
      <Text style={{ color: C.accent, fontSize: 30, fontWeight: '900' }}>Dernière étape</Text>
      <Text style={{ color: C.text, fontSize: 16, lineHeight: 24 }}>
        Connecte l'app à ton projet Firebase :{'\n\n'}
        1. Crée un projet sur console.firebase.google.com{'\n'}
        2. Authentication : active « E-mail/Mot de passe »{'\n'}
        3. Firestore : crée la base et colle le fichier firestore.rules{'\n'}
        4. Colle ta config Web dans src/firebase.js{'\n'}
        5. Relance l'app
      </Text>
    </ScrollView>
  );
}

export default function App() {
  const [user, setUser] = useState(undefined);
  const [verified, setVerified] = useState(false);
  useEffect(() => (isConfigured ? onAuthStateChanged(auth, (u) => { setUser(u); setVerified(!!u?.emailVerified); }) : undefined), []);
  useEffect(() => { if (user && verified) registerForPush(); }, [user?.uid, verified]);
  if (!isConfigured) return <Setup />;
  return (
    <SafeAreaProvider>
      <NavigationContainer theme={{ ...DarkTheme, colors: { ...DarkTheme.colors, background: C.bg, card: C.bg, text: C.text } }}>
        <StatusBar style="light" />
        {user === undefined ? (
          <View style={{ flex: 1, backgroundColor: '#0b0b0c', alignItems: 'center', justifyContent: 'center', gap: 20 }}>
            <Image source={require('./assets/loading-logo.png')} style={{ width: '85%', aspectRatio: 1 }} resizeMode="contain" />
            <ActivityIndicator color={C.accent} size="large" />
          </View>
        ) : user && !verified ? (
          <VerifyScreen onVerified={setVerified} />
        ) : user ? (
          <Stack.Navigator screenOptions={header}>
            <Stack.Screen name="Tabs" component={Tabs} options={{ headerShown: false }} />
            <Stack.Screen name="Community" component={Community} options={{ title: '' }} />
            <Stack.Screen name="CreateGroup" component={CreateGroup} options={{ title: 'Nouvelle communauté' }} />
            <Stack.Screen name="Comments" component={Comments} options={{ title: 'Commentaires' }} />
            <Stack.Screen name="UserProfile" component={UserProfile} options={{ title: '' }} />
            <Stack.Screen name="Chats" component={Chats} options={{ title: 'Messages' }} />
            <Stack.Screen name="Chat" component={Chat} options={{ title: '' }} />
            <Stack.Screen name="Admin" component={Admin} options={{ title: 'Modération' }} />
            <Stack.Screen name="AIChat" component={AIChat} options={{ title: 'Coach IA' }} />
          </Stack.Navigator>
        ) : <AuthScreen />}
      </NavigationContainer>
      <OfflineBanner />
    </SafeAreaProvider>
  );
}
