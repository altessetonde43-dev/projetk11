// XP côté serveur (anti-triche) + notifications push. Nécessite le plan Firebase Blaze.
const { onDocumentCreated, onDocumentUpdated } = require('firebase-functions/v2/firestore');
const admin = require('firebase-admin');
admin.initializeApp();
const db = admin.firestore();
const { FieldValue } = admin.firestore;
const DAILY_CAP = 200;

async function award(uid, n) {
  if (!uid) return;
  const day = new Date().toISOString().slice(0, 10);
  const capRef = db.doc(`xpDaily/${uid}_${day}`);
  const userRef = db.doc(`users/${uid}`);
  await db.runTransaction(async (t) => {
    const [cap, user] = await Promise.all([t.get(capRef), t.get(userRef)]);
    if (!user.exists) return;
    const used = cap.exists ? cap.data().total : 0;
    const give = Math.min(n, DAILY_CAP - used);
    if (give <= 0) return;
    t.set(capRef, { total: used + give });
    t.update(userRef, { xp: FieldValue.increment(give) });
  });
}

exports.xpOnPost = onDocumentCreated('posts/{id}', (e) => award(e.data.data().uid, 10));
exports.xpOnComment = onDocumentCreated('posts/{id}/comments/{cid}', (e) => award(e.data.data().uid, 5));
exports.xpOnLike = onDocumentUpdated('posts/{id}', async (e) => {
  const before = new Set(e.data.before.data().likes || []);
  const added = (e.data.after.data().likes || []).filter((u) => !before.has(u));
  for (const uid of added) {
    try { await db.doc(`xpLog/${e.params.id}_${uid}`).create({ at: FieldValue.serverTimestamp() }); } catch { continue; }
    await award(uid, 1);
  }
});

async function push(uid, title, body) {
  const u = await db.doc(`users/${uid}`).get();
  const to = u.data()?.pushToken;
  if (!to) return;
  await fetch('https://exp.host/--/api/v2/push/send', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ to, title, body, sound: 'default' }),
  });
}
const TEXT = { like: 'a aimé ta publication', comment: 'a commenté ta publication',
  friend_request: "t'a envoyé une demande d'ami", friend_accept: "a accepté ta demande d'ami", invite: "t'invite à jouer" };

exports.onNotification = onDocumentCreated('notifications/{id}', (e) => {
  const n = e.data.data();
  return push(n.to, 'Teskino Gaming', `${n.fromName} ${TEXT[n.type] || ''}`);
});
exports.onDirectMessage = onDocumentCreated('chats/{cid}/messages/{mid}', (e) => {
  const m = e.data.data();
  const to = e.params.cid.split('_').find((x) => x !== m.uid);
  return to ? push(to, m.author || 'Nouveau message', m.text || 'Photo') : null;
});

// ---- Modération automatique des images (optionnel : activer l'API Cloud Vision sur le projet) ----
const vision = require('@google-cloud/vision');
const visionClient = new vision.ImageAnnotatorClient();
exports.moderatePostImage = onDocumentCreated('posts/{id}', async (e) => {
  const p = e.data.data();
  if (!p.imageFull) return;
  try {
    const [r] = await visionClient.safeSearchDetection(p.imageFull);
    const a = r.safeSearchAnnotation || {};
    const bad = ['LIKELY', 'VERY_LIKELY'];
    if (bad.includes(a.adult) || bad.includes(a.violence) || a.racy === 'VERY_LIKELY') await e.data.ref.update({ hidden: true });
  } catch (err) { console.error('moderation', err.message); }
});

// ---- Nettoyage complet quand un compte est supprimé ----
const functionsV1 = require('firebase-functions/v1');
exports.cleanupUser = functionsV1.auth.user().onDelete(async (user) => {
  const uid = user.uid;
  const delAll = async (q) => { const sn = await q.get(); await Promise.all(sn.docs.map((d) => d.ref.delete())); };
  const posts = await db.collection('posts').where('uid', '==', uid).get();
  await Promise.all(posts.docs.map((d) => db.recursiveDelete(d.ref)));
  await Promise.all([
    delAll(db.collectionGroup('comments').where('uid', '==', uid)),
    delAll(db.collectionGroup('messages').where('uid', '==', uid)),
    delAll(db.collection('notifications').where('to', '==', uid)),
    delAll(db.collection('notifications').where('from', '==', uid)),
    delAll(db.collection('friendRequests').where('from', '==', uid)),
    delAll(db.collection('friendRequests').where('to', '==', uid)),
  ]);
  const groups = await db.collection('groups').where('members', 'array-contains', uid).get();
  await Promise.all(groups.docs.map((g) => g.ref.update({ members: FieldValue.arrayRemove(uid) })));
  const friends = await db.collection(`users/${uid}/friends`).get();
  await Promise.all(friends.docs.map((d) => db.doc(`users/${d.id}/friends/${uid}`).delete()));
  await db.recursiveDelete(db.doc(`users/${uid}`));
  await admin.storage().bucket().deleteFiles({ prefix: `users/${uid}/` }).catch(() => {});
});

// ---- Coach IA : la clé API reste côté serveur (secret Firebase), jamais dans l'app ----
const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { defineSecret } = require('firebase-functions/params');
const ANTHROPIC_API_KEY = defineSecret('ANTHROPIC_API_KEY');
const AI_MODEL = 'claude-haiku-4-5-20251001'; // rapide et économique ; remplace par 'claude-sonnet-5-5' pour de meilleures réponses
const AI_DAILY_LIMIT = 30; // messages par joueur et par jour
const AI_SYSTEM = `Tu es le Coach IA de Teskino Gaming, une application de communauté gaming. Tu réponds en français, de façon chaleureuse, claire et courte (l'écran est un téléphone).
Tu aides sur : conseils et astuces de jeu, choix de jeux, builds et stratégies, matériel et réglages, rédaction d'annonces de recherche d'équipe, idées de noms de clan ou de pseudo, organisation de sessions, bonne ambiance dans la communauté.
Réponds en texte simple, sans Markdown (pas d'étoiles, de dièses ni de tableaux) ; pour une liste, utilise des tirets.
Les utilisateurs ont 15 ans ou plus : pas de contenu sexuel, pas d'incitation à la violence, à la haine, aux paris d'argent ou aux arnaques, pas d'aide pour tricher ou pirater des comptes. Refuse poliment et propose une alternative.
Si quelqu'un semble en détresse, réponds avec bienveillance et encourage-le à parler à un proche ou à un professionnel (en France : 3114, numéro national de prévention du suicide).
Si tu ne sais pas ou si une information peut avoir changé (patchs, versions, prix), dis-le franchement. Ne prétends pas être humain.`;

exports.aiChat = onCall({ secrets: [ANTHROPIC_API_KEY], timeoutSeconds: 60, maxInstances: 10 }, async (req) => {
  if (!req.auth) throw new HttpsError('unauthenticated', 'Connecte-toi pour utiliser le Coach IA.');
  if (!req.auth.token.email_verified) throw new HttpsError('failed-precondition', 'Confirme ton e-mail pour utiliser le Coach IA.');
  const user = await db.doc(`users/${req.auth.uid}`).get();
  if (!user.exists || user.data().banned) throw new HttpsError('permission-denied', 'Accès refusé.');

  const raw = Array.isArray(req.data?.messages) ? req.data.messages.slice(-20) : [];
  const messages = raw
    .filter((m) => (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string' && m.content.trim())
    .map((m) => ({ role: m.role, content: m.content.slice(0, 2000) }));
  while (messages.length && messages[0].role !== 'user') messages.shift();
  if (!messages.length || messages[messages.length - 1].role !== 'user') throw new HttpsError('invalid-argument', 'Message invalide.');

  const ref = db.doc(`aiUsage/${req.auth.uid}_${new Date().toISOString().slice(0, 10)}`);
  await db.runTransaction(async (t) => {
    const s = await t.get(ref);
    const n = s.exists ? s.data().count : 0;
    if (n >= AI_DAILY_LIMIT) throw new HttpsError('resource-exhausted', `Tu as atteint la limite de ${AI_DAILY_LIMIT} messages par jour. Reviens demain !`);
    t.set(ref, { count: n + 1 });
  });

  const refund = () => ref.update({ count: FieldValue.increment(-1) }).catch(() => {});
  let r;
  try {
    r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-api-key': ANTHROPIC_API_KEY.value(), 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model: AI_MODEL, max_tokens: 700, system: AI_SYSTEM, messages }),
    });
  } catch (e) { await refund(); throw new HttpsError('unavailable', 'Le Coach IA est indisponible pour le moment.'); }
  if (!r.ok) {
    console.error('anthropic', r.status, await r.text());
    await refund();
    throw new HttpsError('unavailable', 'Le Coach IA est indisponible pour le moment. Réessaie dans un instant.');
  }
  const j = await r.json();
  const reply = (j.content || []).filter((b) => b.type === 'text').map((b) => b.text).join('\n').trim();
  return { reply: reply || "Je n'ai pas de réponse pour l'instant, reformule ta question." };
});
