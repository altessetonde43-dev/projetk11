import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';
import { auth, db } from './firebase';

const cache = new Map();
export function getUser(uid) {
  if (!cache.has(uid)) {
    cache.set(uid, getDoc(doc(db, 'users', uid)).then((d) => {
      if (!d.exists()) { cache.delete(uid); return null; }
      return { id: d.id, ...d.data() };
    }).catch(() => { cache.delete(uid); return null; }));
  }
  return cache.get(uid);
}
const subs = new Set();
export const onUserChange = (fn) => { subs.add(fn); return () => subs.delete(fn); };
export const clearUser = (uid) => { cache.delete(uid); subs.forEach((f) => f(uid)); };

const admins = new Map();
export const isAdmin = () => {
  const uid = auth.currentUser.uid;
  if (!admins.has(uid)) admins.set(uid, getDoc(doc(db, 'admins', uid)).then((d) => d.exists()).catch(() => false));
  return admins.get(uid);
};

// Identifiant déterministe : un même like/commentaire/demande ne notifie qu'une fois (pas de spam possible).
export function notify(to, type, extra = {}) {
  const me = auth.currentUser;
  if (!to || to === me.uid) return;
  const day = type === 'invite' ? `_${new Date().toISOString().slice(0, 10)}` : '';
  const id = `${type}_${me.uid}_${extra.postId || to}${day}`;
  return setDoc(doc(db, 'notifications', id), {
    to, from: me.uid, fromName: me.displayName || 'Joueur', type, read: false, createdAt: serverTimestamp(), ...extra,
  }).catch(() => {});
}
export const friendlyError = (e) => e?.code === 'permission-denied'
  ? 'Action refusée. Vérifie que ton e-mail est confirmé, ou attends quelques secondes avant de recommencer.'
  : e?.message || 'Erreur inconnue.';
export const chatId = (a, b) => [a, b].sort().join('_');

export const chatUnread = (c, me) =>
  !!c.lastSender && c.lastSender !== me && (!c.reads?.[me] || (c.updatedAt && c.reads[me].seconds < c.updatedAt.seconds));
