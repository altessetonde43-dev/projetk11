import React, { useState } from 'react';
import { View, Text, ScrollView, KeyboardAvoidingView, Platform, Image, Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, sendPasswordResetEmail, sendEmailVerification, updateProfile, deleteUser } from 'firebase/auth';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { auth, db } from './firebase';
import { MIN_AGE } from './config';
import LegalModal from './LegalModal';
import { Btn, Field, s, C } from './ui';

const MESSAGES = {
  'auth/invalid-email': 'Adresse e-mail invalide.',
  'auth/email-already-in-use': 'Cet e-mail est déjà utilisé.',
  'auth/weak-password': 'Mot de passe trop court (6 caractères minimum).',
  'auth/invalid-credential': 'E-mail ou mot de passe incorrect.',
  'auth/network-request-failed': 'Pas de connexion internet.',
  'auth/too-many-requests': 'Trop de tentatives. Réessaie dans quelques minutes.',
};

function ageFrom(d, m, y) {
  const now = new Date();
  let a = now.getFullYear() - y;
  if (now.getMonth() + 1 < m || (now.getMonth() + 1 === m && now.getDate() < d)) a--;
  return a;
}

export default function AuthScreen() {
  const [signup, setSignup] = useState(false);
  const [name, setName] = useState(''); const [email, setEmail] = useState(''); const [pass, setPass] = useState('');
  const [dd, setDd] = useState(''); const [mm, setMm] = useState(''); const [yy, setYy] = useState('');
  const [accepted, setAccepted] = useState(false); const [legal, setLegal] = useState(false);
  const [err, setErr] = useState(''); const [info, setInfo] = useState(''); const [busy, setBusy] = useState(false);

  const submit = async () => {
    setErr(''); setInfo('');
    if (busy) return;
    try {
      if (signup) {
        const d = +dd, m = +mm, y = +yy;
        if (name.trim().length < 3 || name.trim().length > 24) return setErr('Pseudo : entre 3 et 24 caractères.');
        if (!(d >= 1 && d <= 31 && m >= 1 && m <= 12 && y >= 1900 && y <= new Date().getFullYear())) return setErr('Date de naissance invalide (JJ / MM / AAAA).');
        if (ageFrom(d, m, y) < MIN_AGE) return setErr(`Tu dois avoir au moins ${MIN_AGE} ans pour t'inscrire.`);
        if (!accepted) return setErr('Accepte les conditions pour continuer.');
        setBusy(true);
        const { user } = await createUserWithEmailAndPassword(auth, email.trim(), pass);
        try {
          await updateProfile(user, { displayName: name.trim() });
          await setDoc(doc(db, 'users', user.uid), {
            name: name.trim(), nameLower: name.trim().toLowerCase(), birthYear: y, consentAt: serverTimestamp(),
            bio: '', photo: null, blocked: [], xp: 0, gamerTag: '', games: '', platforms: [], createdAt: serverTimestamp(),
          });
          await sendEmailVerification(user);
        } catch (e) { await deleteUser(user).catch(() => {}); throw e; }
        await auth.currentUser.reload();
      } else {
        setBusy(true);
        await signInWithEmailAndPassword(auth, email.trim(), pass);
      }
    } catch (e) { setErr(MESSAGES[e.code] || e.message); }
    setBusy(false);
  };
  const reset = async () => {
    setErr(''); setInfo('');
    if (!email.trim()) return setErr('Entre ton e-mail puis appuie sur « Mot de passe oublié ».');
    try { await sendPasswordResetEmail(auth, email.trim()); setInfo('E-mail de réinitialisation envoyé.'); }
    catch (e) { setErr(MESSAGES[e.code] || e.message); }
  };

  return (
    <KeyboardAvoidingView style={s.screen} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={{ padding: 24, flexGrow: 1, justifyContent: 'center', gap: 12 }} keyboardShouldPersistTaps="handled">
        <Image source={require('../assets/logo.jpg')} style={{ width: '100%', aspectRatio: 3 / 2 }} resizeMode="contain" />
        <Text style={[s.dim, { marginBottom: 12 }]}>Trouve ton équipe, partage tes clips, monte en niveau.</Text>
        {signup && <Field placeholder="Pseudo" value={name} onChangeText={setName} />}
        <Field placeholder="E-mail" keyboardType="email-address" value={email} onChangeText={setEmail} />
        <Field placeholder="Mot de passe" secureTextEntry value={pass} onChangeText={setPass} />
        {signup && (<>
          <Text style={s.dim}>Date de naissance (âge minimum : {MIN_AGE} ans)</Text>
          <View style={s.row}>
            <Field style={s.flex} placeholder="JJ" keyboardType="number-pad" maxLength={2} value={dd} onChangeText={setDd} />
            <Field style={s.flex} placeholder="MM" keyboardType="number-pad" maxLength={2} value={mm} onChangeText={setMm} />
            <Field style={{ flex: 2 }} placeholder="AAAA" keyboardType="number-pad" maxLength={4} value={yy} onChangeText={setYy} />
          </View>
          <Pressable style={s.row} onPress={() => setAccepted(!accepted)}>
            <Ionicons name={accepted ? 'checkbox' : 'square-outline'} size={24} color={accepted ? C.accent : C.dim} />
            <Text style={[s.dim, s.flex]}>J'accepte les conditions d'utilisation et la politique de confidentialité.</Text>
          </Pressable>
          <Pressable onPress={() => setLegal(true)}><Text style={{ color: C.accent, fontWeight: '700' }}>Lire les conditions</Text></Pressable>
        </>)}
        {!!err && <Text style={s.error}>{err}</Text>}
        {!!info && <Text style={{ color: C.accent }}>{info}</Text>}
        <Btn title={busy ? 'Patiente…' : signup ? 'Créer mon compte' : 'Se connecter'} onPress={submit} />
        {!signup && <Btn variant="ghost" title="Mot de passe oublié ?" onPress={reset} />}
        <Btn variant="ghost" title={signup ? "J'ai déjà un compte" : 'Nouveau ? Créer un compte'} onPress={() => { setSignup(!signup); setErr(''); setInfo(''); }} />
      </ScrollView>
      <LegalModal visible={legal} onClose={() => setLegal(false)} />
    </KeyboardAvoidingView>
  );
}
