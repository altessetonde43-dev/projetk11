import React, { useEffect, useState } from 'react';
import { View, Text } from 'react-native';
import NetInfo from '@react-native-community/netinfo';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { C } from './ui';

export default function OfflineBanner() {
  const [off, setOff] = useState(false);
  const insets = useSafeAreaInsets();
  useEffect(() => NetInfo.addEventListener((st) => setOff(st.isConnected === false || st.isInternetReachable === false)), []);
  if (!off) return null;
  return (
    <View pointerEvents="none" style={{ position: 'absolute', top: insets.top, left: 0, right: 0, zIndex: 99, backgroundColor: C.accent, paddingVertical: 4, alignItems: 'center' }}>
      <Text style={{ color: '#fff', fontWeight: '800', fontSize: 12 }}>Hors ligne – reconnexion en cours…</Text>
    </View>
  );
}
