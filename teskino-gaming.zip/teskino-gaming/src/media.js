import * as ImagePicker from 'expo-image-picker';
import * as IM from 'expo-image-manipulator';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { storage, auth } from './firebase';

const resize = (uri, width, compress) =>
  IM.manipulateAsync(uri, [{ resize: { width } }], { compress, format: IM.SaveFormat.JPEG });

// Choisit une photo et la réduit (uri locale). L'envoi se fait plus tard avec uploadPhoto / uploadAvatar.
export async function pickLocal(width = 1280) {
  const r = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 1 });
  if (r.canceled) return null;
  return (await resize(r.assets[0].uri, width, 0.7)).uri;
}

async function put(uri, path) {
  const blob = await (await fetch(uri)).blob();
  const r = ref(storage, path);
  await uploadBytes(r, blob, { contentType: 'image/jpeg' });
  return getDownloadURL(r);
}

// Envoie l'image en 2 tailles : miniature (fil) et complète (visionneuse).
export async function uploadPhoto(localUri, folder) {
  const base = `users/${auth.currentUser.uid}/${folder}/${Date.now()}`;
  const thumb = await resize(localUri, 480, 0.6);
  const [imageFull, image] = await Promise.all([put(localUri, `${base}_full.jpg`), put(thumb.uri, `${base}_thumb.jpg`)]);
  return { image, imageFull };
}

export async function uploadAvatar(localUri) {
  const small = await resize(localUri, 300, 0.7);
  return put(small.uri, `users/${auth.currentUser.uid}/avatar/${Date.now()}.jpg`);
}

export const uploadErrorMessage = (e) =>
  e?.code === 'storage/unauthorized' || e?.code === 'storage/unknown' || e?.code === 'storage/bucket-not-found'
    ? "L'envoi de photo a échoué. Vérifie que Firebase Storage est activé et que storage.rules est publié."
    : e?.message || "L'envoi de photo a échoué.";
