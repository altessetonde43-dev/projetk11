// Âge minimum pour s'inscrire (15 ans = majorité numérique en France). Si tu changes cette valeur, change aussi `>= 15` dans firestore.rules.
export const MIN_AGE = 15;
