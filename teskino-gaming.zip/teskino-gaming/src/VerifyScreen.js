import React, { useState } from 'react';
import { View, Text } from 'react-native';
import { sendEmailVerification, signOut } from 'firebase/auth';
import { auth } from './firebase';
import { Btn, s, C } from './ui';

export default function VerifyScreen({ onVerified }) {
  const [msg, setMsg] = useState('');
  const check = async () => {
    setMsg('');
    try {
      await auth.currentUser.reload();
      await auth.currentUser.getIdToken(true);
      if (auth.currentUser.emailVerified) onVerified(true);
      else setMsg("Ton e-mail n'est pas encore confirmé. Ouvre le lien reçu, puis réessaie.");
    } catch (e) { setMsg(e.message); }
  };
  const resend = async () => {
    try { await sendEmailVerification(auth.currentUser); setMsg('E-mail renvoyé. Regarde aussi tes courriers indésirables.'); }
    catch (e) { setMsg(e.code === 'auth/too-many-requests' ? 'Patiente quelques minutes avant de renvoyer.' : e.message); }
  };
  return (
    <View style={[s.screen, { padding: 24, justifyContent: 'center', gap: 14 }]}>
      <Text style={{ color: C.accent, fontSize: 26, fontWeight: '900' }}>Confirme ton e-mail</Text>
      <Text style={{ color: C.text, fontSize: 16, lineHeight: 24 }}>
        Nous avons envoyé un lien de confirmation à {auth.currentUser.email}. Ouvre-le, puis reviens ici.
        Regarde aussi dans tes courriers indésirables.
      </Text>
      {!!msg && <Text style={{ color: C.accent }}>{msg}</Text>}
      <Btn title="J'ai confirmé mon e-mail" onPress={check} />
      <Btn variant="ghost" title="Renvoyer l'e-mail" onPress={resend} />
      <Btn variant="ghost" title="Se déconnecter" onPress={() => signOut(auth)} />
    </View>
  );
}
