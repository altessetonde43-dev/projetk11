import { useEffect, useState } from 'react';
import { Alert } from 'react-native';
import { collection, query, where, onSnapshot, doc, deleteDoc, writeBatch, serverTimestamp } from 'firebase/firestore';
import { auth, db } from './firebase';
import { notify, friendlyError } from './data';
import { Btn } from './ui';

export function useRelations() {
  const me = auth.currentUser.uid;
  const [st, setSt] = useState({ friends: [], incoming: [], sent: [], blocked: [] });
  useEffect(() => {
    const noop = () => {};
    const a = onSnapshot(collection(db, 'users', me, 'friends'), (sn) => setSt((x) => ({ ...x, friends: sn.docs.map((d) => d.id) })), noop);
    const b = onSnapshot(doc(db, 'users', me), (d) => setSt((x) => ({ ...x, blocked: d.data()?.blocked || [] })), noop);
    const c = onSnapshot(query(collection(db, 'friendRequests'), where('to', '==', me)),
      (sn) => setSt((x) => ({ ...x, incoming: sn.docs.map((d) => ({ id: d.id, ...d.data() })) })), noop);
    const e = onSnapshot(query(collection(db, 'friendRequests'), where('from', '==', me)),
      (sn) => setSt((x) => ({ ...x, sent: sn.docs.map((d) => d.data().to) })), noop);
    return () => { a(); b(); c(); e(); };
  }, []);
  return st;
}

export const A = {
  request: async (uid) => {
    const me = auth.currentUser;
    const b = writeBatch(db);
    b.set(doc(db, 'friendRequests', `${me.uid}_${uid}`), { from: me.uid, to: uid, fromName: me.displayName || 'Joueur', createdAt: serverTimestamp() });
    b.update(doc(db, 'users', me.uid), { lastRequestAt: serverTimestamp() });
    await b.commit();
    notify(uid, 'friend_request');
  },
  cancel: (uid) => deleteDoc(doc(db, 'friendRequests', `${auth.currentUser.uid}_${uid}`)),
  decline: (r) => deleteDoc(doc(db, 'friendRequests', r.id)),
  accept: async (r) => {
    const me = auth.currentUser.uid, b = writeBatch(db);
    b.set(doc(db, 'users', me, 'friends', r.from), { createdAt: serverTimestamp() });
    b.set(doc(db, 'users', r.from, 'friends', me), { createdAt: serverTimestamp() });
    b.delete(doc(db, 'friendRequests', r.id));
    await b.commit();
    notify(r.from, 'friend_accept');
  },
  unfriend: async (uid) => {
    const me = auth.currentUser.uid, b = writeBatch(db);
    b.delete(doc(db, 'users', me, 'friends', uid));
    b.delete(doc(db, 'users', uid, 'friends', me));
    await b.commit();
  },
};

const run = (fn) => fn().catch((e) => Alert.alert('Action impossible', friendlyError(e)));

export function FriendButton({ uid, rel }) {
  const inc = rel.incoming.find((r) => r.from === uid);
  if (rel.friends.includes(uid)) return <Btn variant="ghost" title="Ami" onPress={() => Alert.alert('Retirer cet ami ?', '', [{ text: 'Annuler', style: 'cancel' }, { text: 'Retirer', style: 'destructive', onPress: () => run(() => A.unfriend(uid)) }])} />;
  if (inc) return <Btn title="Accepter" onPress={() => run(() => A.accept(inc))} />;
  if (rel.sent.includes(uid)) return <Btn variant="ghost" title="Annuler la demande" onPress={() => run(() => A.cancel(uid))} />;
  return <Btn title="Ajouter" onPress={() => run(() => A.request(uid))} />;
}
