import React from 'react';
import { Modal, View, Text, ScrollView } from 'react-native';
import { LEGAL_TEXT } from './legalText';
import { Btn, s, C } from './ui';

export default function LegalModal({ visible, onClose }) {
  return (
    <Modal visible={visible} animationType="slide" onRequestClose={onClose}>
      <View style={[s.screen, { paddingTop: 50 }]}>
        <ScrollView contentContainerStyle={{ padding: 20 }}>
          <Text style={{ color: C.text, fontSize: 14, lineHeight: 21 }}>{LEGAL_TEXT}</Text>
        </ScrollView>
        <View style={{ padding: 16 }}><Btn title="Fermer" onPress={onClose} /></View>
      </View>
    </Modal>
  );
}
