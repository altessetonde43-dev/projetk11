import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, Pressable } from 'react-native';
import { collection, query, orderBy, limit, onSnapshot, addDoc, updateDoc, doc, arrayUnion, arrayRemove, serverTimestamp } from 'firebase/firestore';
import { auth, db } from '../firebase';
import PostList from '../PostList';
import { Btn, Field, Chip, ChipRow, GAMES, s, C } from '../ui';

export const Feed = ({ navigation }) => <View style={s.screen}><PostList navigation={navigation} /></View>;

export function Communities({ navigation }) {
  const [groups, setGroups] = useState([]); const [q, setQ] = useState('');
  const uid = auth.currentUser.uid;
  useEffect(() => onSnapshot(query(collection(db, 'groups'), orderBy('createdAt', 'desc'), limit(100)),
    (snap) => setGroups(snap.docs.map((d) => ({ id: d.id, ...d.data() }))), () => {}), []);
  const toggle = (g) => updateDoc(doc(db, 'groups', g.id), { members: g.members.includes(uid) ? arrayRemove(uid) : arrayUnion(uid) });
  const shown = groups.filter((g) => `${g.name} ${g.game}`.toLowerCase().includes(q.trim().toLowerCase()));
  return (
    <View style={s.screen}>
      <FlatList data={shown} keyExtractor={(g) => g.id} contentContainerStyle={{ padding: 16, gap: 12 }} keyboardShouldPersistTaps="handled"
        ListHeaderComponent={<View style={{ gap: 10 }}>
          <Btn title="Créer une communauté" onPress={() => navigation.navigate('CreateGroup')} />
          <Field placeholder="Rechercher un jeu ou une communauté" value={q} onChangeText={setQ} />
        </View>}
        ListEmptyComponent={<Text style={[s.dim, { marginTop: 12 }]}>Aucune communauté trouvée.</Text>}
        renderItem={({ item }) => {
          const on = item.members.includes(uid);
          return (
            <Pressable style={[s.card, s.row]} onPress={() => navigation.navigate('Community', { id: item.id })}>
              <View style={s.flex}>
                <Text style={s.title}>{item.name}</Text>
                <Text style={s.dim}>{item.game} · {item.members.length} membre{item.members.length > 1 ? 's' : ''}</Text>
              </View>
              <Btn title={on ? 'Quitter' : 'Rejoindre'} variant={on ? 'ghost' : undefined} onPress={() => toggle(item)} />
            </Pressable>
          );
        }} />
    </View>
  );
}

export function CreateGroup({ navigation }) {
  const [name, setName] = useState(''); const [game, setGame] = useState(''); const [desc, setDesc] = useState('');
  const create = async () => {
    if (!name.trim() || !game.trim()) return;
    await addDoc(collection(db, 'groups'), {
      name: name.trim(), game: game.trim(), desc: desc.trim(),
      ownerId: auth.currentUser.uid, members: [auth.currentUser.uid], createdAt: serverTimestamp(),
    });
    navigation.goBack();
  };
  return (
    <View style={[s.screen, { padding: 16, gap: 12 }]}>
      <Field placeholder="Nom de la communauté" value={name} onChangeText={setName} autoCapitalize="sentences" />
      <Field placeholder="Jeu (ex : Valorant)" value={game} onChangeText={setGame} autoCapitalize="sentences" />
      <ChipRow>{GAMES.map((g) => <Chip key={g} label={g} on={game === g} onPress={() => setGame(g)} />)}</ChipRow>
      <Field placeholder="Description" value={desc} onChangeText={setDesc} multiline autoCapitalize="sentences" />
      <Btn title="Créer" onPress={create} />
    </View>
  );
}

export function Community({ route, navigation }) {
  const [g, setG] = useState(null);
  const uid = auth.currentUser.uid;
  useEffect(() => onSnapshot(doc(db, 'groups', route.params.id), (d) => {
    if (d.exists()) { setG({ id: d.id, ...d.data() }); navigation.setOptions({ title: d.data().name }); }
  }, () => {}), []);
  if (!g) return <View style={s.screen} />;
  const on = g.members.includes(uid);
  const header = (
    <View style={[s.card, { gap: 8 }]}>
      <Text style={s.dim}>{g.game} · {g.members.length} membre{g.members.length > 1 ? 's' : ''}</Text>
      {!!g.desc && <Text style={{ color: C.text }}>{g.desc}</Text>}
      {on && <Btn title="Salon de discussion" onPress={() => navigation.navigate('Chat', { groupId: g.id, name: g.name })} />}
      <Btn title={on ? 'Quitter' : 'Rejoindre'} variant={on ? 'ghost' : undefined}
        onPress={() => updateDoc(doc(db, 'groups', g.id), { members: on ? arrayRemove(uid) : arrayUnion(uid) })} />
    </View>
  );
  return <View style={s.screen}><PostList group={g} navigation={navigation} header={header} /></View>;
}
