import React, { useEffect, useState } from 'react';
import { View, Text, FlatList } from 'react-native';
import { collection, query, orderBy, limit, onSnapshot, getDoc, deleteDoc, updateDoc, doc } from 'firebase/firestore';
import { db } from '../firebase';
import { Btn, Photo, ago, s, C } from '../ui';

function ReportItem({ r }) {
  const [post, setPost] = useState(undefined);
  useEffect(() => { getDoc(doc(db, 'posts', r.postId)).then((d) => setPost(d.exists() ? { id: d.id, ...d.data() } : null)).catch(() => setPost(null)); }, [r.postId]);
  const dismiss = () => deleteDoc(doc(db, 'reports', r.id));
  const removePost = async () => { await deleteDoc(doc(db, 'posts', r.postId)); dismiss(); };
  const ban = async () => { await updateDoc(doc(db, 'users', r.reportedUid), { banned: true }); removePost(); };
  return (
    <View style={[s.card, { gap: 8 }]}>
      <Text style={s.dim}>Signalé {ago(r.createdAt)}</Text>
      {post === undefined ? <Text style={s.dim}>Chargement…</Text>
        : post === null ? <Text style={s.dim}>Publication déjà supprimée.</Text>
        : (<>
          <Text style={s.title}>{post.author}</Text>
          {!!post.text && <Text style={s.body}>{post.text}</Text>}
          {!!post.image && <Photo uri={post.image} full={post.imageFull} style={{ width: '100%', aspectRatio: 4 / 3, borderRadius: 10 }} />}
        </>)}
      {post && <Btn title="Supprimer la publication" onPress={removePost} style={{ backgroundColor: C.danger }} />}
      {post && <Btn title="Supprimer et bannir l'auteur" variant="ghost" onPress={ban} />}
      <Btn title="Ignorer le signalement" variant="ghost" onPress={dismiss} />
    </View>
  );
}

export default function Admin() {
  const [reports, setReports] = useState([]);
  useEffect(() => onSnapshot(query(collection(db, 'reports'), orderBy('createdAt', 'desc'), limit(50)),
    (sn) => setReports(sn.docs.map((d) => ({ id: d.id, ...d.data() }))), () => {}), []);
  return (
    <View style={s.screen}>
      <FlatList data={reports} keyExtractor={(r) => r.id} contentContainerStyle={{ padding: 16, gap: 12 }}
        ListEmptyComponent={<Text style={s.dim}>Aucun signalement en attente.</Text>}
        renderItem={({ item }) => <ReportItem r={item} />} />
    </View>
  );
}
