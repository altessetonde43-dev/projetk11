import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, KeyboardAvoidingView, Platform, Alert } from 'react-native';
import { useHeaderHeight } from '@react-navigation/elements';
import { collection, query, orderBy, onSnapshot, writeBatch, doc, increment, serverTimestamp } from 'firebase/firestore';
import { auth, db } from '../firebase';
import { notify, friendlyError } from '../data';
import { Btn, Field, Photo, s } from '../ui';

export default function Comments({ route }) {
  const { postId } = route.params;
  const headerH = useHeaderHeight();
  const [post, setPost] = useState(null);
  const [list, setList] = useState([]); const [text, setText] = useState('');
  useEffect(() => onSnapshot(doc(db, 'posts', postId), (d) => d.exists() && setPost({ id: d.id, ...d.data() }), () => {}), []);
  useEffect(() => onSnapshot(query(collection(db, 'posts', postId, 'comments'), orderBy('createdAt', 'asc')),
    (snap) => setList(snap.docs.map((d) => ({ id: d.id, ...d.data() }))), () => {}), []);
  const send = async () => {
    if (!text.trim() || !post) return;
    const t = text.trim(); setText('');
    try {
      const b = writeBatch(db);
      b.set(doc(collection(db, 'posts', postId, 'comments')), { uid: auth.currentUser.uid, author: auth.currentUser.displayName || 'Joueur', text: t, createdAt: serverTimestamp() });
      b.update(doc(db, 'posts', postId), { commentCount: increment(1) });
      b.update(doc(db, 'users', auth.currentUser.uid), { lastCommentAt: serverTimestamp() });
      await b.commit();
      notify(post.uid, 'comment', { postId });
    } catch (e) { setText(t); Alert.alert('Commentaire non envoyé', friendlyError(e)); }
  };
  return (
    <KeyboardAvoidingView style={s.screen} behavior={Platform.OS === 'ios' ? 'padding' : undefined} keyboardVerticalOffset={headerH}>
      <FlatList data={list} keyExtractor={(c) => c.id} contentContainerStyle={{ padding: 16, gap: 10 }}
        ListHeaderComponent={post && (
          <View style={[s.card, { marginBottom: 6 }]}>
            <Text style={s.title}>{post.author}</Text>
            {!!post.text && <Text style={s.body}>{post.text}</Text>}
            {!!post.image && <Photo uri={post.image} full={post.imageFull} style={{ width: '100%', aspectRatio: 4 / 3, borderRadius: 10, marginTop: 8 }} />}
          </View>)}
        renderItem={({ item }) => <View style={s.card}><Text style={s.title}>{item.author}</Text><Text style={s.body}>{item.text}</Text></View>} />
      <View style={[s.row, { padding: 12 }]}>
        <Field style={s.flex} placeholder="Ajouter un commentaire" value={text} onChangeText={setText} autoCapitalize="sentences" />
        <Btn title="Envoyer" onPress={send} />
      </View>
    </KeyboardAvoidingView>
  );
}
