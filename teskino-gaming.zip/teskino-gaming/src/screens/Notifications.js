import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, Pressable } from 'react-native';
import { collection, query, where, limit, onSnapshot, updateDoc, doc } from 'firebase/firestore';
import { auth, db } from '../firebase';
import { Btn, Avatar, ago, s, C } from '../ui';

const NOTIF = {
  like: 'a aimé ta publication', comment: 'a commenté ta publication',
  friend_request: "t'a envoyé une demande d'ami", friend_accept: "a accepté ta demande d'ami", invite: "t'invite à jouer",
};

export default function Notifications({ navigation }) {
  const me = auth.currentUser.uid;
  const [list, setList] = useState([]);
  useEffect(() => onSnapshot(query(collection(db, 'notifications'), where('to', '==', me), limit(60)), (sn) => {
    const l = sn.docs.map((d) => ({ id: d.id, ...d.data() }));
    l.sort((a, b) => (b.createdAt?.seconds ?? Infinity) - (a.createdAt?.seconds ?? Infinity));
    setList(l);
  }, () => {}), []);
  const open = (n) => {
    if (!n.read) updateDoc(doc(db, 'notifications', n.id), { read: true });
    if (n.postId) navigation.navigate('Comments', { postId: n.postId });
    else navigation.navigate('UserProfile', { uid: n.from });
  };
  const readAll = () => list.filter((n) => !n.read).forEach((n) => updateDoc(doc(db, 'notifications', n.id), { read: true }));
  return (
    <View style={s.screen}>
      <FlatList data={list} keyExtractor={(n) => n.id} contentContainerStyle={{ padding: 16, gap: 10 }}
        ListHeaderComponent={list.some((n) => !n.read) ? <Btn variant="ghost" title="Tout marquer comme lu" onPress={readAll} /> : null}
        ListEmptyComponent={<Text style={s.dim}>Aucune notification pour l'instant.</Text>}
        renderItem={({ item }) => (
          <Pressable style={[s.card, s.row, !item.read && { borderColor: C.accent }]} onPress={() => open(item)}>
            <Avatar uid={item.from} name={item.fromName} />
            <View style={s.flex}>
              <Text style={{ color: C.text }}><Text style={s.title}>{item.fromName}</Text> {NOTIF[item.type]}{item.game ? ` (${item.game})` : ''}</Text>
              <Text style={s.dim}>{ago(item.createdAt)}</Text>
            </View>
          </Pressable>)} />
    </View>
  );
}
