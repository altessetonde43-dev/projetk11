import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, Pressable } from 'react-native';
import { collection, query, where, orderBy, limit, onSnapshot } from 'firebase/firestore';
import { auth, db } from '../firebase';
import { useRelations, A, FriendButton } from '../friends';
import { Btn, Field, Avatar, AvatarView, Chip, ChipRow, levelOf, rankOf, s, C } from '../ui';

export default function People({ navigation }) {
  const me = auth.currentUser.uid;
  const rel = useRelations();
  const [users, setUsers] = useState([]); const [q, setQ] = useState(''); const [mode, setMode] = useState('players');
  useEffect(() => {
    const ql = q.trim().toLowerCase(), col = collection(db, 'users');
    const qy = mode === 'rank' ? query(col, orderBy('xp', 'desc'), limit(50))
      : ql ? query(col, where('nameLower', '>=', ql), where('nameLower', '<=', ql + '\uf8ff'), limit(30))
      : query(col, orderBy('createdAt', 'desc'), limit(30));
    return onSnapshot(qy, (sn) => setUsers(sn.docs.map((d) => ({ id: d.id, ...d.data() }))), () => {});
  }, [mode, q]);
  const shown = mode === 'players' ? users.filter((u) => u.id !== me && !rel.blocked.includes(u.id)) : users;
  return (
    <View style={s.screen}>
      <FlatList data={shown} keyExtractor={(u) => u.id} contentContainerStyle={{ padding: 16, gap: 10 }} keyboardShouldPersistTaps="handled"
        ListHeaderComponent={
          <View style={{ gap: 10, marginBottom: 4 }}>
            <ChipRow>
              <Chip label="Joueurs" on={mode === 'players'} onPress={() => setMode('players')} />
              <Chip label="Classement" on={mode === 'rank'} onPress={() => setMode('rank')} />
            </ChipRow>
            {mode === 'players' && rel.incoming.map((r) => (
              <View key={r.id} style={[s.card, s.row]}>
                <Avatar uid={r.from} name={r.fromName} />
                <Text style={[s.title, s.flex]}>{r.fromName}</Text>
                <Btn title="Accepter" onPress={() => A.accept(r)} />
                <Btn variant="ghost" title="Refuser" onPress={() => A.decline(r)} />
              </View>))}
            {mode === 'players' && <Field placeholder="Rechercher un joueur (début du pseudo)" value={q} onChangeText={setQ} />}
          </View>}
        ListEmptyComponent={<Text style={s.dim}>Aucun joueur trouvé.</Text>}
        renderItem={({ item, index }) => {
          const lvl = levelOf(item.xp || 0);
          return (
            <Pressable style={[s.card, s.row]} onPress={() => navigation.navigate('UserProfile', { uid: item.id })}>
              {mode === 'rank' && <Text style={{ color: C.accent, fontWeight: '900', width: 30 }}>#{index + 1}</Text>}
              <AvatarView photo={item.photo} name={item.name} size={44} />
              <View style={s.flex}>
                <Text style={s.title}>{item.name}</Text>
                <Text style={s.dim}>Niv. {lvl} · {rankOf(lvl)}{mode === 'rank' ? ` · ${item.xp || 0} XP` : ''}</Text>
              </View>
              {mode === 'players' && <FriendButton uid={item.id} rel={rel} />}
            </Pressable>);
        }} />
    </View>
  );
}
