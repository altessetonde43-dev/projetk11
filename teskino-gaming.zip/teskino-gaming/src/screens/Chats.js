import React, { useEffect, useRef, useState } from 'react';
import { View, Text, FlatList, Pressable, Alert, KeyboardAvoidingView, Platform } from 'react-native';
import { collection, query, where, orderBy, onSnapshot, addDoc, setDoc, updateDoc, doc, serverTimestamp } from 'firebase/firestore';
import { useHeaderHeight } from '@react-navigation/elements';
import { auth, db } from '../firebase';
import { chatId, chatUnread, friendlyError } from '../data';
import { pickLocal, uploadPhoto, uploadErrorMessage } from '../media';
import { Btn, Field, Photo, Avatar, s, C } from '../ui';

export function Chats({ navigation }) {
  const me = auth.currentUser.uid;
  const [list, setList] = useState([]);
  useEffect(() => onSnapshot(query(collection(db, 'chats'), where('members', 'array-contains', me)), (sn) => {
    const l = sn.docs.map((d) => ({ id: d.id, ...d.data() }));
    l.sort((a, b) => (b.updatedAt?.seconds ?? Infinity) - (a.updatedAt?.seconds ?? Infinity));
    setList(l);
  }, () => {}), []);
  return (
    <View style={s.screen}>
      <FlatList data={list} keyExtractor={(c) => c.id} contentContainerStyle={{ padding: 16, gap: 10 }}
        ListEmptyComponent={<Text style={s.dim}>Aucune conversation. Ouvre le profil d'un joueur pour lui écrire.</Text>}
        renderItem={({ item }) => {
          const other = item.members.find((x) => x !== me); const name = item.names?.[other] || 'Joueur';
          const unread = chatUnread(item, me);
          return (
            <Pressable style={[s.card, s.row, unread && { borderColor: C.accent }]} onPress={() => navigation.navigate('Chat', { uid: other, name })}>
              <Avatar uid={other} name={name} size={44} />
              <View style={s.flex}>
                <Text style={s.title}>{name}</Text>
                <Text style={[s.dim, unread && { color: C.text, fontWeight: '700' }]} numberOfLines={1}>{item.lastMessage}</Text>
              </View>
              {unread && <View style={{ width: 10, height: 10, borderRadius: 5, backgroundColor: C.accent }} />}
            </Pressable>);
        }} />
    </View>
  );
}

export function Chat({ route, navigation }) {
  const { uid, name, groupId } = route.params; const me = auth.currentUser;
  const headerH = useHeaderHeight();
  const id = groupId ? null : chatId(me.uid, uid);
  const path = groupId ? ['groups', groupId, 'messages'] : ['chats', id, 'messages'];
  const [msgs, setMsgs] = useState([]); const [text, setText] = useState('');
  const [otherRead, setOtherRead] = useState(null); const ref = useRef();
  useEffect(() => { navigation.setOptions({ title: name }); }, []);
  useEffect(() => onSnapshot(query(collection(db, ...path), orderBy('createdAt', 'asc')),
    (sn) => setMsgs(sn.docs.map((d) => ({ id: d.id, ...d.data() }))), () => {}), [groupId, id]);
  useEffect(() => (groupId ? undefined : onSnapshot(doc(db, 'chats', id),
    (d) => setOtherRead(d.data()?.reads?.[uid] || null), () => {})), [id]);
  useEffect(() => {
    if (groupId || !msgs.length || msgs[msgs.length - 1].uid === me.uid) return;
    updateDoc(doc(db, 'chats', id), { [`reads.${me.uid}`]: serverTimestamp() }).catch(() => {});
  }, [msgs.length]);

  const send = async (imgs) => {
    const t = imgs ? '' : text.trim();
    if (!t && !imgs) return;
    setText('');
    try {
      if (!groupId) {
        await setDoc(doc(db, 'chats', id), {
          members: [me.uid, uid], names: { [me.uid]: me.displayName || 'Joueur', [uid]: name },
          lastMessage: t || 'Photo', lastSender: me.uid, updatedAt: serverTimestamp(), reads: { [me.uid]: serverTimestamp() },
        }, { merge: true });
      }
      await addDoc(collection(db, ...path), {
        uid: me.uid, author: me.displayName || 'Joueur', text: t,
        image: imgs?.image || null, imageFull: imgs?.imageFull || null, createdAt: serverTimestamp(),
      });
    } catch (e) { Alert.alert('Message non envoyé', friendlyError(e)); }
  };
  const sendPhoto = async () => {
    const l = await pickLocal(1000); if (!l) return;
    try { send(await uploadPhoto(l, 'chat')); } catch (e) { Alert.alert('Photo non envoyée', uploadErrorMessage(e)); }
  };
  const lastMine = [...msgs].reverse().find((m) => m.uid === me.uid);

  return (
    <KeyboardAvoidingView style={s.screen} behavior={Platform.OS === 'ios' ? 'padding' : undefined} keyboardVerticalOffset={headerH}>
      <FlatList ref={ref} data={msgs} keyExtractor={(m) => m.id} contentContainerStyle={{ padding: 16, gap: 8 }}
        onContentSizeChange={() => ref.current?.scrollToEnd({ animated: false })}
        renderItem={({ item }) => {
          const mine = item.uid === me.uid;
          const seen = !groupId && mine && lastMine?.id === item.id && otherRead && item.createdAt && otherRead.seconds >= item.createdAt.seconds;
          return (
            <View style={{ alignSelf: mine ? 'flex-end' : 'flex-start', maxWidth: '80%' }}>
              <View style={{ backgroundColor: mine ? C.violet : C.card, borderRadius: 14, padding: 10, gap: 6 }}>
                {!!groupId && !mine && <Text style={{ color: C.accent, fontWeight: '800', fontSize: 12 }}>{item.author}</Text>}
                {!!item.image && <Photo uri={item.image} full={item.imageFull} style={{ width: 220, height: 165, borderRadius: 10 }} />}
                {!!item.text && <Text style={{ color: C.text, fontSize: 15 }}>{item.text}</Text>}
              </View>
              {seen && <Text style={[s.dim, { alignSelf: 'flex-end', marginTop: 2 }]}>Vu</Text>}
            </View>);
        }} />
      <View style={[s.row, { padding: 12 }]}>
        <Btn variant="ghost" title="Photo" onPress={sendPhoto} />
        <Field style={s.flex} placeholder="Écrire un message" value={text} onChangeText={setText} autoCapitalize="sentences" />
        <Btn title="Envoyer" onPress={() => send()} />
      </View>
    </KeyboardAvoidingView>
  );
}
