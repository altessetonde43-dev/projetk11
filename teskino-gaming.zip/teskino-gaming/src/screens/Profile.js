import React, { useEffect, useRef, useState } from 'react';
import { View, Text, Pressable, Alert } from 'react-native';
import { collection, query, where, onSnapshot, updateDoc, deleteDoc, getDocs, doc } from 'firebase/firestore';
import { signOut, deleteUser, EmailAuthProvider, reauthenticateWithCredential } from 'firebase/auth';
import { auth, db } from '../firebase';
import { notify, clearUser, getUser, isAdmin } from '../data';
import { pickLocal, uploadAvatar, uploadErrorMessage } from '../media';
import { useRelations, FriendButton } from '../friends';
import PostList from '../PostList';
import LegalModal from '../LegalModal';
import { Btn, Field, AvatarView, Chip, ChipRow, XpBar, PLATFORMS, levelOf, rankOf, s, C } from '../ui';

export default function UserProfile({ route, navigation }) {
  const me = auth.currentUser;
  const uid = route.params?.uid ?? me.uid; const isMe = uid === me.uid;
  const rel = useRelations();
  const [u, setU] = useState(null); const [nf, setNf] = useState(0); const [admin, setAdmin] = useState(false);
  const [f, setF] = useState({ bio: '', gamerTag: '', games: '', platforms: [] });
  const init = useRef(false);
  const [legal, setLegal] = useState(false);
  const [delOpen, setDelOpen] = useState(false); const [pwd, setPwd] = useState('');
  useEffect(() => { isAdmin().then(setAdmin); }, []);
  useEffect(() => onSnapshot(collection(db, 'users', uid, 'friends'), (sn) => setNf(sn.size), () => {}), [uid]);
  useEffect(() => onSnapshot(doc(db, 'users', uid), (d) => {
    if (!d.exists()) return;
    const x = d.data(); setU({ id: d.id, ...x });
    if (!init.current) { init.current = true; setF({ bio: x.bio || '', gamerTag: x.gamerTag || '', games: x.games || '', platforms: x.platforms || [] }); }
    if (!isMe) navigation.setOptions({ title: x.name });
  }, () => {}), [uid]);
  if (!u) return <View style={s.screen} />;
  const lvl = levelOf(u.xp || 0);
  const changePhoto = async () => {
    const l = await pickLocal(600); if (!l) return;
    try { const url = await uploadAvatar(l); await updateDoc(doc(db, 'users', me.uid), { photo: url }); clearUser(me.uid); }
    catch (e) { Alert.alert('Photo non enregistrée', uploadErrorMessage(e)); }
  };
  const togglePlat = (p) => setF((x) => ({ ...x, platforms: x.platforms.includes(p) ? x.platforms.filter((y) => y !== p) : [...x.platforms, p] }));
  const deleteAccount = async () => {
    try {
      await reauthenticateWithCredential(me, EmailAuthProvider.credential(me.email, pwd));
      const mine = await getDocs(query(collection(db, 'posts'), where('uid', '==', me.uid)));
      await Promise.all(mine.docs.map((d) => deleteDoc(d.ref)));
      const fr = await getDocs(collection(db, 'users', me.uid, 'friends'));
      await Promise.all(fr.docs.flatMap((d) => [deleteDoc(d.ref), deleteDoc(doc(db, 'users', d.id, 'friends', me.uid))]));
      await deleteDoc(doc(db, 'users', me.uid));
      await deleteUser(me);
    } catch (e) {
      Alert.alert('Suppression impossible', e.code === 'auth/invalid-credential' || e.code === 'auth/wrong-password' ? 'Mot de passe incorrect.' : e.message);
    }
  };
  const invite = async () => {
    const mine = await getUser(me.uid);
    notify(uid, 'invite', { game: (mine?.games || '').split(',')[0].trim() || null });
    Alert.alert('Invitation envoyée', `${u.name} va recevoir ta demande pour jouer ensemble.`);
  };
  const head = (
    <View style={[s.card, { gap: 10, alignItems: 'center' }]}>
      <AvatarView photo={u.photo} name={u.name} size={96} />
      <Text style={{ color: C.text, fontSize: 22, fontWeight: '800' }}>{u.name}{u.banned ? ' (banni)' : ''}</Text>
      <Text style={{ color: C.accent, fontWeight: '800' }}>Niv. {lvl} · {rankOf(lvl)}</Text>
      <XpBar xp={u.xp || 0} />
      <Text style={s.dim}>{u.xp || 0} XP · {nf} ami(s)</Text>
      {isMe ? (<>
        <Btn variant="ghost" title="Changer la photo" onPress={changePhoto} />
        <Field style={{ alignSelf: 'stretch' }} placeholder="Pseudo de jeu (Discord, Steam, PSN…)" value={f.gamerTag} onChangeText={(v) => setF({ ...f, gamerTag: v })} />
        <Field style={{ alignSelf: 'stretch' }} placeholder="Jeux préférés (ex : Valorant, Zelda)" value={f.games} onChangeText={(v) => setF({ ...f, games: v })} autoCapitalize="sentences" />
        <ChipRow>{PLATFORMS.map((p) => <Chip key={p} label={p} on={f.platforms.includes(p)} onPress={() => togglePlat(p)} />)}</ChipRow>
        <Field style={{ alignSelf: 'stretch' }} placeholder="Ta bio" value={f.bio} onChangeText={(v) => setF({ ...f, bio: v })} autoCapitalize="sentences" />
        <Btn title="Enregistrer mon profil" onPress={() => updateDoc(doc(db, 'users', me.uid), f).then(() => clearUser(me.uid))} />
        {admin && <Btn variant="ghost" title="Modération" onPress={() => navigation.navigate('Admin')} />}
        <Btn variant="ghost" title="Conditions et confidentialité" onPress={() => setLegal(true)} />
        <Btn variant="ghost" title="Se déconnecter" onPress={() => signOut(auth)} />
        {delOpen ? (<>
          <Field style={{ alignSelf: 'stretch' }} placeholder="Mot de passe pour confirmer" secureTextEntry value={pwd} onChangeText={setPwd} />
          <Btn title="Supprimer définitivement mon compte" onPress={deleteAccount} style={{ backgroundColor: C.danger }} />
        </>) : <Pressable onPress={() => setDelOpen(true)}><Text style={{ color: C.danger }}>Supprimer mon compte</Text></Pressable>}
      </>) : (<>
        {!!u.gamerTag && <Text style={{ color: C.text, fontWeight: '700' }}>{u.gamerTag}</Text>}
        {!!u.platforms?.length && <Text style={s.dim}>{u.platforms.join(' · ')}</Text>}
        {!!u.games && <Text style={{ color: C.text }}>Joue à : {u.games}</Text>}
        {!!u.bio && <Text style={{ color: C.text }}>{u.bio}</Text>}
        <FriendButton uid={uid} rel={rel} />
        <Btn title="Inviter à jouer" onPress={invite} />
        <Btn variant="ghost" title="Envoyer un message" onPress={() => navigation.navigate('Chat', { uid, name: u.name })} />
        <Btn variant="ghost" title={rel.blocked.includes(uid) ? 'Débloquer' : 'Bloquer ce joueur'}
          onPress={() => updateDoc(doc(db, 'users', me.uid), { blocked: rel.blocked.includes(uid) ? arrayRemoveSafe(rel.blocked, uid) : [...rel.blocked, uid] })} />
        {admin && <Btn variant="ghost" title={u.banned ? 'Débannir' : 'Bannir ce joueur'} onPress={() => updateDoc(doc(db, 'users', uid), { banned: !u.banned })} />}
      </>)}
    </View>
  );
  return <View style={s.screen}><PostList uid={uid} navigation={navigation} header={head} /><LegalModal visible={legal} onClose={() => setLegal(false)} /></View>;
}
const arrayRemoveSafe = (arr, x) => arr.filter((y) => y !== x);
