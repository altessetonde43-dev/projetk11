import React, { useEffect, useRef, useState } from 'react';
import { View, Text, FlatList, Pressable, KeyboardAvoidingView, Platform, ActivityIndicator, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useHeaderHeight } from '@react-navigation/elements';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { httpsCallable } from 'firebase/functions';
import { auth, functions } from '../firebase';
import { Btn, Field, Chip, ChipRow, s, C } from '../ui';

const SUGGESTIONS = [
  'Recommande-moi un jeu selon mes goûts',
  'Écris une annonce pour trouver 2 joueurs',
  'Des astuces pour progresser en FPS',
  'Idées de nom de clan',
];
const storeKey = () => `aiChat:${auth.currentUser.uid}`;

export default function AIChat({ navigation }) {
  const headerH = useHeaderHeight();
  const [msgs, setMsgs] = useState([]); const [text, setText] = useState(''); const [busy, setBusy] = useState(false);
  const loaded = useRef(false); const list = useRef();

  useEffect(() => {
    AsyncStorage.getItem(storeKey()).then((v) => { if (v) setMsgs(JSON.parse(v)); }).catch(() => {}).finally(() => { loaded.current = true; });
  }, []);
  useEffect(() => { if (loaded.current) AsyncStorage.setItem(storeKey(), JSON.stringify(msgs.slice(-40))).catch(() => {}); }, [msgs]);
  useEffect(() => {
    navigation.setOptions({
      headerRight: () => msgs.length ? (
        <Pressable style={{ paddingHorizontal: 16 }} onPress={() => Alert.alert('Nouvelle conversation ?', "L'historique sera effacé.", [
          { text: 'Annuler', style: 'cancel' }, { text: 'Effacer', style: 'destructive', onPress: () => setMsgs([]) }])}>
          <Ionicons name="trash-outline" size={22} color={C.dim} />
        </Pressable>) : null,
    });
  }, [msgs.length]);

  const send = async (t) => {
    const content = (t ?? text).trim();
    if (!content || busy) return;
    setText('');
    const next = [...msgs, { role: 'user', content }];
    setMsgs(next); setBusy(true);
    try {
      const payload = next.filter((m) => !m.error).slice(-20).map(({ role, content: c }) => ({ role, content: c }));
      const res = await httpsCallable(functions, 'aiChat')({ messages: payload });
      setMsgs([...next, { role: 'assistant', content: res.data.reply }]);
    } catch (e) {
      const known = e?.code?.startsWith('functions/') && e.message && e.message !== 'internal' && e.code !== 'functions/unavailable';
      setMsgs([...next, { role: 'assistant', error: true, content: known ? e.message : "Le Coach IA ne répond pas. Vérifie ta connexion et réessaie." }]);
    }
    setBusy(false);
  };

  return (
    <KeyboardAvoidingView style={s.screen} behavior={Platform.OS === 'ios' ? 'padding' : undefined} keyboardVerticalOffset={headerH}>
      <FlatList ref={list} data={msgs} keyExtractor={(_, i) => String(i)} contentContainerStyle={{ padding: 16, gap: 10, flexGrow: 1 }}
        onContentSizeChange={() => list.current?.scrollToEnd({ animated: true })}
        ListHeaderComponent={<Text style={[s.dim, { textAlign: 'center', marginBottom: 6 }]}>Coach IA · réponses générées par une IA, elles peuvent contenir des erreurs.</Text>}
        ListEmptyComponent={
          <View style={{ gap: 12, marginTop: 12 }}>
            <Text style={{ color: C.text, fontSize: 18, fontWeight: '800' }}>Salut ! Je suis ton Coach IA.</Text>
            <Text style={s.dim}>Pose-moi une question sur un jeu, une stratégie, ou demande-moi de rédiger une annonce.</Text>
            <ChipRow>{SUGGESTIONS.map((q) => <Chip key={q} label={q} onPress={() => send(q)} />)}</ChipRow>
          </View>}
        ListFooterComponent={busy ? <View style={[s.row, { marginTop: 8 }]}><ActivityIndicator color={C.accent} /><Text style={s.dim}>Le Coach réfléchit…</Text></View> : null}
        renderItem={({ item }) => {
          const mine = item.role === 'user';
          return (
            <View style={{ alignSelf: mine ? 'flex-end' : 'flex-start', maxWidth: '88%', backgroundColor: mine ? C.violet : C.card,
              borderRadius: 14, padding: 12, borderWidth: item.error ? 1 : 0, borderColor: C.danger }}>
              <Text style={{ color: item.error ? C.danger : C.text, fontSize: 15, lineHeight: 21 }} selectable>{item.content}</Text>
            </View>);
        }} />
      <View style={[s.row, { padding: 12 }]}>
        <Field style={s.flex} placeholder="Demande quelque chose au Coach" value={text} onChangeText={setText} multiline maxLength={2000} autoCapitalize="sentences" />
        <Btn title="Envoyer" onPress={() => send()} />
      </View>
    </KeyboardAvoidingView>
  );
}
