# Respawn — app Android (projet source)

Application Android native (Kotlin) qui affiche l'interface Respawn dans une
WebView embarquée. Les publications et les likes sont **réellement
sauvegardés sur l'appareil** (localStorage persistant), donc l'app garde son
état après fermeture/réouverture.

## Ce que fait réellement l'app
- Fil d'actualité, composeur de post, likes : fonctionnels et persistants sur l'appareil.
- Fonctionne 100% hors-ligne (tout est embarqué dans `app/src/main/assets/index.html`).

## Ce que l'app NE fait PAS (soyons honnêtes)
- Ce n'est **pas** un vrai réseau social multi-utilisateurs : il n'y a pas de
  serveur, donc les autres "joueurs en ligne" du fil sont du contenu de
  démonstration, pas de vraies personnes. Pour un vrai réseau social il faudrait
  un backend (base de données, comptes, API) — possible à ajouter ensuite si tu veux.
- Je n'ai pas pu compiler l'APK moi-même (pas d'accès réseau/SDK Android dans
  mon environnement) : ce ZIP est le **projet source prêt à compiler**, pas un
  APK déjà généré.

## Comment obtenir l'APK (5 minutes)
1. Installe **Android Studio** (gratuit) : https://developer.android.com/studio
2. Dézippe ce projet, puis `File > Open` dans Android Studio et sélectionne le dossier `RespawnApp`.
3. Laisse Android Studio synchroniser Gradle (barre de progression en bas, ça télécharge les dépendances — connexion internet nécessaire cette fois).
4. Menu `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
5. L'APK généré se trouve dans `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfère ce fichier sur ton téléphone et installe-le (autorise "sources inconnues" si demandé).

### Alternative en ligne de commande (si tu as déjà le SDK Android + Java installés)
```
cd RespawnApp
gradle wrapper        # génère gradlew si absent
./gradlew assembleDebug
```

## Structure du projet
```
RespawnApp/
├── app/
│   ├── build.gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/respawn/app/MainActivity.kt   ← charge la WebView
│       ├── assets/index.html                       ← toute l'interface (HTML/CSS/JS)
│       └── res/                                     ← icône, thème, couleurs
├── build.gradle
└── settings.gradle
```
