// Notifications push (app fermée). Optionnel : nécessite le plan Firebase Blaze (paiement à l'usage, quota gratuit inclus).
const { onDocumentCreated } = require('firebase-functions/v2/firestore');
const admin = require('firebase-admin');
admin.initializeApp();

async function push(uid, title, body) {
  const u = await admin.firestore().doc(`users/${uid}`).get();
  const to = u.data()?.pushToken;
  if (!to) return;
  await fetch('https://exp.host/--/api/v2/push/send', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ to, title, body, sound: 'default' }),
  });
}
const TEXT = { like: 'a aimé ta publication', comment: 'a commenté ta publication',
  friend_request: "t'a envoyé une demande d'ami", friend_accept: "a accepté ta demande d'ami", invite: "t'invite à jouer" };

exports.onNotification = onDocumentCreated('notifications/{id}', (e) => {
  const n = e.data.data();
  return push(n.to, 'Teskino Gaming', `${n.fromName} ${TEXT[n.type] || ''}`);
});
exports.onDirectMessage = onDocumentCreated('chats/{cid}/messages/{mid}', (e) => {
  const m = e.data.data();
  const to = e.params.cid.split('_').find((x) => x !== m.uid);
  return to ? push(to, m.author || 'Nouveau message', m.text || 'Photo') : null;
});
