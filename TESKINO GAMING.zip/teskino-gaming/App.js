import React, { useEffect, useState } from 'react';
import { View, ActivityIndicator, Pressable, Text, ScrollView, Image } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import { NavigationContainer, DarkTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { onAuthStateChanged } from 'firebase/auth';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { auth, db, isConfigured } from './src/firebase';
import { registerForPush } from './src/push';
import AuthScreen from './src/AuthScreen';
import { Feed, Communities, CreateGroup, Community, Comments } from './src/Screens';
import { People, UserProfile, Notifications, Chats, Chat } from './src/Social';
import { C } from './src/ui';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();
const header = { headerStyle: { backgroundColor: C.bg }, headerTintColor: C.text, headerTitleStyle: { fontWeight: '800' } };
const ICONS = { Fil: 'home', Groupes: 'game-controller', Amis: 'people', Notifs: 'notifications', Profil: 'person' };

function Tabs() {
  const [unread, setUnread] = useState(0);
  useEffect(() => onSnapshot(query(collection(db, 'notifications'), where('to', '==', auth.currentUser.uid), where('read', '==', false)),
    (sn) => setUnread(sn.size), () => {}), []);
  return (
    <Tab.Navigator screenOptions={({ route }) => ({
      ...header,
      tabBarStyle: { backgroundColor: C.card, borderTopColor: C.line },
      tabBarActiveTintColor: C.accent, tabBarInactiveTintColor: C.dim,
      tabBarLabelStyle: { fontSize: 12, fontWeight: '700' },
      tabBarIcon: ({ color, size, focused }) => <Ionicons name={focused ? ICONS[route.name] : `${ICONS[route.name]}-outline`} size={size} color={color} />,
    })}>
      <Tab.Screen name="Fil" component={Feed} options={({ navigation }) => ({
        title: 'Teskino Gaming',
        headerRight: () => (
          <Pressable onPress={() => navigation.navigate('Chats')} style={{ paddingHorizontal: 16 }}>
            <Ionicons name="chatbubbles-outline" size={24} color={C.accent} />
          </Pressable>),
      })} />
      <Tab.Screen name="Groupes" component={Communities} />
      <Tab.Screen name="Amis" component={People} />
      <Tab.Screen name="Notifs" component={Notifications} options={{ tabBarBadge: unread || undefined }} />
      <Tab.Screen name="Profil" component={UserProfile} />
    </Tab.Navigator>
  );
}

function Setup() {
  return (
    <ScrollView style={{ flex: 1, backgroundColor: C.bg }} contentContainerStyle={{ padding: 24, paddingTop: 80, gap: 12 }}>
      <Text style={{ color: C.accent, fontSize: 30, fontWeight: '900' }}>Dernière étape</Text>
      <Text style={{ color: C.text, fontSize: 16, lineHeight: 24 }}>
        Connecte l'app à ton projet Firebase :{'\n\n'}
        1. Crée un projet sur console.firebase.google.com{'\n'}
        2. Authentication : active « E-mail/Mot de passe »{'\n'}
        3. Firestore : crée la base et colle le fichier firestore.rules{'\n'}
        4. Colle ta config Web dans src/firebase.js{'\n'}
        5. Relance l'app
      </Text>
    </ScrollView>
  );
}

export default function App() {
  const [user, setUser] = useState(undefined);
  const [splashDone, setSplashDone] = useState(false);
  useEffect(() => {
    const timer = setTimeout(() => setSplashDone(true), 6000);
    return () => clearTimeout(timer);
  }, []);
  useEffect(() => (isConfigured ? onAuthStateChanged(auth, setUser) : undefined), []);
  useEffect(() => { if (user) registerForPush(); }, [user?.uid]);
  if (!splashDone) {
    return (
      <SafeAreaProvider>
        <View style={{ flex: 1, backgroundColor: '#050505', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 18 }}>
          <Image source={require('./assets/intro-splash.jpg')} style={{ width: '100%', height: '76%' }} resizeMode="contain" />
          <View style={{ alignItems: 'center', gap: 10, marginTop: 8 }}>
            <ActivityIndicator size="large" color={C.accent} />
            <Text style={{ color: '#F5F3F3', fontSize: 13, fontWeight: '700', letterSpacing: 1.2 }}>CHARGEMENT DE TESKINO GAMING</Text>
          </View>
        </View>
      </SafeAreaProvider>
    );
  }
  if (!isConfigured) return <Setup />;
  return (
    <SafeAreaProvider>
      <NavigationContainer theme={{ ...DarkTheme, colors: { ...DarkTheme.colors, background: C.bg, card: C.bg, text: C.text } }}>
        <StatusBar style="light" />
        {user === undefined ? (
          <View style={{ flex: 1, backgroundColor: C.bg, justifyContent: 'center' }}><ActivityIndicator color={C.accent} /></View>
        ) : user ? (
          <Stack.Navigator screenOptions={header}>
            <Stack.Screen name="Tabs" component={Tabs} options={{ headerShown: false }} />
            <Stack.Screen name="Community" component={Community} options={{ title: '' }} />
            <Stack.Screen name="CreateGroup" component={CreateGroup} options={{ title: 'Nouvelle communauté' }} />
            <Stack.Screen name="Comments" component={Comments} options={{ title: 'Commentaires' }} />
            <Stack.Screen name="UserProfile" component={UserProfile} options={{ title: '' }} />
            <Stack.Screen name="Chats" component={Chats} options={{ title: 'Messages' }} />
            <Stack.Screen name="Chat" component={Chat} options={{ title: '' }} />
          </Stack.Navigator>
        ) : <AuthScreen />}
      </NavigationContainer>
    </SafeAreaProvider>
  );
}
