import { doc, getDoc, addDoc, collection, serverTimestamp } from 'firebase/firestore';
import { auth, db } from './firebase';

const cache = new Map();
export function getUser(uid) {
  if (!cache.has(uid)) cache.set(uid, getDoc(doc(db, 'users', uid)).then((d) => (d.exists() ? { id: d.id, ...d.data() } : null)).catch(() => null));
  return cache.get(uid);
}
export const clearUser = (uid) => cache.delete(uid);

export function notify(to, type, extra = {}) {
  const me = auth.currentUser;
  if (!to || to === me.uid) return;
  return addDoc(collection(db, 'notifications'), {
    to, from: me.uid, fromName: me.displayName || 'Joueur', type, read: false, createdAt: serverTimestamp(), ...extra,
  }).catch(() => {});
}
export const chatId = (a, b) => [a, b].sort().join('_');

import { updateDoc, increment } from 'firebase/firestore';
export const addXp = (n) => updateDoc(doc(db, 'users', auth.currentUser.uid), { xp: increment(n) }).catch(() => {});
