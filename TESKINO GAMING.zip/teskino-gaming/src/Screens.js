import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, Pressable, KeyboardAvoidingView, Platform } from 'react-native';
import { collection, query, orderBy, onSnapshot, addDoc, updateDoc, doc, arrayUnion, arrayRemove, increment, serverTimestamp } from 'firebase/firestore';
import { notify, addXp } from './data';
import { auth, db } from './firebase';
import PostList from './PostList';
import { Btn, Field, Chip, ChipRow, GAMES, Photo, s, C } from './ui';

export const Feed = ({ navigation }) => <View style={s.screen}><PostList navigation={navigation} /></View>;

export function Communities({ navigation }) {
  const [groups, setGroups] = useState([]);
  const uid = auth.currentUser.uid;
  useEffect(() => onSnapshot(query(collection(db, 'groups'), orderBy('createdAt', 'desc')),
    (snap) => setGroups(snap.docs.map((d) => ({ id: d.id, ...d.data() })))), []);
  const toggle = (g) => updateDoc(doc(db, 'groups', g.id), { members: g.members.includes(uid) ? arrayRemove(uid) : arrayUnion(uid) });
  return (
    <View style={s.screen}>
      <FlatList data={groups} keyExtractor={(g) => g.id} contentContainerStyle={{ padding: 16, gap: 12 }}
        ListHeaderComponent={<Btn title="Créer une communauté" onPress={() => navigation.navigate('CreateGroup')} />}
        ListEmptyComponent={<Text style={[s.dim, { marginTop: 12 }]}>Aucune communauté. Crée la première.</Text>}
        renderItem={({ item }) => {
          const on = item.members.includes(uid);
          return (
            <Pressable style={[s.card, s.row]} onPress={() => navigation.navigate('Community', { id: item.id })}>
              <View style={s.flex}>
                <Text style={s.title}>{item.name}</Text>
                <Text style={s.dim}>{item.game} · {item.members.length} membre{item.members.length > 1 ? 's' : ''}</Text>
              </View>
              <Btn title={on ? 'Quitter' : 'Rejoindre'} variant={on ? 'ghost' : undefined} onPress={() => toggle(item)} />
            </Pressable>
          );
        }} />
    </View>
  );
}

export function CreateGroup({ navigation }) {
  const [name, setName] = useState(''); const [game, setGame] = useState(''); const [desc, setDesc] = useState('');
  const create = async () => {
    if (!name.trim() || !game.trim()) return;
    await addDoc(collection(db, 'groups'), {
      name: name.trim(), game: game.trim(), desc: desc.trim(),
      ownerId: auth.currentUser.uid, members: [auth.currentUser.uid], createdAt: serverTimestamp(),
    });
    navigation.goBack();
  };
  return (
    <View style={[s.screen, { padding: 16, gap: 12 }]}>
      <Field placeholder="Nom de la communauté" value={name} onChangeText={setName} autoCapitalize="sentences" />
      <Field placeholder="Jeu (ex : Valorant)" value={game} onChangeText={setGame} autoCapitalize="sentences" />
      <ChipRow>{GAMES.map((g) => <Chip key={g} label={g} on={game === g} onPress={() => setGame(g)} />)}</ChipRow>
      <Field placeholder="Description" value={desc} onChangeText={setDesc} multiline autoCapitalize="sentences" />
      <Btn title="Créer" onPress={create} />
    </View>
  );
}

export function Community({ route, navigation }) {
  const [g, setG] = useState(null);
  const uid = auth.currentUser.uid;
  useEffect(() => onSnapshot(doc(db, 'groups', route.params.id), (d) => {
    if (d.exists()) { setG({ id: d.id, ...d.data() }); navigation.setOptions({ title: d.data().name }); }
  }), []);
  if (!g) return <View style={s.screen} />;
  const on = g.members.includes(uid);
  const header = (
    <View style={[s.card, { gap: 8 }]}>
      <Text style={s.dim}>{g.game} · {g.members.length} membre{g.members.length > 1 ? 's' : ''}</Text>
      {!!g.desc && <Text style={{ color: C.text }}>{g.desc}</Text>}
      {on && <Btn title="Salon de discussion" onPress={() => navigation.navigate('Chat', { groupId: g.id, name: g.name })} />}
      <Btn title={on ? 'Quitter' : 'Rejoindre'} variant={on ? 'ghost' : undefined}
        onPress={() => updateDoc(doc(db, 'groups', g.id), { members: on ? arrayRemove(uid) : arrayUnion(uid) })} />
    </View>
  );
  return <View style={s.screen}><PostList group={g} navigation={navigation} header={header} /></View>;
}

export function Comments({ route }) {
  const { postId } = route.params;
  const [post, setPost] = useState(null);
  const [list, setList] = useState([]); const [text, setText] = useState('');
  useEffect(() => onSnapshot(doc(db, 'posts', postId), (d) => d.exists() && setPost({ id: d.id, ...d.data() })), []);
  useEffect(() => onSnapshot(query(collection(db, 'posts', postId, 'comments'), orderBy('createdAt', 'asc')),
    (snap) => setList(snap.docs.map((d) => ({ id: d.id, ...d.data() })))), []);
  const send = async () => {
    if (!text.trim() || !post) return;
    const t = text.trim(); setText('');
    await addDoc(collection(db, 'posts', postId, 'comments'), { uid: auth.currentUser.uid, author: auth.currentUser.displayName || 'Joueur', text: t, createdAt: serverTimestamp() });
    await updateDoc(doc(db, 'posts', postId), { commentCount: increment(1) });
    notify(post.uid, 'comment', { postId }); addXp(5);
  };
  return (
    <KeyboardAvoidingView style={s.screen} behavior={Platform.OS === 'ios' ? 'padding' : undefined} keyboardVerticalOffset={90}>
      <FlatList data={list} keyExtractor={(c) => c.id} contentContainerStyle={{ padding: 16, gap: 10 }}
        ListHeaderComponent={post && (
          <View style={[s.card, { marginBottom: 6 }]}>
            <Text style={s.title}>{post.author}</Text>
            {!!post.text && <Text style={s.body}>{post.text}</Text>}
            {!!post.image && <Photo uri={post.image} style={{ width: '100%', aspectRatio: 4 / 3, borderRadius: 10, marginTop: 8 }} />}
          </View>)}
        renderItem={({ item }) => <View style={s.card}><Text style={s.title}>{item.author}</Text><Text style={s.body}>{item.text}</Text></View>} />
      <View style={[s.row, { padding: 12 }]}>
        <Field style={s.flex} placeholder="Ajouter un commentaire" value={text} onChangeText={setText} autoCapitalize="sentences" />
        <Btn title="Envoyer" onPress={send} />
      </View>
    </KeyboardAvoidingView>
  );
}
