import React, { useState } from 'react';
import { View, Text, ScrollView, KeyboardAvoidingView, Platform, Image } from 'react-native';
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, sendPasswordResetEmail, updateProfile } from 'firebase/auth';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { auth, db } from './firebase';
import { Btn, Field, s, C } from './ui';

const MESSAGES = {
  'auth/invalid-email': 'Adresse e-mail invalide.',
  'auth/email-already-in-use': 'Cet e-mail est déjà utilisé.',
  'auth/weak-password': 'Mot de passe trop court (6 caractères minimum).',
  'auth/invalid-credential': 'E-mail ou mot de passe incorrect.',
  'auth/network-request-failed': 'Pas de connexion internet.',
};

export default function AuthScreen() {
  const [signup, setSignup] = useState(false);
  const [name, setName] = useState(''); const [email, setEmail] = useState(''); const [pass, setPass] = useState('');
  const [err, setErr] = useState(''); const [info, setInfo] = useState('');

  const submit = async () => {
    setErr(''); setInfo('');
    try {
      if (signup) {
        if (name.trim().length < 3) return setErr('Choisis un pseudo (3 caractères minimum).');
        const { user } = await createUserWithEmailAndPassword(auth, email.trim(), pass);
        await updateProfile(user, { displayName: name.trim() });
        await setDoc(doc(db, 'users', user.uid), { name: name.trim(), bio: '', photo: null, friends: [], blocked: [], xp: 0, gamerTag: '', games: '', platforms: [], createdAt: serverTimestamp() });
        await auth.currentUser.reload();
      } else {
        await signInWithEmailAndPassword(auth, email.trim(), pass);
      }
    } catch (e) { setErr(MESSAGES[e.code] || e.message); }
  };
  const reset = async () => {
    setErr(''); setInfo('');
    if (!email.trim()) return setErr('Entre ton e-mail puis appuie sur « Mot de passe oublié ».');
    try { await sendPasswordResetEmail(auth, email.trim()); setInfo('E-mail de réinitialisation envoyé.'); }
    catch (e) { setErr(MESSAGES[e.code] || e.message); }
  };

  return (
    <KeyboardAvoidingView style={s.screen} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={{ padding: 24, flexGrow: 1, justifyContent: 'center', gap: 12 }} keyboardShouldPersistTaps="handled">
        <Image source={require('../assets/logo.jpg')} style={{ width: '100%', aspectRatio: 3 / 2 }} resizeMode="contain" />
        <Text style={[s.dim, { marginBottom: 12 }]}>Trouve ton équipe, partage tes clips, monte en niveau.</Text>
        {signup && <Field placeholder="Pseudo" value={name} onChangeText={setName} />}
        <Field placeholder="E-mail" keyboardType="email-address" value={email} onChangeText={setEmail} />
        <Field placeholder="Mot de passe" secureTextEntry value={pass} onChangeText={setPass} />
        {!!err && <Text style={s.error}>{err}</Text>}
        {!!info && <Text style={{ color: C.accent }}>{info}</Text>}
        <Btn title={signup ? 'Créer mon compte' : 'Se connecter'} onPress={submit} />
        {signup && <Text style={s.dim}>En créant un compte, tu t'engages à ne publier aucun contenu haineux, illégal ou inapproprié. Les contenus peuvent être signalés et les comptes bloqués.</Text>}
        {!signup && <Btn variant="ghost" title="Mot de passe oublié ?" onPress={reset} />}
        <Btn variant="ghost" title={signup ? "J'ai déjà un compte" : 'Nouveau ? Créer un compte'} onPress={() => { setSignup(!signup); setErr(''); setInfo(''); }} />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
