import * as ImagePicker from 'expo-image-picker';
import * as ImageManipulator from 'expo-image-manipulator';

// Choisit une photo, la réduit et la renvoie en data-URI (stockée directement dans Firestore).
export async function pickImage(width = 800, quality = 0.5) {
  const r = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 1 });
  if (r.canceled) return null;
  const out = await ImageManipulator.manipulateAsync(r.assets[0].uri, [{ resize: { width } }],
    { compress: quality, format: ImageManipulator.SaveFormat.JPEG, base64: true });
  return 'data:image/jpeg;base64,' + out.base64;
}
