import React, { useEffect, useRef, useState } from 'react';
import { View, Text, FlatList, Pressable, Alert, KeyboardAvoidingView, Platform } from 'react-native';
import { collection, query, where, limit, onSnapshot, addDoc, setDoc, updateDoc, deleteDoc, doc, arrayUnion, arrayRemove, writeBatch, orderBy, getDocs, serverTimestamp } from 'firebase/firestore';
import { signOut, deleteUser, EmailAuthProvider, reauthenticateWithCredential } from 'firebase/auth';
import { auth, db } from './firebase';
import { notify, chatId, clearUser, getUser } from './data';
import { pickImage } from './media';
import PostList from './PostList';
import { Btn, Field, Photo, Avatar, AvatarView, Chip, ChipRow, XpBar, PLATFORMS, levelOf, rankOf, ago, s, C } from './ui';

function useRelations() {
  const me = auth.currentUser.uid;
  const [st, setSt] = useState({ friends: [], incoming: [], sent: [], blocked: [] });
  useEffect(() => {
    const a = onSnapshot(doc(db, 'users', me), (d) => setSt((x) => ({ ...x, friends: d.data()?.friends || [], blocked: d.data()?.blocked || [] })));
    const b = onSnapshot(query(collection(db, 'friendRequests'), where('to', '==', me)),
      (sn) => setSt((x) => ({ ...x, incoming: sn.docs.map((d) => ({ id: d.id, ...d.data() })) })));
    const c = onSnapshot(query(collection(db, 'friendRequests'), where('from', '==', me)),
      (sn) => setSt((x) => ({ ...x, sent: sn.docs.map((d) => d.data().to) })));
    return () => { a(); b(); c(); };
  }, []);
  return st;
}

const A = {
  request: async (uid) => {
    const me = auth.currentUser;
    await setDoc(doc(db, 'friendRequests', `${me.uid}_${uid}`), { from: me.uid, to: uid, fromName: me.displayName || 'Joueur', createdAt: serverTimestamp() });
    notify(uid, 'friend_request');
  },
  cancel: (uid) => deleteDoc(doc(db, 'friendRequests', `${auth.currentUser.uid}_${uid}`)),
  decline: (r) => deleteDoc(doc(db, 'friendRequests', r.id)),
  accept: async (r) => {
    const me = auth.currentUser.uid, b = writeBatch(db);
    b.update(doc(db, 'users', me), { friends: arrayUnion(r.from) });
    b.update(doc(db, 'users', r.from), { friends: arrayUnion(me) });
    b.delete(doc(db, 'friendRequests', r.id));
    await b.commit();
    notify(r.from, 'friend_accept');
  },
  unfriend: async (uid) => {
    const me = auth.currentUser.uid, b = writeBatch(db);
    b.update(doc(db, 'users', me), { friends: arrayRemove(uid) });
    b.update(doc(db, 'users', uid), { friends: arrayRemove(me) });
    await b.commit();
  },
};

function FriendButton({ uid, rel }) {
  const inc = rel.incoming.find((r) => r.from === uid);
  if (rel.friends.includes(uid)) return <Btn variant="ghost" title="Ami" onPress={() => Alert.alert('Retirer cet ami ?', '', [{ text: 'Annuler', style: 'cancel' }, { text: 'Retirer', style: 'destructive', onPress: () => A.unfriend(uid) }])} />;
  if (inc) return <Btn title="Accepter" onPress={() => A.accept(inc)} />;
  if (rel.sent.includes(uid)) return <Btn variant="ghost" title="Annuler la demande" onPress={() => A.cancel(uid)} />;
  return <Btn title="Ajouter" onPress={() => A.request(uid)} />;
}

export function People({ navigation }) {
  const me = auth.currentUser.uid;
  const rel = useRelations();
  const [users, setUsers] = useState([]); const [q, setQ] = useState(''); const [mode, setMode] = useState('players');
  useEffect(() => onSnapshot(query(collection(db, 'users'), limit(200)),
    (sn) => setUsers(sn.docs.map((d) => ({ id: d.id, ...d.data() })))), []);
  let shown = users.filter((u) => (u.name || '').toLowerCase().includes(q.trim().toLowerCase()));
  shown = mode === 'players' ? shown.filter((u) => u.id !== me && !rel.blocked.includes(u.id)) : [...shown].sort((a, b) => (b.xp || 0) - (a.xp || 0)).slice(0, 50);
  return (
    <View style={s.screen}>
      <FlatList data={shown} keyExtractor={(u) => u.id} contentContainerStyle={{ padding: 16, gap: 10 }} keyboardShouldPersistTaps="handled"
        ListHeaderComponent={
          <View style={{ gap: 10, marginBottom: 4 }}>
            <ChipRow>
              <Chip label="Joueurs" on={mode === 'players'} onPress={() => setMode('players')} />
              <Chip label="Classement" on={mode === 'rank'} onPress={() => setMode('rank')} />
            </ChipRow>
            {mode === 'players' && rel.incoming.map((r) => (
              <View key={r.id} style={[s.card, s.row]}>
                <Avatar uid={r.from} name={r.fromName} />
                <Text style={[s.title, s.flex]}>{r.fromName}</Text>
                <Btn title="Accepter" onPress={() => A.accept(r)} />
                <Btn variant="ghost" title="Refuser" onPress={() => A.decline(r)} />
              </View>))}
            <Field placeholder="Rechercher un joueur" value={q} onChangeText={setQ} />
          </View>}
        ListEmptyComponent={<Text style={s.dim}>Aucun joueur trouvé.</Text>}
        renderItem={({ item, index }) => {
          const lvl = levelOf(item.xp || 0);
          return (
            <Pressable style={[s.card, s.row]} onPress={() => navigation.navigate('UserProfile', { uid: item.id })}>
              {mode === 'rank' && <Text style={{ color: C.accent, fontWeight: '900', width: 30 }}>#{index + 1}</Text>}
              <AvatarView photo={item.photo} name={item.name} size={44} />
              <View style={s.flex}>
                <Text style={s.title}>{item.name}</Text>
                <Text style={s.dim}>Niv. {lvl} · {rankOf(lvl)}{mode === 'rank' ? ` · ${item.xp || 0} XP` : ''}</Text>
              </View>
              {mode === 'players' && <FriendButton uid={item.id} rel={rel} />}
            </Pressable>);
        }} />
    </View>
  );
}

export function UserProfile({ route, navigation }) {
  const me = auth.currentUser;
  const uid = route.params?.uid ?? me.uid; const isMe = uid === me.uid;
  const rel = useRelations();
  const [u, setU] = useState(null);
  const [f, setF] = useState({ bio: '', gamerTag: '', games: '', platforms: [] });
  const init = useRef(false);
  const [delOpen, setDelOpen] = useState(false); const [pwd, setPwd] = useState('');
  useEffect(() => onSnapshot(doc(db, 'users', uid), (d) => {
    if (!d.exists()) return;
    const x = d.data(); setU({ id: d.id, ...x });
    if (!init.current) { init.current = true; setF({ bio: x.bio || '', gamerTag: x.gamerTag || '', games: x.games || '', platforms: x.platforms || [] }); }
    if (!isMe) navigation.setOptions({ title: x.name });
  }), [uid]);
  if (!u) return <View style={s.screen} />;
  const lvl = levelOf(u.xp || 0);
  const changePhoto = async () => {
    const p = await pickImage(300, 0.5); if (!p) return;
    await updateDoc(doc(db, 'users', me.uid), { photo: p }); clearUser(me.uid);
  };
  const togglePlat = (p) => setF((x) => ({ ...x, platforms: x.platforms.includes(p) ? x.platforms.filter((y) => y !== p) : [...x.platforms, p] }));
  const deleteAccount = async () => {
    try {
      await reauthenticateWithCredential(me, EmailAuthProvider.credential(me.email, pwd));
      const mine = await getDocs(query(collection(db, 'posts'), where('uid', '==', me.uid)));
      await Promise.all(mine.docs.map((d) => deleteDoc(d.ref)));
      await deleteDoc(doc(db, 'users', me.uid));
      await deleteUser(me);
    } catch (e) {
      Alert.alert('Suppression impossible', e.code === 'auth/invalid-credential' || e.code === 'auth/wrong-password' ? 'Mot de passe incorrect.' : e.message);
    }
  };
  const invite = async () => {
    const mine = await getUser(me.uid);
    notify(uid, 'invite', { game: (mine?.games || '').split(',')[0].trim() || null });
    Alert.alert('Invitation envoyée', `${u.name} va recevoir ta demande pour jouer ensemble.`);
  };
  const head = (
    <View style={[s.card, { gap: 10, alignItems: 'center' }]}>
      <AvatarView photo={u.photo} name={u.name} size={96} />
      <Text style={{ color: C.text, fontSize: 22, fontWeight: '800' }}>{u.name}</Text>
      <Text style={{ color: C.accent, fontWeight: '800' }}>Niv. {lvl} · {rankOf(lvl)}</Text>
      <XpBar xp={u.xp || 0} />
      <Text style={s.dim}>{u.xp || 0} XP · {u.friends?.length || 0} ami(s)</Text>
      {isMe ? (<>
        <Btn variant="ghost" title="Changer la photo" onPress={changePhoto} />
        <Field style={{ alignSelf: 'stretch' }} placeholder="Pseudo de jeu (Discord, Steam, PSN…)" value={f.gamerTag} onChangeText={(v) => setF({ ...f, gamerTag: v })} />
        <Field style={{ alignSelf: 'stretch' }} placeholder="Jeux préférés (ex : Valorant, Zelda)" value={f.games} onChangeText={(v) => setF({ ...f, games: v })} autoCapitalize="sentences" />
        <ChipRow>{PLATFORMS.map((p) => <Chip key={p} label={p} on={f.platforms.includes(p)} onPress={() => togglePlat(p)} />)}</ChipRow>
        <Field style={{ alignSelf: 'stretch' }} placeholder="Ta bio" value={f.bio} onChangeText={(v) => setF({ ...f, bio: v })} autoCapitalize="sentences" />
        <Btn title="Enregistrer mon profil" onPress={() => updateDoc(doc(db, 'users', me.uid), f).then(() => clearUser(me.uid))} />
        <Btn variant="ghost" title="Se déconnecter" onPress={() => signOut(auth)} />
        {delOpen ? (<>
          <Field style={{ alignSelf: 'stretch' }} placeholder="Mot de passe pour confirmer" secureTextEntry value={pwd} onChangeText={setPwd} />
          <Btn title="Supprimer définitivement mon compte" onPress={deleteAccount} style={{ backgroundColor: C.danger }} />
        </>) : <Pressable onPress={() => setDelOpen(true)}><Text style={{ color: C.danger }}>Supprimer mon compte</Text></Pressable>}
      </>) : (<>
        {!!u.gamerTag && <Text style={{ color: C.text, fontWeight: '700' }}>{u.gamerTag}</Text>}
        {!!u.platforms?.length && <Text style={s.dim}>{u.platforms.join(' · ')}</Text>}
        {!!u.games && <Text style={{ color: C.text }}>Joue à : {u.games}</Text>}
        {!!u.bio && <Text style={{ color: C.text }}>{u.bio}</Text>}
        <FriendButton uid={uid} rel={rel} />
        <Btn title="Inviter à jouer" onPress={invite} />
        <Btn variant="ghost" title="Envoyer un message" onPress={() => navigation.navigate('Chat', { uid, name: u.name })} />
        <Btn variant="ghost" title={rel.blocked.includes(uid) ? 'Débloquer' : 'Bloquer ce joueur'}
          onPress={() => updateDoc(doc(db, 'users', me.uid), { blocked: rel.blocked.includes(uid) ? arrayRemove(uid) : arrayUnion(uid) })} />
      </>)}
    </View>
  );
  return <View style={s.screen}><PostList uid={uid} navigation={navigation} header={head} /></View>;
}

const NOTIF = {
  like: 'a aimé ta publication', comment: 'a commenté ta publication',
  friend_request: "t'a envoyé une demande d'ami", friend_accept: 'a accepté ta demande d\'ami', invite: "t'invite à jouer",
};

export function Notifications({ navigation }) {
  const me = auth.currentUser.uid;
  const [list, setList] = useState([]);
  useEffect(() => onSnapshot(query(collection(db, 'notifications'), where('to', '==', me), limit(60)), (sn) => {
    const l = sn.docs.map((d) => ({ id: d.id, ...d.data() }));
    l.sort((a, b) => (b.createdAt?.seconds ?? Infinity) - (a.createdAt?.seconds ?? Infinity));
    setList(l);
  }, () => {}), []);
  const open = (n) => {
    if (!n.read) updateDoc(doc(db, 'notifications', n.id), { read: true });
    if (n.postId) navigation.navigate('Comments', { postId: n.postId });
    else navigation.navigate('UserProfile', { uid: n.from });
  };
  const readAll = () => list.filter((n) => !n.read).forEach((n) => updateDoc(doc(db, 'notifications', n.id), { read: true }));
  return (
    <View style={s.screen}>
      <FlatList data={list} keyExtractor={(n) => n.id} contentContainerStyle={{ padding: 16, gap: 10 }}
        ListHeaderComponent={list.some((n) => !n.read) ? <Btn variant="ghost" title="Tout marquer comme lu" onPress={readAll} /> : null}
        ListEmptyComponent={<Text style={s.dim}>Aucune notification pour l'instant.</Text>}
        renderItem={({ item }) => (
          <Pressable style={[s.card, s.row, !item.read && { borderColor: C.accent }]} onPress={() => open(item)}>
            <Avatar uid={item.from} name={item.fromName} />
            <View style={s.flex}>
              <Text style={{ color: C.text }}><Text style={s.title}>{item.fromName}</Text> {NOTIF[item.type]}{item.game ? ` (${item.game})` : ''}</Text>
              <Text style={s.dim}>{ago(item.createdAt)}</Text>
            </View>
          </Pressable>)} />
    </View>
  );
}

export function Chats({ navigation }) {
  const me = auth.currentUser.uid;
  const [list, setList] = useState([]);
  useEffect(() => onSnapshot(query(collection(db, 'chats'), where('members', 'array-contains', me)), (sn) => {
    const l = sn.docs.map((d) => ({ id: d.id, ...d.data() }));
    l.sort((a, b) => (b.updatedAt?.seconds ?? Infinity) - (a.updatedAt?.seconds ?? Infinity));
    setList(l);
  }, () => {}), []);
  return (
    <View style={s.screen}>
      <FlatList data={list} keyExtractor={(c) => c.id} contentContainerStyle={{ padding: 16, gap: 10 }}
        ListEmptyComponent={<Text style={s.dim}>Aucune conversation. Ouvre le profil d'un joueur pour lui écrire.</Text>}
        renderItem={({ item }) => {
          const other = item.members.find((x) => x !== me); const name = item.names?.[other] || 'Joueur';
          return (
            <Pressable style={[s.card, s.row]} onPress={() => navigation.navigate('Chat', { uid: other, name })}>
              <Avatar uid={other} name={name} size={44} />
              <View style={s.flex}>
                <Text style={s.title}>{name}</Text>
                <Text style={s.dim} numberOfLines={1}>{item.lastMessage}</Text>
              </View>
            </Pressable>);
        }} />
    </View>
  );
}

export function Chat({ route, navigation }) {
  const { uid, name, groupId } = route.params; const me = auth.currentUser;
  const id = groupId ? null : chatId(me.uid, uid);
  const path = groupId ? ['groups', groupId, 'messages'] : ['chats', id, 'messages'];
  const [msgs, setMsgs] = useState([]); const [text, setText] = useState(''); const ref = useRef();
  useEffect(() => { navigation.setOptions({ title: name }); }, []);
  useEffect(() => onSnapshot(query(collection(db, ...path), orderBy('createdAt', 'asc')),
    (sn) => setMsgs(sn.docs.map((d) => ({ id: d.id, ...d.data() }))), () => {}), [groupId, id]);
  const send = async (img) => {
    const hasImg = typeof img === 'string';
    const t = hasImg ? '' : text.trim();
    if (!t && !hasImg) return;
    setText('');
    if (!groupId) {
      await setDoc(doc(db, 'chats', id), {
        members: [me.uid, uid], names: { [me.uid]: me.displayName || 'Joueur', [uid]: name },
        lastMessage: t || 'Photo', updatedAt: serverTimestamp(),
      }, { merge: true });
    }
    await addDoc(collection(db, ...path), { uid: me.uid, author: me.displayName || 'Joueur', text: t, image: hasImg ? img : null, createdAt: serverTimestamp() });
  };
  return (
    <KeyboardAvoidingView style={s.screen} behavior={Platform.OS === 'ios' ? 'padding' : undefined} keyboardVerticalOffset={90}>
      <FlatList ref={ref} data={msgs} keyExtractor={(m) => m.id} contentContainerStyle={{ padding: 16, gap: 8 }}
        onContentSizeChange={() => ref.current?.scrollToEnd({ animated: false })}
        renderItem={({ item }) => {
          const mine = item.uid === me.uid;
          return (
            <View style={{ alignSelf: mine ? 'flex-end' : 'flex-start', maxWidth: '80%', backgroundColor: mine ? C.violet : C.card, borderRadius: 14, padding: 10, gap: 6 }}>
              {!!groupId && !mine && <Text style={{ color: C.accent, fontWeight: '800', fontSize: 12 }}>{item.author}</Text>}
              {!!item.image && <Photo uri={item.image} style={{ width: 220, height: 165, borderRadius: 10 }} />}
              {!!item.text && <Text style={{ color: C.text, fontSize: 15 }}>{item.text}</Text>}
            </View>);
        }} />
      <View style={[s.row, { padding: 12 }]}>
        <Btn variant="ghost" title="Photo" onPress={async () => { const p = await pickImage(700, 0.5); if (p) send(p); }} />
        <Field style={s.flex} placeholder="Écrire un message" value={text} onChangeText={setText} autoCapitalize="sentences" />
        <Btn title="Envoyer" onPress={() => send()} />
      </View>
    </KeyboardAvoidingView>
  );
}
