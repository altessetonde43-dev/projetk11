import React, { useEffect, useState } from 'react';
import { Pressable, Text, TextInput, StyleSheet, View, Image, Modal } from 'react-native';
import { getUser } from './data';

export const C = { bg: '#000000', card: '#15151A', line: '#2A2A32', text: '#F5F3F3', dim: '#9C9AA3', accent: '#FF2A3A', violet: '#7A1620', danger: '#FFB020' };

export const Btn = ({ title, onPress, variant, style }) => (
  <Pressable onPress={onPress} style={[s.btn, variant === 'ghost' && s.ghost, style]}>
    <Text style={[s.btnTxt, variant === 'ghost' && { color: C.text }]}>{title}</Text>
  </Pressable>
);
export const Field = (p) => <TextInput placeholderTextColor={C.dim} autoCapitalize="none" {...p} style={[s.field, p.style]} />;

export function AvatarView({ photo, name, size = 40 }) {
  const box = { width: size, height: size, borderRadius: size / 2 };
  return photo ? <Image source={{ uri: photo }} style={box} /> : (
    <View style={[box, { backgroundColor: C.violet, alignItems: 'center', justifyContent: 'center' }]}>
      <Text style={{ color: C.text, fontWeight: '800', fontSize: size * 0.42 }}>{(name || '?')[0].toUpperCase()}</Text>
    </View>
  );
}
export function Avatar({ uid, name, size }) {
  const [photo, setPhoto] = useState(null);
  useEffect(() => { let on = true; if (uid) getUser(uid).then((u) => on && setPhoto(u?.photo || null)); return () => { on = false; }; }, [uid]);
  return <AvatarView photo={photo} name={name} size={size} />;
}

export const ago = (ts) => {
  if (!ts) return "à l'instant";
  const m = Math.floor((Date.now() - ts.seconds * 1000) / 60000);
  if (m < 1) return "à l'instant";
  if (m < 60) return `${m} min`;
  const h = Math.floor(m / 60);
  return h < 24 ? `${h} h` : `${Math.floor(h / 24)} j`;
};

export const s = StyleSheet.create({
  flex: { flex: 1 }, row: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  screen: { flex: 1, backgroundColor: C.bg },
  card: { backgroundColor: C.card, borderRadius: 14, padding: 14, borderWidth: 1, borderColor: C.line },
  title: { color: C.text, fontSize: 16, fontWeight: '800' },
  body: { color: C.text, fontSize: 15, lineHeight: 21, marginTop: 6 },
  dim: { color: C.dim, fontSize: 13 },
  field: { backgroundColor: C.card, color: C.text, borderRadius: 12, padding: 12, borderWidth: 1, borderColor: C.line, fontSize: 16 },
  btn: { backgroundColor: C.accent, borderRadius: 10, paddingVertical: 11, paddingHorizontal: 16, alignItems: 'center' },
  ghost: { backgroundColor: C.violet }, btnTxt: { color: '#FFFFFF', fontWeight: '800' },
  error: { color: C.danger, fontWeight: '600' },
});

export const PLATFORMS = ['PC', 'PlayStation', 'Xbox', 'Switch', 'Mobile'];
export const GAMES = ['Fortnite', 'Valorant', 'Minecraft', 'League of Legends', 'CS2', 'Apex Legends', 'GTA Online', 'Rocket League', 'Call of Duty', 'EA FC', 'Genshin Impact', 'Zelda'];
export const levelOf = (xp = 0) => Math.floor(Math.sqrt(xp / 40)) + 1;
export const rankOf = (l) => (l < 3 ? 'Recrue' : l < 6 ? 'Joueur' : l < 10 ? 'Vétéran' : l < 15 ? 'Élite' : 'Légende');

const chipStyles = StyleSheet.create({
  chip: { borderRadius: 20, paddingVertical: 7, paddingHorizontal: 14, borderWidth: 1, borderColor: C.line, backgroundColor: C.card },
  on: { backgroundColor: C.accent, borderColor: C.accent },
});
export const Chip = ({ label, on, onPress }) => (
  <Pressable onPress={onPress} style={[chipStyles.chip, on && chipStyles.on]}>
    <Text style={{ color: on ? '#FFFFFF' : C.text, fontWeight: '700', fontSize: 13 }}>{label}</Text>
  </Pressable>
);
export const ChipRow = ({ children }) => <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>{children}</View>;

export function XpBar({ xp = 0 }) {
  const l = levelOf(xp), lo = 40 * (l - 1) ** 2, hi = 40 * l ** 2;
  const pct = Math.min(1, (xp - lo) / (hi - lo));
  return (
    <View style={{ alignSelf: 'stretch', height: 10, borderRadius: 5, backgroundColor: C.line, overflow: 'hidden' }}>
      <View style={{ width: `${pct * 100}%`, height: '100%', backgroundColor: C.accent }} />
    </View>
  );
}

export function Photo({ uri, style }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <Pressable onPress={() => setOpen(true)}><Image source={{ uri }} style={style} /></Pressable>
      <Modal visible={open} transparent animationType="fade" onRequestClose={() => setOpen(false)}>
        <Pressable onPress={() => setOpen(false)} style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.93)', justifyContent: 'center' }}>
          <Image source={{ uri }} style={{ width: '100%', height: '80%' }} resizeMode="contain" />
        </Pressable>
      </Modal>
    </>
  );
}
