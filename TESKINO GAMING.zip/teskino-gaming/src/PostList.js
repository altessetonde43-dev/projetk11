import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, Pressable, Alert, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { collection, query, where, orderBy, limit, onSnapshot, addDoc, updateDoc, deleteDoc, doc, arrayUnion, arrayRemove, serverTimestamp } from 'firebase/firestore';
import { auth, db } from './firebase';
import { notify, addXp } from './data';
import { pickImage } from './media';
import { Btn, Field, Photo, Avatar, Chip, ChipRow, ago, s, C } from './ui';

const TYPES = [['post', 'Discussion'], ['lfg', "Recherche d'équipe"], ['clip', 'Clip']];

export default function PostList({ group, uid, navigation, header }) {
  const [posts, setPosts] = useState([]);
  const [draft, setDraft] = useState('');
  const [image, setImage] = useState(null);
  const [type, setType] = useState('post');
  const [game, setGame] = useState('');
  const [filter, setFilter] = useState('all');
  const [blocked, setBlocked] = useState([]);
  const me = auth.currentUser;

  useEffect(() => onSnapshot(doc(db, 'users', me.uid), (d) => setBlocked(d.data()?.blocked || []), () => {}), []);
  useEffect(() => {
    const q = group ? query(collection(db, 'posts'), where('groupId', '==', group.id))
      : uid ? query(collection(db, 'posts'), where('uid', '==', uid))
      : query(collection(db, 'posts'), orderBy('createdAt', 'desc'), limit(50));
    return onSnapshot(q, (snap) => {
      const list = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      list.sort((a, b) => (b.createdAt?.seconds ?? Infinity) - (a.createdAt?.seconds ?? Infinity));
      setPosts(list);
    }, () => {});
  }, [group?.id, uid]);

  const publish = async () => {
    if (!draft.trim() && !image) return;
    if (type === 'lfg' && !game.trim()) return Alert.alert('Indique le jeu', "Précise le jeu pour ta recherche d'équipe.");
    const text = draft.trim(), img = image, t = type, g = game.trim();
    setDraft(''); setImage(null); setGame(''); setType('post');
    await addDoc(collection(db, 'posts'), {
      uid: me.uid, author: me.displayName || 'Joueur', text, image: img, type: t, game: t === 'lfg' ? g : null,
      groupId: group?.id ?? null, groupName: group?.name ?? null,
      likes: [], commentCount: 0, createdAt: serverTimestamp(),
    });
    addXp(10);
  };
  const like = async (p) => {
    const liked = p.likes?.includes(me.uid);
    await updateDoc(doc(db, 'posts', p.id), { likes: liked ? arrayRemove(me.uid) : arrayUnion(me.uid) });
    if (!liked) { notify(p.uid, 'like', { postId: p.id }); addXp(1); }
  };
  const remove = (p) => Alert.alert('Supprimer ?', 'Cette publication sera supprimée.', [
    { text: 'Annuler', style: 'cancel' }, { text: 'Supprimer', style: 'destructive', onPress: () => deleteDoc(doc(db, 'posts', p.id)) }]);
  const report = (p) => Alert.alert('Signaler cette publication ?', 'Notre équipe l\'examinera.', [
    { text: 'Annuler', style: 'cancel' },
    { text: 'Signaler', onPress: async () => {
      await addDoc(collection(db, 'reports'), { postId: p.id, reportedUid: p.uid, reporter: me.uid, createdAt: serverTimestamp() });
      Alert.alert('Merci', 'Signalement envoyé.');
    } }]);
  const canPost = !uid || uid === me.uid;
  const data = posts.filter((p) => !blocked.includes(p.uid) && (filter === 'all' || (p.type || 'post') === filter));

  return (
    <FlatList
      data={data} keyExtractor={(p) => p.id} contentContainerStyle={{ padding: 16, gap: 12 }} keyboardShouldPersistTaps="handled"
      ListHeaderComponent={
        <View style={{ gap: 8, marginBottom: 4 }}>
          {header}
          {canPost && <>
            <ChipRow>{TYPES.map(([k, l]) => <Chip key={k} label={l} on={type === k} onPress={() => setType(k)} />)}</ChipRow>
            {type === 'lfg' && <Field placeholder="Jeu (ex : Valorant)" value={game} onChangeText={setGame} autoCapitalize="sentences" />}
            <Field placeholder={type === 'lfg' ? 'Rang, horaire, mode de jeu, nombre de joueurs…' : type === 'clip' ? 'Décris ton clip ou ta capture' : group ? `Écrire dans ${group.name}` : 'Quoi de neuf, gamer ?'}
              value={draft} onChangeText={setDraft} multiline autoCapitalize="sentences" />
            {image && <Image source={{ uri: image }} style={{ width: '100%', aspectRatio: 4 / 3, borderRadius: 10 }} />}
            <View style={[s.row, { justifyContent: 'flex-end' }]}>
              <Btn variant="ghost" title={image ? 'Changer la photo' : type === 'clip' ? 'Ajouter la capture' : 'Ajouter une photo'} onPress={async () => { const p = await pickImage(); if (p) setImage(p); }} />
              <Btn title="Publier" onPress={publish} />
            </View>
          </>}
          {!group && !uid && (
            <ChipRow>
              <Chip label="Tout" on={filter === 'all'} onPress={() => setFilter('all')} />
              <Chip label="Recherche d'équipe" on={filter === 'lfg'} onPress={() => setFilter('lfg')} />
              <Chip label="Clips" on={filter === 'clip'} onPress={() => setFilter('clip')} />
            </ChipRow>)}
        </View>
      }
      ListEmptyComponent={<Text style={s.dim}>Aucune publication pour l'instant.</Text>}
      renderItem={({ item }) => {
        const liked = item.likes?.includes(me.uid);
        return (
          <View style={s.card}>
            <Pressable style={s.row} onPress={() => navigation.navigate('UserProfile', { uid: item.uid })}>
              <Avatar uid={item.uid} name={item.author} />
              <View>
                <Text style={s.title}>{item.author}</Text>
                <Text style={s.dim}>{ago(item.createdAt)}{item.groupName ? ` · ${item.groupName}` : ''}</Text>
              </View>
            </Pressable>
            {item.type === 'lfg' && <Text style={{ color: C.accent, fontWeight: '800', marginTop: 8 }}>Recherche d'équipe · {item.game}</Text>}
            {item.type === 'clip' && <Text style={{ color: C.violet, fontWeight: '800', marginTop: 8 }}>Clip</Text>}
            {!!item.text && <Text style={s.body}>{item.text}</Text>}
            {!!item.image && <Photo uri={item.image} style={{ width: '100%', aspectRatio: 4 / 3, borderRadius: 10, marginTop: 8 }} />}
            <View style={[s.row, { marginTop: 10, gap: 22 }]}>
              <Pressable style={s.row} onPress={() => like(item)}>
                <Ionicons name={liked ? 'flame' : 'flame-outline'} size={22} color={liked ? C.accent : C.dim} />
                <Text style={{ color: liked ? C.accent : C.dim, fontWeight: '700', marginLeft: -6 }}>{item.likes?.length || 0}</Text>
              </Pressable>
              <Pressable style={s.row} onPress={() => navigation.navigate('Comments', { postId: item.id })}>
                <Ionicons name="chatbubble-outline" size={20} color={C.dim} />
                <Text style={{ color: C.dim, fontWeight: '700', marginLeft: -6 }}>{item.commentCount || 0}</Text>
              </Pressable>
              {item.type === 'lfg' && item.uid !== me.uid && (
                <Pressable onPress={() => navigation.navigate('Chat', { uid: item.uid, name: item.author })}><Text style={{ color: C.accent, fontWeight: '800' }}>Rejoindre</Text></Pressable>)}
              <View style={s.flex} />
              {item.uid === me.uid
                ? <Pressable onPress={() => remove(item)}><Ionicons name="trash-outline" size={20} color={C.danger} /></Pressable>
                : <Pressable onPress={() => report(item)}><Ionicons name="flag-outline" size={20} color={C.dim} /></Pressable>}
            </View>
          </View>
        );
      }}
    />
  );
}
