import { getApp, getApps, initializeApp } from 'firebase/app';
import { getAuth, initializeAuth, getReactNativePersistence } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Configure these EXPO_PUBLIC_* values in your local .env file or EAS environment.
// Never commit private service-account credentials into a mobile application.
const firebaseConfig = {
  apiKey: process.env.EXPO_PUBLIC_FIREBASE_API_KEY || 'VOTRE_API_KEY',
  authDomain: process.env.EXPO_PUBLIC_FIREBASE_AUTH_DOMAIN || 'VOTRE_PROJET.firebaseapp.com',
  projectId: process.env.EXPO_PUBLIC_FIREBASE_PROJECT_ID || 'VOTRE_PROJET',
  storageBucket: process.env.EXPO_PUBLIC_FIREBASE_STORAGE_BUCKET || 'VOTRE_PROJET.appspot.com',
  messagingSenderId: process.env.EXPO_PUBLIC_FIREBASE_MESSAGING_SENDER_ID || '000000000000',
  appId: process.env.EXPO_PUBLIC_FIREBASE_APP_ID || '1:000000000000:web:0000000000000000',
};

const configured = Boolean(
  firebaseConfig.apiKey && !firebaseConfig.apiKey.startsWith('VOTRE') &&
  firebaseConfig.projectId && !firebaseConfig.projectId.startsWith('VOTRE') &&
  firebaseConfig.appId && !firebaseConfig.appId.includes('000000000000')
);

const app = getApps().length ? getApp() : initializeApp(firebaseConfig);
let authInstance;
try {
  authInstance = initializeAuth(app, { persistence: getReactNativePersistence(AsyncStorage) });
} catch (error) {
  // Fast refresh can initialize Firebase Auth more than once in development.
  if (error?.code === 'auth/already-initialized') authInstance = getAuth(app);
  else throw error;
}

export const auth = authInstance;
export const db = getFirestore(app);
export const isConfigured = configured;
