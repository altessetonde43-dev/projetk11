# TESKINO GAMING — réseau social gaming

Application Android/iOS Expo + React Native + Firebase : fil d'actualité, publications et captures, recherche d'équipe, communautés avec salons, amis, messagerie privée, notifications, profils joueurs, XP/classement, signalement et blocage.

## Configuration Firebase

1. Crée un projet sur https://console.firebase.google.com.
2. Dans **Authentication**, active le fournisseur **E-mail/Mot de passe**.
3. Crée **Cloud Firestore** et publie les règles de `firestore.rules` après les avoir vérifiées pour ton projet.
4. Dans Paramètres du projet > Tes applications > application Web, récupère la configuration Firebase.
5. Copie `.env.example` vers `.env` et remplace chaque valeur par celle de ton projet. Ne partage pas ton fichier `.env`.
6. Pour EAS, configure les mêmes variables `EXPO_PUBLIC_FIREBASE_*` dans l'environnement EAS utilisé pour compiler. Les variables `EXPO_PUBLIC_` sont intégrées à l'application : elles ne doivent contenir aucun secret serveur ou clé de compte de service.

Sans configuration Firebase, l'application affiche l'écran de configuration au lieu de tenter une connexion.

## Développement depuis Android / Termux

Installe Node.js et Git dans Termux, puis place-toi dans le dossier du projet :

```sh
pkg update && pkg upgrade
pkg install nodejs-lts git
npm install
npx expo install --fix
npx expo-doctor
npx expo start
```

Expo Go peut servir à tester les écrans compatibles. Les notifications push et certaines fonctions natives doivent être vérifiées dans un build Android.

## Générer un APK avec EAS (sans PC)

EAS compile dans le cloud. Depuis le dossier du projet :

```sh
npm install
npm install --global eas-cli
eas login
eas init
eas build:configure
eas build --platform android --profile preview
```

Le profil `preview` produit un APK installable. À la fin, EAS affiche un lien vers le fichier. Pour une version destinée à une publication sur le Play Store :

```sh
eas build --platform android --profile production
```

Il faut un compte Expo et une connexion Internet. La compilation locale Android complète dans Termux n'est pas garantie, car Android SDK/NDK et les outils natifs peuvent être difficiles à configurer sur téléphone.

## Notifications push (optionnel)

Après `eas init`, configure les identifiants Android FCM demandés par EAS. Les fonctions serveur du dossier `functions/` se déploient avec Firebase CLI et peuvent nécessiter le plan Blaze selon les services utilisés :

```sh
npm install --global firebase-tools
firebase login
firebase deploy --only functions
```

## À vérifier avant publication

- Remplacer les variables Firebase et tester inscription, connexion, récupération de mot de passe et suppression de compte.
- Vérifier les règles Firestore avec des comptes de test : les règles doivent limiter chaque utilisateur à ses propres données et aux conversations dont il est membre.
- Ajouter une politique de confidentialité accessible par URL et des informations de contact pour les signalements.
- Tester les notifications sur un APK/EAS build réel.

## Limites actuelles

- Les captures sont compressées et conservées dans Firestore : ce choix est adapté à un prototype, mais peut augmenter les coûts et atteindre les limites de documents. Pour une mise à l'échelle, prévoir Firebase Storage avec des règles dédiées.
- Le classement actuel est basé sur un nombre limité de profils chargés côté client.
- Le projet n'embarque pas de service de modération humaine automatique : les signalements doivent être examinés depuis Firebase ou un outil d'administration sécurisé.
