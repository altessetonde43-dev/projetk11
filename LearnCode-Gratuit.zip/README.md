# LearnCode — version gratuite

Version gratuite de LearnCode pour apprendre Python.
- Cours Python
- Éditeur Python dans le navigateur
- Exercices et projets
- Progression locale
- Interface responsive téléphone/ordinateur
- Aucun abonnement Premium

Pour publier le site : envoyer le contenu de ce dossier sur GitHub Pages, Cloudflare Pages ou un autre hébergeur statique.
