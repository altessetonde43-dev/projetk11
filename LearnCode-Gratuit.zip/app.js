const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const chapters=[
["Fondamentaux","Les bases absolues de Python",["Bienvenue et environnement","Hello World et print()","Commentaires et bonnes pratiques","Variables et affectation","Types int, float, str, bool","Conversion de types","Entrées utilisateur","Opérateurs arithmétiques","Comparaisons et booléens","F-strings et formatage"]],
["Contrôle du programme","Faire décider et répéter le programme",["if, elif, else","Conditions imbriquées","Opérateurs logiques","match / case","Boucle while","Boucle for","range()","break et continue","Compréhensions simples","Mini-projet : menu interactif"]],
["Listes et collections","Manipuler les données efficacement",["Listes : création et index","Slicing","Ajouter, supprimer, trier","Tuples","Ensembles set","Dictionnaires","Parcourir un dictionnaire","Comprehensions","Unpacking","Choisir la bonne collection"]],
["Fonctions","Écrire du code réutilisable",["Créer une fonction","Paramètres et arguments","return","Arguments par défaut","Arguments nommés","*args et **kwargs","Portée des variables","Fonctions lambda","Docstrings et annotations","Mini-projet : bibliothèque de fonctions"]],
["Erreurs et fichiers","Rendre les programmes robustes",["Exceptions : comprendre les erreurs","try / except","else / finally","Lever une exception","Lire un fichier texte","Écrire et ajouter dans un fichier","with et gestion des ressources","JSON","CSV","Mini-projet : carnet de données"]],
["Modules et packages","Organiser un vrai projet Python",["import et from","Créer son module","__name__ et point d'entrée","Bibliothèque standard","pathlib","datetime","random","statistics et math","Créer un package","Environnement virtuel et pip"]],
["POO","Programmer avec des objets",["Classes et objets","__init__","Attributs et méthodes","Méthodes de classe et static","Encapsulation","Héritage","super()","Polymorphisme","dataclasses","Mini-projet : gestion de bibliothèque"]],
["Python avancé","Les outils du Python moderne",["Itérateurs","Générateurs","yield","Décorateurs","Context managers","Expressions génératrices","Fonctions d'ordre supérieur","typing","dataclasses avancées","Comprendre la complexité"]],
["Web et API","Connecter Python au monde",["HTTP et URLs","Lire du JSON","APIs REST","urllib","Requests : principes","Créer une API Flask","Routes et paramètres","Validation des données","API + JSON","Mini-projet : client météo"]],
["Données et automatisation","Construire des outils utiles",["Recherche et filtrage","Agrégations","Manipuler des dates","CSV vers JSON","Nettoyage de données","Expressions régulières","Automatiser des fichiers","Arguments en ligne de commande","Logs","Mini-projet : analyseur de fichiers"]],
["Tests et qualité","Écrire du code fiable",["Pourquoi tester","assert","unittest","Tests paramétrés","Mocks : concept","Déboguer efficacement","PEP 8","Type hints","Refactoriser","Projet : application testée"]],
["Projets de A à Z","Construire ton portfolio Python",["Calculatrice","Jeu de devinettes","Pierre-feuille-ciseaux","To-do CLI","Quiz Python","Gestionnaire de contacts","Analyseur CSV","Générateur de mots de passe","Mini API","Projet final : application complète"]]
];
let lessons=[];let id=0;
chapters.forEach((c,ci)=>c[2].forEach((title,li)=>lessons.push({id:id++,chapter:ci+1,chapterName:c[0],title,level:ci<2?"Débutant":ci<6?"Intermédiaire":"Avancé"})));
const examples={
"Hello World et print()":`print("Bonjour, LearnCode !")\nprint("Python est prêt.")`,
"Variables et affectation":`nom = "Alex"\nage = 15\nprint(f"{nom} a {age} ans")`,
"if, elif, else":`age = 18\nif age >= 18:\n    print("Majeur")\nelse:\n    print("Mineur")`,
"Boucle for":`for i in range(1, 6):\n    print(i)`,
"Créer une fonction":`def saluer(nom):\n    return f"Bonjour {nom} !"\n\nprint(saluer("Python"))`,
"Lire un fichier texte":`from pathlib import Path\n\np = Path("notes.txt")\n# Exemple local :\nprint(p.exists())`,
"Classes et objets":`class Personne:\n    def __init__(self, nom):\n        self.nom = nom\n\n    def saluer(self):\n        return f"Salut, {self.nom} !"\n\np = Personne("Alex")\nprint(p.saluer())`,
"JSON":`import json\n\nprofil = {"nom": "Alex", "niveau": "Python"}\ntexte = json.dumps(profil, ensure_ascii=False)\nprint(texte)`,
"Mini-projet : menu interactif":`def menu():\n    print("1. Dire bonjour")\n    print("2. Dire au revoir")\n    print("3. Quitter")\n\nmenu()`
};
function state(){return JSON.parse(localStorage.getItem("lc_state")||'{"done":[],"files":{"main.py":"print(\\"Bienvenue dans LearnCode !\\")"},"name":"Apprenant"}')}
let S=state();function save(){localStorage.setItem("lc_state",JSON.stringify(S));updateProgress()}
function pct(){return Math.round(S.done.length/lessons.length*100)}
function updateProgress(){let p=pct();$("#sidePercent").textContent=p+"%";$("#sideBar").style.width=p+"%";$("#sideDone").textContent=`${S.done.length} / ${lessons.length} leçons`}
function toast(t){$("#toast").textContent=t;$("#toast").classList.add("show");setTimeout(()=>$("#toast").classList.remove("show"),2200)}
function nav(view){$$(".nav").forEach(x=>x.classList.toggle("active",x.dataset.view===view));render(view);$("#sidebar").classList.remove("open")}
$$("[data-view]").forEach(b=>b.addEventListener("click",()=>nav(b.dataset.view)));
$("#menuBtn").onclick=()=>$("#sidebar").classList.toggle("open");$("#themeBtn").onclick=()=>document.body.classList.toggle("light");
$("#profileBtn").onclick=()=>{$("#profileModal").classList.add("open");$("#nameInput").value=S.name||"Apprenant"}
$$("[data-close]").forEach(b=>b.onclick=()=>b.closest(".modal").classList.remove("open"));
$("#saveName").onclick=()=>{S.name=$("#nameInput").value.trim()||"Apprenant";save();$("#profileModal").classList.remove("open");toast("Profil enregistré")};
function lessonCard(l){let d=S.done.includes(l.id);return `<div class="lesson-row ${d?"done":""}" data-lesson="${l.id}"><div class="check">${d?"✓":""}</div><div><h4>${l.chapter}.${l.id%10+1} · ${l.title}</h4><small>${l.level} · ${l.chapterName}</small></div><span class="push muted">›</span></div>`}
function courseCard(c,ci){let ids=lessons.filter(x=>x.chapter===ci+1).map(x=>x.id),done=ids.filter(x=>S.done.includes(x)).length,p=Math.round(done/ids.length*100);return `<article class="card course"><div class="num">CHAPITRE ${String(ci+1).padStart(2,"0")}</div><h3>${c[0]}</h3><p>${c[1]}</p><span class="tag">${ids.length} leçons</span><span class="tag">${ci<2?"Débutant":ci<6?"Intermédiaire":"Avancé"}</span><div class="bottom"><button class="secondary" data-course="${ci}">Ouvrir</button><div class="progress-ring" style="--p:${p*3.6}deg"><span>${p}%</span></div></div></article>`}
function render(view="home"){
let m=$("#main");
if(view==="home"){m.innerHTML=`<section class="hero"><div class="eyebrow">PYTHON ACADEMY · ${lessons.length} LEÇONS</div><h1>Apprends Python.<br><em>Code immédiatement.</em></h1><p>Un parcours complet, des exercices, des projets et un véritable studio Python dans une seule plateforme. De zéro jusqu'aux concepts avancés.</p><div class="actions"><button class="primary" id="continue">▶ Continuer mon parcours</button><button class="secondary" id="allCourses">Voir tous les cours</button></div></section><div class="stats"><div class="stat"><small>Progression</small><br><b>${pct()}%</b></div><div class="stat"><small>Leçons terminées</small><br><b>${S.done.length}</b></div><div class="stat"><small>Chapitres</small><br><b>${chapters.length}</b></div><div class="stat"><small>Projets</small><br><b>10+</b></div></div><div class="section-head"><h2>Parcours Python</h2></div><div class="grid">${chapters.slice(0,6).map((c,i)=>courseCard(c,i)).join("")}</div>`;$("#continue").onclick=()=>openLesson(lessons.find(l=>!S.done.includes(l.id))||lessons[0]);$("#allCourses").onclick=()=>nav("courses");bindCourse()}
else if(view==="courses"){m.innerHTML=`<div class="section-head"><div><div class="eyebrow">CURRICULUM</div><h2>Tous les cours Python</h2></div></div><div class="grid">${chapters.map((c,i)=>courseCard(c,i)).join("")}</div><div id="chapterDetail"></div>`;bindCourse()}
else if(view==="practice"){m.innerHTML=`<div class="section-head"><div><div class="eyebrow">ENTRAÎNEMENT</div><h2>Exercices Python</h2></div></div><div class="grid">${lessons.filter((l,i)=>i%3===0).slice(0,12).map(l=>`<article class="card practice-card"><span class="difficulty ${l.level==="Débutant"?"easy":l.level==="Intermédiaire"?"medium":"hard"}">${l.level}</span><h3>${l.title}</h3><p class="muted">Applique ce concept dans Python. Lis la leçon, écris ton code et exécute-le dans le Studio.</p><button class="secondary" data-practice="${l.id}">Commencer ›</button></article>`).join("")}</div>`;$$("[data-practice]").forEach(b=>b.onclick=()=>openLesson(lessons[+b.dataset.practice]))}
else if(view==="projects"){let ps=["Calculatrice CLI","Jeu de devinettes","To-do list","Quiz Python","Gestionnaire de contacts","Analyseur CSV","Automatisation de fichiers","Client API","Mini service web","Projet final"];m.innerHTML=`<div class="hero"><div class="eyebrow">BUILD LAB</div><h1>Projets <em>pratiques.</em></h1><p>Construis des programmes complets et transforme les notions apprises en vrais projets.</p></div><div class="grid">${ps.map((p,i)=>`<article class="card practice-card"><span class="tag">PROJET ${i+1}</span><h3>${p}</h3><p class="muted">Objectif, étapes, contraintes, tests et extension. Construis-le dans Python Studio.</p><button class="primary" data-project="${i}">Ouvrir le projet</button></article>`).join("")}</div>`;$$("[data-project]").forEach(b=>b.onclick=()=>openProject(+b.dataset.project))}
else if(view==="editor"){renderEditor()}
else if(view==="files"){renderFiles()}
else if(view==="progress"){renderProgress()}
updateProgress();bindLessons()
}
function bindCourse(){$$("[data-course]").forEach(b=>b.onclick=()=>{let c=chapters[+b.dataset.course],ls=lessons.filter(l=>l.chapter===+b.dataset.course+1);$("#chapterDetail").innerHTML=`<div class="section-head"><h2>${c[0]}</h2></div><div class="lesson-list">${ls.map(lessonCard).join("")}</div>`;bindLessons()})}
function bindLessons(){$$("[data-lesson]").forEach(x=>x.onclick=()=>openLesson(lessons[+x.dataset.lesson]))}
function openLesson(l){
  const free = l.id < 10 || S.premium === true;
  if(!free){
    $("#lessonContent").innerHTML=`<div class="eyebrow">CONTENU PREMIUM</div><span class="premium-badge">💎 PREMIUM</span><h1>${esc(l.title)}</h1><p>Cette leçon fait partie du parcours Premium. Les 10 premières leçons restent accessibles gratuitement pour découvrir LearnCode.</p><div class="lock">🔒 Accès Premium requis pour continuer ce chapitre et débloquer les cours avancés, exercices et projets.</div><div class="lesson-actions"><button class="primary" id="goPremium">Voir les offres Premium</button></div>`;
    $("#lessonModal").classList.add("open");
    $("#goPremium").onclick=()=>{$("#lessonModal").classList.remove("open");nav("premium")};
    return;
  }
  let code=examples[l.title]||`# ${l.title}\n\n# Écris ton code ici.\nprint("À toi de jouer !")`;
  $("#lessonContent").innerHTML=`<div class="eyebrow">CHAPITRE ${l.chapter} · ${l.level}</div><h1>${l.title}</h1><p><b>Objectif :</b> comprendre <strong>${l.title}</strong> et savoir l'utiliser dans un programme Python.</p><h2>Le concept</h2><p>En Python, ce concept fait partie des outils essentiels pour écrire un programme clair, lisible et réutilisable. Commence par observer l'exemple, puis modifie-le dans le Studio.</p><h2>Exemple</h2><pre>${esc(code)}</pre><h2>À retenir</h2><ul><li>Lis le code ligne par ligne avant de l'exécuter.</li><li>Modifie une valeur et observe ce qui change.</li><li>Teste un cas normal puis un cas limite.</li></ul><h2>Défi</h2><p>Écris ta propre version sans copier l'exemple. Quand ton programme fonctionne, marque la leçon comme terminée.</p><div class="lesson-actions"><button class="primary" id="practiceLesson">▸ Ouvrir dans Python Studio</button><button class="secondary" id="completeLesson">${S.done.includes(l.id)?"✓ Leçon terminée":"Marquer comme terminée"}</button></div>`;
  $("#lessonModal").classList.add("open");
  $("#practiceLesson").onclick=()=>{$("#lessonModal").classList.remove("open");nav("editor");setTimeout(()=>{if(window.setEditorCode)setEditorCode(code)},50)};
  $("#completeLesson").onclick=()=>{if(!S.done.includes(l.id))S.done.push(l.id);save();$("#completeLesson").textContent="✓ Leçon terminée";toast("Leçon validée !")};
}
function esc(s){return s.replace(/[&<>]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;"}[c]))}
function renderEditor(){let files=Object.keys(S.files);$("#main").innerHTML=`<div class="section-head"><div><div class="eyebrow">PYTHON STUDIO</div><h2>Ton environnement de code</h2></div><div><button class="secondary" id="newFile">＋ Fichier</button> <button class="primary" id="saveFile">💾 Sauvegarder</button></div></div><div class="editor-wrap"><aside class="editor-side"><b>EXPLORATEUR</b><div style="height:12px"></div><div id="fileList">${files.map((f,i)=>`<div class="file ${i===0?"active":""}" data-file="${esc(f)}">🐍 ${esc(f)}</div>`).join("")}</div></aside><section class="editor-main"><div class="tabs"><div class="tab active" id="tabName">${esc(files[0]||"main.py")}</div></div><div class="code-area"><textarea id="code" spellcheck="false">${esc(S.files[files[0]]||"")}</textarea></div><div class="editor-toolbar"><button class="primary" id="runCode">▶ Exécuter</button><button class="secondary" id="clearConsole">Effacer</button></div><div class="console" id="console">Prêt à exécuter.\\nPython sera chargé au premier lancement.</div></section><aside class="editor-help"><h3>⚡ Aide rapide</h3><div class="hint">Écris du Python puis appuie sur <b>Exécuter</b>. Le code est conservé sur ton appareil.</div><h3>Raccourcis</h3><div class="hint">Entrée : nouvelle ligne<br>Tab : indentation<br>Ctrl/⌘ + S : sauvegarder</div><h3>Exemple</h3><pre style="font-size:11px">nom = "Python"\\nprint("Bonjour", nom)</pre></aside></div>`;let current=files[0]||"main.py";window.setEditorCode=c=>{$("#code").value=c};$$("[data-file]").forEach(f=>f.onclick=()=>{current=f.dataset.file;$("#code").value=S.files[current]||"";$("#tabName").textContent=current;$$(".file").forEach(x=>x.classList.remove("active"));f.classList.add("active")});$("#saveFile").onclick=()=>{S.files[current]=$("#code").value;save();toast("Fichier sauvegardé")};$("#newFile").onclick=()=>{let n=prompt("Nom du fichier","script.py");if(n){if(!n.endsWith(".py"))n+=".py";S.files[n]="# Nouveau fichier Python\\n";save();renderEditor()}};$("#clearConsole").onclick=()=>$("#console").textContent="Console effacée.";$("#runCode").onclick=()=>runPython($("#code").value);$("#code").addEventListener("keydown",e=>{if(e.key==="Tab"){e.preventDefault();let a=e.target,s=a.selectionStart;a.value=a.value.slice(0,s)+"    "+a.value.slice(a.selectionEnd);a.selectionStart=a.selectionEnd=s+4}if((e.ctrlKey||e.metaKey)&&e.key==="s"){e.preventDefault();$("#saveFile").click()}})}
async function runPython(code){let out=$("#console");out.textContent="Chargement de Python…";try{if(!window.pyodide){let sc=document.createElement("script");sc.src="https://cdn.jsdelivr.net/pyodide/v0.27.7/full/pyodide.js";document.head.appendChild(sc);await new Promise((res,rej)=>{sc.onload=res;sc.onerror=rej});window.pyodide=await loadPyodide()}let result=await pyodide.runPythonAsync(`import sys,io,contextlib,traceback\\n_b=io.StringIO()\\ntry:\\n    with contextlib.redirect_stdout(_b):\\n        exec(${JSON.stringify(code)}, {})\\n    print(_b.getvalue(), end="")\\nexcept Exception:\\n    print(_b.getvalue(), end="")\\n    traceback.print_exc()`);out.textContent=result||"Programme terminé sans sortie."}catch(e){out.textContent="Impossible de charger/exécuter Python. Vérifie ta connexion Internet.\\n\\n"+e}}
function renderFiles(){let files=Object.entries(S.files);$("#main").innerHTML=`<div class="hero"><div class="eyebrow">WORKSPACE</div><h1>Mes <em>fichiers.</em></h1><p>Tes fichiers Python sont enregistrés localement dans ton navigateur.</p><button class="primary" id="goEditor">▸ Ouvrir Python Studio</button></div><div class="lesson-list">${files.map(([n,c])=>`<div class="lesson-row"><div class="check">🐍</div><div><h4>${esc(n)}</h4><small>${c.length} caractères</small></div><button class="secondary push" data-openfile="${esc(n)}">Ouvrir</button></div>`).join("")}</div>`;$("#goEditor").onclick=()=>nav("editor");$$("[data-openfile]").forEach(b=>b.onclick=()=>{nav("editor");setTimeout(()=>{let el=$$("[data-file]").find(x=>x.dataset.file===b.dataset.openfile);if(el)el.click()},40)})}
function renderProgress(){let p=pct(),next=lessons.find(l=>!S.done.includes(l.id));$("#main").innerHTML=`<div class="section-head"><div><div class="eyebrow">TON PARCOURS</div><h2>Ma progression</h2></div></div><div class="dashboard"><div class="card big-progress"><small class="muted">Progression globale</small><br><strong>${p}%</strong><div class="bar-lg"><i style="width:${p}%"></i></div><p class="muted">${S.done.length} leçons terminées sur ${lessons.length}. ${next?"Prochaine étape : "+next.title:"Parcours terminé !"}</p>${next?`<button class="primary" id="nextLesson">Continuer ›</button>`:""}</div><div class="card big-progress"><h3>Badges</h3><p>🏁 Premier pas — ${S.done.length>0?"débloqué":"à débloquer"}</p><p>🔥 10 leçons — ${S.done.length>=10?"débloqué":"à débloquer"}</p><p>🚀 50 leçons — ${S.done.length>=50?"débloqué":"à débloquer"}</p><p>🏆 Maître Python — ${S.done.length>=100?"débloqué":"à débloquer"}</p></div></div><div class="section-head"><h2>Chapitres</h2></div><div class="grid">${chapters.map((c,i)=>courseCard(c,i)).join("")}</div>`;if(next)$("#nextLesson").onclick=()=>openLesson(next);bindCourse()}
function openProject(i){if(i>1 && !S.premium){nav("premium");toast("Ce projet est réservé au Premium");return}let names=["Calculatrice CLI","Jeu de devinettes","To-do list","Quiz Python","Gestionnaire de contacts","Analyseur CSV","Automatisation de fichiers","Client API","Mini service web","Projet final"];let starters=[`def addition(a, b):\\n    return a + b\\n\\nprint(addition(12, 8))`,`import random\\nsecret=random.randint(1,10)\\nprint("Jeu prêt !")`,`taches=[]\\ntaches.append("Apprendre Python")\\nprint(taches)`];let code=starters[i]||`# ${names[i]}\\n\\n# Étape 1 : définir les données\\n# Étape 2 : écrire les fonctions\\n# Étape 3 : tester\\nprint("Projet démarré !")`;$("#lessonContent").innerHTML=`<div class="eyebrow">BUILD LAB · PROJET ${i+1}</div><h1>${names[i]}</h1><p>Construis ce projet en plusieurs étapes. Commence par le squelette puis ajoute progressivement des fonctionnalités.</p><h2>Plan</h2><ol><li>Définir les données et les entrées.</li><li>Créer des fonctions courtes et testables.</li><li>Gérer les erreurs et les cas limites.</li><li>Améliorer l'interface et ajouter une extension.</li></ol><h2>Squelette de départ</h2><pre>${esc(code)}</pre><div class="lesson-actions"><button class="primary" id="projCode">▸ Ouvrir dans le Studio</button></div>`;$("#lessonModal").classList.add("open");$("#projCode").onclick=()=>{$("#lessonModal").classList.remove("open");nav("editor");setTimeout(()=>{if(window.setEditorCode)setEditorCode(code)},50)}}
$("#globalSearch").addEventListener("input",e=>{let q=e.target.value.trim().toLowerCase();if(q.length<2)return;let found=lessons.filter(l=>(l.title+" "+l.chapterName).toLowerCase().includes(q)).slice(0,8);$("#main").innerHTML=`<div class="section-head"><div><div class="eyebrow">RECHERCHE</div><h2>${found.length} résultat(s)</h2></div></div><div class="lesson-list">${found.map(lessonCard).join("")||"<p class='muted'>Aucun résultat.</p>"}</div>`;bindLessons()});

/* ===== LearnCode World extensions ===== */
const originalRender = render;
render = function(view="home"){
  if(view==="leaderboard") return renderLeaderboard();
  if(view==="community") return renderCommunity();
  if(view==="certificates") return renderCertificates();
  if(view==="settings") return renderSettings();
  if(view==="premium") return renderPremium();
  if(view==="practice") return renderPracticePlus();
  originalRender(view);
};

const communityPosts = JSON.parse(localStorage.getItem("lc_posts")||"null") || [
 {name:"LearnCode",text:"Bienvenue dans la communauté Python ! Partage ton projet, pose une question et aide les autres apprenants.",likes:12},
 {name:"Python Club",text:"Défi du jour : écris une fonction qui compte les voyelles d'une phrase.",likes:8}
];
function savePosts(){localStorage.setItem("lc_posts",JSON.stringify(communityPosts))}
function renderPracticePlus(){
  const items=lessons.map((l,i)=>({...l,question:
    i%4===0?`Quelle fonction affiche du texte en Python ?`:i%4===1?`Quel mot-clé crée une condition ?`:i%4===2?`Quelle collection associe des clés à des valeurs ?`:`Quel mot-clé sert à définir une fonction ?`,
    answers:i%4===0?["print()","echo()","show()","write()"]:i%4===1?["if","when","case","check"]:i%4===2?["dict","list","tuple","set"]:["def","func","function","lambda"],
    correct:0}));
  $("#main").innerHTML=`<div class="section-head"><div><div class="eyebrow">SMART PRACTICE</div><h2>Exercices & quiz interactifs</h2></div></div>
  <div class="notice">Chaque réponse est corrigée immédiatement. Ton score et ta progression sont enregistrés sur cet appareil.</div>
  <div id="quizBox" class="quiz card" style="padding:20px"></div>`;
  let q=items[Math.min(S.done.length,items.length-1)], score=0;
  function draw(){
    $("#quizBox").innerHTML=`<div class="label">${q.level} · ${q.chapterName}</div><h2>${q.question}</h2>
    ${q.answers.map((a,i)=>`<button class="option" data-opt="${i}">${a}</button>`).join("")}
    <div id="quizResult" class="notice" style="display:none"></div>`;
    $$(".option").forEach(b=>b.onclick=()=>{
      const chosen=+b.dataset.opt, ok=chosen===q.correct;
      $$(".option").forEach(x=>x.disabled=true);
      b.classList.add(ok?"correct":"wrong");
      $("#quizResult").style.display="block";
      $("#quizResult").textContent=ok?"✓ Bonne réponse !":"✗ Pas encore. Relis la leçon puis réessaie.";
      if(ok){score++; if(!S.done.includes(q.id)){S.done.push(q.id);save()}}
    });
  }
  draw();
}
function renderLeaderboard(){
  const entries=JSON.parse(localStorage.getItem("lc_leaderboard")||"null")||[
    ["Python Explorer",92],["Code Builder",76],["LearnCode Student",61],["Syntax Master",44],["New Coder",27]
  ];
  entries.push([S.name||"Apprenant",pct()]);
  const unique=[...new Map(entries.map(x=>[x[0],x])).values()].sort((a,b)=>b[1]-a[1]);
  $("#main").innerHTML=`<div class="hero"><div class="eyebrow">COMMUNAUTÉ</div><h1>Classement <em>LearnCode.</em></h1><p>Un tableau de progression local pour suivre tes objectifs. Dans une version connectée, il pourra être synchronisé entre comptes.</p></div>
  <div class="card" style="padding:8px">${unique.map((x,i)=>`<div class="lesson-row"><div class="check">${i<3?["🥇","🥈","🥉"][i]:""+(i+1)}</div><div><h4>${esc(x[0])}</h4><small>Progression Python</small></div><strong class="push">${x[1]}%</strong></div>`).join("")}</div>
  <div class="notice">Le classement affiché ici est une démonstration locale : aucun profil réel n'est publié sans serveur et système de comptes.</div>`;
}
function renderCommunity(){
  $("#main").innerHTML=`<div class="section-head"><div><div class="eyebrow">LEARN + SHARE</div><h2>Communauté Python</h2></div></div>
  <div class="card" style="padding:18px"><textarea id="postText" rows="4" style="width:100%" placeholder="Partage une question, une astuce ou ton projet..."></textarea><button class="primary" id="publishPost" style="margin-top:10px">Publier</button></div>
  <div class="section-head"><h2>Discussions</h2></div><div class="grid" id="posts"></div>`;
  function drawPosts(){$("#posts").innerHTML=communityPosts.map((p,i)=>`<article class="card community-post"><span class="tag">${esc(p.name)}</span><h3>${i===0?"Bienvenue sur LearnCode":"Discussion Python"}</h3><p>${esc(p.text)}</p><div class="post-actions"><button data-like="${i}">♥ ${p.likes}</button><button>Répondre</button></div></article>`).join("");$$("[data-like]").forEach(b=>b.onclick=()=>{communityPosts[+b.dataset.like].likes++;savePosts();drawPosts()})}
  $("#publishPost").onclick=()=>{let t=$("#postText").value.trim();if(!t)return toast("Écris un message");communityPosts.unshift({name:S.name||"Apprenant",text:t,likes:0});savePosts();$("#postText").value="";drawPosts();toast("Publication ajoutée")};
  drawPosts();
}
function renderCertificates(){
  const eligible=pct()>=80;
  $("#main").innerHTML=`<div class="hero"><div class="eyebrow">CERTIFICATION</div><h1>Certificats <em>LearnCode.</em></h1><p>Prépare des certificats de parcours à partir de ta progression.</p></div>
  <div class="certificate"><div class="seal">🎓</div><div class="label">LEARNCODE PYTHON ACADEMY</div><h1>${eligible?"Certificat de parcours Python":"Certificat en préparation"}</h1><p>Apprenant : <b>${esc(S.name||"Apprenant")}</b><br>Progression : <b>${pct()}%</b></p>
  <button class="${eligible?"primary":"secondary"}" id="certBtn">${eligible?"Imprimer / enregistrer":"Continuer le parcours"}</button></div>
  <div class="notice">${eligible?"Tu as atteint 80% du parcours.":"Le certificat de démonstration devient disponible à 80% du parcours. Pour une certification officielle, il faudra un système d'évaluation et un serveur de validation."}</div>`;
  $("#certBtn").onclick=()=>eligible?window.print():nav("courses");
}
function renderSettings(){
  $("#main").innerHTML=`<div class="hero"><div class="eyebrow">CONFIGURATION</div><h1>Paramètres <em>LearnCode.</em></h1><p>Personnalise ton espace d'apprentissage et gère tes données locales.</p></div>
  <div class="settings-grid">
   <div class="card setting"><h3>👤 Compte</h3><label>Nom d'affichage<input id="setName" value="${esc(S.name||"Apprenant")}"></label><button class="primary" id="setSave">Enregistrer</button></div>
   <div class="card setting"><h3>🌍 Langue</h3><p class="muted">Architecture prête pour plusieurs langues.</p><select id="lang"><option>Français</option><option>English</option><option>Español</option></select></div>
   <div class="card setting"><h3>☁ Synchronisation</h3><p class="muted">La version actuelle stocke les données localement. Un backend peut être branché ici pour synchroniser les comptes.</p><button class="secondary" onclick="toast('Synchronisation cloud : module prêt à connecter')">Configurer le cloud</button></div>
   <div class="card setting"><h3>🧹 Données</h3><p class="muted">Supprime la progression et les fichiers enregistrés sur cet appareil.</p><button class="danger" id="resetData">Réinitialiser mes données</button></div>
  </div>
  <div class="notice">Pour devenir une plateforme mondiale, les briques serveur à connecter sont : authentification, base de données, synchronisation, paiements éventuels, modération, statistiques et infrastructure HTTPS.</div>`;
  $("#setSave").onclick=()=>{S.name=$("#setName").value.trim()||"Apprenant";save();toast("Profil enregistré")};
  $("#resetData").onclick=()=>{if(confirm("Réinitialiser la progression et les fichiers locaux ?")){localStorage.removeItem("lc_state");location.reload()}};
}

function renderPremium(){
  const paid=S.premium===true;
  $("#main").innerHTML=`<div class="hero"><div class="eyebrow">LEARNCODE PREMIUM</div><span class="premium-badge">💎 ${paid?"ABONNÉ":"ACCÈS PREMIUM"}</span><h1>Apprends Python <em>sans limites.</em></h1><p>Débloque le parcours complet, les exercices avancés et les projets. Les 10 premières leçons restent gratuites.</p></div>
  <div class="price-grid">
    <article class="card price-card"><span class="tag">GRATUIT</span><div class="price">0€ <small>pour toujours</small></div><ul class="feature-list"><li>10 premières leçons</li><li>Python Studio</li><li>Progression locale</li><li>Quelques exercices</li></ul><button class="secondary full">Plan actuel</button></article>
    <article class="card price-card featured"><span class="premium-badge">RECOMMANDÉ</span><div class="price">9,99€ <small>/ mois</small></div><ul class="feature-list"><li>120 leçons complètes</li><li>Tous les exercices</li><li>10+ projets</li><li>Parcours avancé</li><li>Certificat de parcours</li><li>Fonctionnalités Premium</li></ul><button class="primary full" id="monthlyPay">${paid?"Abonnement actif":"Choisir Premium"}</button></article>
    <article class="card price-card"><span class="tag">ANNUEL</span><div class="price">79,99€ <small>/ an</small></div><ul class="feature-list"><li>Toutes les fonctions Premium</li><li>12 mois d'accès</li><li>Certificat de parcours</li><li>Évolutions Premium</li></ul><button class="secondary full" id="yearlyPay">${paid?"Abonnement actif":"Choisir l'annuel"}</button></article>
  </div>
  <div class="pay-note"><b>Paiement réel :</b> cette version contient l'interface et le système d'accès Premium, mais aucun paiement réel n'est simulé. Pour accepter de vrais paiements, il faut connecter un prestataire de paiement et un serveur sécurisé (avec compte de paiement détenu par un adulte/une entreprise habilitée), puis valider les achats côté serveur. Ne mets jamais de clé secrète de paiement dans le JavaScript public.</div>`;
  if(!paid){
    $("#monthlyPay").onclick=()=>premiumDemo();
    $("#yearlyPay").onclick=()=>premiumDemo();
  }
}
function premiumDemo(){
  // Local preview only: never represents a real payment.
  S.premium=true; save(); toast("Mode Premium de démonstration activé sur cet appareil");
  renderPremium();
}

render("home");
