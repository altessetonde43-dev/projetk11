package com.example.gamebooster

import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.BatteryManager
import android.os.Build
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import java.io.File
import android.os.IBinder
import android.os.Looper

/** Surveille la session de jeu : chaleur, batterie, pauses yeux, bilan final. */
class GuardianService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private var start = 0L
    private var breakMin = 0
    private var lastBreak = 0
    private var lastHeat = 0L
    private var maxTemp = 0f
    private var startBat = 0
    private var nid = 10
    private var lowWarned = false
    private var game = ""
    private var autoEnd = false
    private var fg: String? = null
    private var lastQ = 0L
    private var seenGame = false
    private var awayMs = 0L
    private var onset = -1

    private val tick = object : Runnable {
        override fun run() {
            val (temp, lvl) = battery()
            if (temp > maxTemp) maxTemp = temp
            val now = System.currentTimeMillis()
            val mins = ((now - start) / 60000).toInt()
            if (onset < 0 && temp >= 40f) onset = mins
            if (mins >= 360) {
                finishSession(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
                return
            }
            if (temp >= 42f && now - lastHeat > 300000) {
                lastHeat = now
                alert("🔥 Téléphone chaud ($temp°C)", "Faites une pause ou baissez les graphismes pour éviter le throttling.")
            }
            if (Build.VERSION.SDK_INT >= 29) {
                val ts = (getSystemService(Context.POWER_SERVICE) as PowerManager).currentThermalStatus
                if (ts >= PowerManager.THERMAL_STATUS_SEVERE && now - lastHeat > 300000) {
                    lastHeat = now
                    alert("🌡️ Le système bride les performances", "Pause conseillée : le téléphone ralentit pour se refroidir.")
                }
            }
            if (lvl <= 15 && lvl < startBat && !lowWarned) {
                lowWarned = true
                alert("🔋 Batterie à $lvl%", "Branchez le chargeur pour terminer votre partie.")
            }
            if (breakMin > 0 && mins >= lastBreak + breakMin) {
                lastBreak = mins
                alert("👀 Pause yeux", "$mins min de jeu. Regardez au loin pendant 20 secondes.")
            }
            h.postDelayed(this, 60000)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            if (start != 0L) finishSession()
            stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
            return START_NOT_STICKY
        }
        breakMin = intent?.getIntExtra("break", 0) ?: 0
        start = System.currentTimeMillis(); lastBreak = 0; maxTemp = 0f; lowWarned = false
        startBat = battery().second
        game = intent?.getStringExtra("game") ?: ""
        autoEnd = intent?.getBooleanExtra("autoend", false) == true && hasUsageAccess(this)
        fg = null; lastQ = start; seenGame = false; awayMs = 0L; onset = -1
        pingMs = -1; pingSum = 0L; pingN = 0
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("pilot", "Game Booster", NotificationManager.IMPORTANCE_HIGH))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, GuardianService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "pilot")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Game Booster surveille votre session")
            .setContentText("Chaleur, batterie et pauses sous contrôle")
            .setOngoing(true)
            .addAction(Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_delete), "Terminer", stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
        h.removeCallbacks(tick); h.post(tick)
        h.removeCallbacks(watch); if (autoEnd) h.postDelayed(watch, 10000)
        h.removeCallbacks(pingTask); h.post(pingTask)
        if (intent?.getBooleanExtra("overlay", false) == true && Settings.canDrawOverlays(this)) startOverlay()
        return START_NOT_STICKY
    }

    private fun battery(): Pair<Float, Int> {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val t = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val l = (i?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0) * 100 /
                maxOf(1, i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100)
        return t to l
    }

    private fun alert(title: String, text: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(nid++, Notification.Builder(this, "pilot")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title).setContentText(text).setAutoCancel(true).build())
    }

    private fun finishSession() {
        h.removeCallbacks(tick); h.removeCallbacks(watch); h.removeCallbacks(pingTask)
        removeOverlay()
        val mins = ((System.currentTimeMillis() - start) / 60000).toInt()
        val drop = startBat - battery().second
        val avgPing = if (pingN > 0) (pingSum / pingN).toInt() else -1
        val summary = "$mins min · pic ${maxTemp}°C · batterie -$drop%" + (if (avgPing >= 0) " · ping $avgPing ms" else "")
        val sp = getSharedPreferences("p", MODE_PRIVATE)
        val hist = (sp.getString("hist", "") ?: "").split(";").filter { it.isNotBlank() }
            .plus(Session(mins, maxTemp, drop, game, avgPing, onset).encode()).takeLast(12).joinToString(";")
        sp.edit().putString("last", summary).putString("hist", hist).apply()
        if (sp.getBoolean("dndSet", false)) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.isNotificationPolicyAccessGranted) nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
            sp.edit().putBoolean("dndSet", false).apply()
        }
        start = 0L
        alert("🛬 Session terminée", summary)
    }

    // ---- Fin de session automatique : détecte quand le jeu quitte le premier plan ----
    private val watch = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            try {
                val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
                val ev = usm.queryEvents(lastQ, now)
                val e = UsageEvents.Event()
                while (ev.hasNextEvent()) {
                    ev.getNextEvent(e)
                    if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) fg = e.packageName
                }
            } catch (ex: Exception) {}
            lastQ = now
            if (fg == game) { seenGame = true; awayMs = 0L }
            else if (seenGame) awayMs += 10000
            if ((seenGame && awayMs >= 60000) || (!seenGame && now - start > 120000)) {
                finishSession(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
                return
            }
            h.postDelayed(this, 10000)
        }
    }

    // ---- Ping réel (connexion TCP vers 1.1.1.1), moyenne enregistrée dans le bilan ----
    @Volatile private var pingMs = -1
    @Volatile private var pinging = false
    private var pingSum = 0L
    private var pingN = 0
    private val pingTask = object : Runnable {
        override fun run() {
            if (!pinging) {
                pinging = true
                Thread {
                    val ms = pingOnce()
                    pingMs = ms
                    if (ms >= 0) { pingSum += ms; pingN++ }
                    pinging = false
                }.start()
            }
            h.postDelayed(this, 8000)
        }
    }

    // ---- Bulle flottante en jeu (déplaçable) ----
    private var overlay: TextView? = null
    private val ov = object : Runnable {
        override fun run() {
            overlay?.let { updateOverlay(it) }
            h.postDelayed(this, 2000)
        }
    }

    private fun startOverlay() {
        removeOverlay()
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val tv = TextView(this).apply {
            setTextColor(0xFFFFFFFF.toInt()); textSize = 12f; setPadding(22, 14, 22, 14)
            background = GradientDrawable().apply { setColor(0xCC000000.toInt()); cornerRadius = 28f }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 140 }
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var t0 = 0L; var moved = false
        tv.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; t0 = e.eventTime; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.abs(e.rawX - tx) > 12 || Math.abs(e.rawY - ty) > 12) moved = true
                    lp.x = sx + (e.rawX - tx).toInt(); lp.y = sy + (e.rawY - ty).toInt()
                    wm.updateViewLayout(v, lp)
                }
                MotionEvent.ACTION_UP -> if (!moved && e.eventTime - t0 > 800) {
                    h.post { finishSession(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
                }
            }
            true
        }
        try { wm.addView(tv, lp); overlay = tv; h.post(ov) } catch (e: Exception) {}
    }

    private fun removeOverlay() {
        h.removeCallbacks(ov)
        overlay?.let {
            try { (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(it) } catch (e: Exception) {}
        }
        overlay = null
    }

    private fun cpuGhz(): Float? {
        var max = 0L
        for (i in 0..7) {
            val v = try {
                File("/sys/devices/system/cpu/cpu$i/cpufreq/scaling_cur_freq").readText().trim().toLong()
            } catch (e: Exception) { 0L }
            if (v > max) max = v
        }
        return if (max > 0) max / 1_000_000f else null
    }

    private fun updateOverlay(tv: TextView) {
        val (temp, lvl) = battery()
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val mins = (System.currentTimeMillis() - start) / 60000
        val sb = StringBuilder("⏱ $mins min\n🌡 $temp°C\n🧠 RAM ${mi.availMem / 1048576} Mo libres\n🔋 $lvl%\n📶 ${netType(this)} · ${if (pingMs >= 0) "$pingMs ms" else "—"}\n⏹ appui long = fin")
        cpuGhz()?.let { sb.append("\n⚡ CPU ").append(String.format("%.1f", it)).append(" GHz") }
        if (Build.VERSION.SDK_INT >= 29) {
            val ts = (getSystemService(Context.POWER_SERVICE) as PowerManager).currentThermalStatus
            sb.append("\n⚙️ ").append(
                when {
                    ts >= PowerManager.THERMAL_STATUS_SEVERE -> "bridé"
                    ts >= PowerManager.THERMAL_STATUS_MODERATE -> "chaud"
                    else -> "normal"
                }
            )
        }
        tv.text = sb
        (tv.background as GradientDrawable).setColor(if (temp >= 42f) 0xCCB00020.toInt() else 0xCC000000.toInt())
    }

    override fun onDestroy() {
        h.removeCallbacks(tick); h.removeCallbacks(watch); h.removeCallbacks(pingTask)
        removeOverlay(); super.onDestroy()
    }
}
