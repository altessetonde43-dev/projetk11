package com.example.gamebooster

import android.app.AppOpsManager
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Process
import java.net.InetSocketAddress
import java.net.Socket

/** Une session de jeu enregistrée. Format texte : mins,temp,chute,paquet,ping,minutes avant 40°C */
data class Session(val mins: Int, val temp: Float, val drop: Int, val pkg: String, val ping: Int, val onset: Int) {
    fun encode() = "$mins,$temp,$drop,$pkg,$ping,$onset"

    companion object {
        fun parse(line: String): Session? {
            val p = line.split(",")
            if (p.size < 3) return null
            return try {
                Session(
                    p[0].toInt(), p[1].toFloat(), p[2].toInt(),
                    p.getOrElse(3) { "" }, p.getOrElse(4) { "-1" }.toInt(), p.getOrElse(5) { "-1" }.toInt()
                )
            } catch (e: Exception) { null }
        }

        fun parseAll(s: String): List<Session> = s.split(";").filter { it.isNotBlank() }.mapNotNull { parse(it) }
    }
}

/** Vrai si l'utilisateur a accordé « Accès aux données d'utilisation ». */
fun hasUsageAccess(ctx: Context): Boolean {
    val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
    return ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName) ==
        AppOpsManager.MODE_ALLOWED
}

fun netType(ctx: Context): String {
    val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val c = cm.getNetworkCapabilities(cm.activeNetwork) ?: return "hors ligne"
    return when {
        c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
        c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile"
        else -> "Réseau"
    }
}

/** Ping réel : temps de connexion TCP vers Cloudflare (1.1.1.1:443), en ms, ou -1. À appeler hors thread principal. */
fun pingOnce(): Int {
    val t0 = System.nanoTime()
    return try {
        Socket().use { it.connect(InetSocketAddress("1.1.1.1", 443), 1500) }
        ((System.nanoTime() - t0) / 1_000_000).toInt()
    } catch (e: Exception) { -1 }
}
