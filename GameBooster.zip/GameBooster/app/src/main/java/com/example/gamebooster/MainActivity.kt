package com.example.gamebooster

import android.Manifest
import android.app.Activity
import android.app.ActivityManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val BG = 0xFF0E1116.toInt()
    private val CARD = 0xFF1A1214.toInt()
    private val ACCENT = 0xFFFF2D3D.toInt()

    private lateinit var score: TextView
    private lateinit var advice: TextView
    private lateinit var last: TextView
    private lateinit var spin: Spinner
    private lateinit var dndBox: CheckBox
    private lateinit var hist: HistoryView
    private lateinit var stats: TextView
    private lateinit var net: TextView
    private lateinit var tip: TextView
    private lateinit var top: TextView
    private var selected: String? = null
    private var loading = false
    private val breakValues = listOf(0, 20, 30, 45)

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun tv(t: String, size: Float = 15f, color: Int = 0xFFFFFFFF.toInt()) =
        TextView(this).apply { text = t; textSize = size; setTextColor(color) }
    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = GradientDrawable().apply { setColor(CARD); cornerRadius = dp(16).toFloat() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) }
    }
    private fun btn(t: String, color: Int, fn: () -> Unit) = Button(this).apply {
        text = t; setTextColor(0xFFFFFFFF.toInt()); isAllCaps = false
        background = GradientDrawable().apply { setColor(color); cornerRadius = dp(14).toFloat() }
        setOnClickListener { fn() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(10) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(BG)
            setPadding(dp(18), dp(36), dp(18), dp(18))
        }
        root.addView(ImageView(this).apply {
            setImageResource(R.drawable.logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
            layoutParams = LinearLayout.LayoutParams(-1, dp(190))
        })
        root.addView(tv("Votre copilote avant et pendant le jeu", 14f, 0xFF9AA4B2.toInt()).apply {
            setPadding(0, 0, 0, dp(16))
        })

        // Carte 1 : checklist avant décollage
        val c1 = card()
        c1.addView(tv("✈️ Checklist avant décollage", 16f))
        score = tv("--", 48f, 0xFF00E5A0.toInt())
        advice = tv("", 14f, 0xFFCBD3DE.toInt())
        c1.addView(score); c1.addView(advice)
        net = tv("", 13f, 0xFF9AA4B2.toInt()).apply { setPadding(0, dp(6), 0, 0) }
        c1.addView(net)

        // Carte 2 : jeu + profil
        val c2 = card()
        c2.addView(tv("🎮 Votre jeu", 16f))
        val group = RadioGroup(this)
        group.setOnCheckedChangeListener { g, id ->
            selected = g.findViewById<View>(id)?.tag as? String
            selected?.let { prefs().edit().putString("lastGame", it).apply() }
            loadProfile()
        }
        c2.addView(group)
        populate(group)
        c2.addView(tv("Profil de ce jeu (mémorisé)", 13f, 0xFF9AA4B2.toInt()).apply { setPadding(0, dp(10), 0, 0) })
        spin = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Pauses yeux : désactivées", "Pause toutes les 20 min", "Pause toutes les 30 min", "Pause toutes les 45 min"))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) = saveProfile()
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }
        dndBox = CheckBox(this).apply {
            text = "Activer Ne pas déranger pendant la session"
            setTextColor(0xFFFFFFFF.toInt()); setOnCheckedChangeListener { _, _ -> saveProfile() }
        }
        val overlayBox = CheckBox(this).apply {
            text = "Afficher température, RAM et batterie en jeu"
            setTextColor(0xFFFFFFFF.toInt()); isChecked = prefs().getBoolean("overlay", true)
            setOnCheckedChangeListener { _, c -> prefs().edit().putBoolean("overlay", c).apply() }
        }
        val autoBox = CheckBox(this).apply {
            text = "Fin de session automatique quand je quitte le jeu"
            setTextColor(0xFFFFFFFF.toInt()); isChecked = prefs().getBoolean("autoend", true)
            setOnCheckedChangeListener { _, c -> prefs().edit().putBoolean("autoend", c).apply() }
        }
        tip = tv("", 13f, 0xFFCBD3DE.toInt()).apply { setPadding(0, dp(10), 0, 0) }
        c2.addView(spin); c2.addView(dndBox); c2.addView(overlayBox); c2.addView(autoBox); c2.addView(tip)

        last = tv("", 13f, 0xFF9AA4B2.toInt()).apply { setPadding(0, dp(4), 0, dp(12)) }

        root.addView(c1); root.addView(c2)
        root.addView(btn("🛫 DÉCOLLER", ACCENT) { takeoff() })
        root.addView(btn("🛬 Terminer la session", 0xFFFFB84D.toInt()) { landing() })
        root.addView(last)
        val c3 = card()
        c3.addView(tv("📈 Vos sessions (couleur = chaleur)", 16f))
        hist = HistoryView(this).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(90)).apply { topMargin = dp(8) } }
        stats = tv("", 13f, 0xFF9AA4B2.toInt())
        top = tv("", 13f, 0xFFCBD3DE.toInt()).apply { setPadding(0, dp(10), 0, 0) }
        c3.addView(hist); c3.addView(stats); c3.addView(top)
        root.addView(c3)
        setContentView(ScrollView(this).apply { setBackgroundColor(BG); addView(root) })
    }

    override fun onResume() { super.onResume(); refresh() }

    @Volatile private var cache: List<Pair<String, String>> = emptyList()

    /** Chargement des jeux en arrière-plan : l'écran s'affiche instantanément. */
    private fun populate(group: RadioGroup) {
        Thread {
            val pm = packageManager
            val list = pm.getInstalledApplications(0)
                .filter { it.flags and ApplicationInfo.FLAG_SYSTEM == 0 && it.packageName != packageName }
                .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
                .map { pm.getApplicationLabel(it).toString() to it.packageName }
                .sortedBy { it.first.lowercase() }
            cache = list
            val saved = prefs().getString("lastGame", null)
            runOnUiThread {
                for ((label, pkg) in list) {
                    val rb = RadioButton(this).apply {
                        text = label; tag = pkg; id = View.generateViewId(); setTextColor(0xFFFFFFFF.toInt())
                    }
                    group.addView(rb)
                    if (pkg == saved) group.check(rb.id)
                }
                refresh()
                if (list.isEmpty()) Toast.makeText(this, "Aucun jeu trouvé", Toast.LENGTH_LONG).show()
                if (intent?.action == "com.example.gamebooster.TAKEOFF" && selected != null) {
                    intent.action = null
                    takeoff()
                }
            }
        }.start()
    }

    private fun sessions(): List<Session> = Session.parseAll(prefs().getString("hist", "") ?: "")

    private fun labelOf(pkg: String) = cache.firstOrNull { it.second == pkg }?.first ?: pkg

    /** Conseils tirés de VOS sessions réelles sur le jeu sélectionné. */
    private fun updateTip() {
        val g = selected
        if (g == null) { tip.text = ""; return }
        val s = sessions().filter { it.pkg == g }
        if (s.size < 2) { tip.text = "Conseils personnalisés après 2 sessions sur ce jeu."; return }
        val lines = mutableListOf<String>()
        val onsets = s.filter { it.onset >= 0 }.map { it.onset }
        if (onsets.size >= 2) lines += "🌡 Sur ce jeu, le téléphone passe 40°C après ~${onsets.average().toInt()} min : prévoyez une pause avant."
        else lines += "🌡 Pic moyen : ${"%.1f".format(s.map { it.temp }.average())}°C"
        val mins = s.sumOf { it.mins }
        if (mins >= 10) lines += "🔋 Consommation : ~${s.sumOf { it.drop } * 60 / mins} %/h"
        val pings = s.filter { it.ping >= 0 }.map { it.ping }
        if (pings.isNotEmpty()) lines += "📶 Ping moyen : ${pings.average().toInt()} ms"
        tip.text = lines.joinToString("\n")
    }

    private fun freeMb(): Long {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        return ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }.availMem / 1048576
    }

    private fun prefs() = getSharedPreferences("p", MODE_PRIVATE)

    private fun loadProfile() {
        val g = selected ?: return
        loading = true
        spin.setSelection(breakValues.indexOf(prefs().getInt("$g.break", 30)).coerceAtLeast(0))
        dndBox.isChecked = prefs().getBoolean("$g.dnd", false)
        loading = false
        updateTip()
    }

    private fun saveProfile() {
        val g = selected ?: return
        if (loading) return
        prefs().edit().putInt("$g.break", breakValues[spin.selectedItemPosition])
            .putBoolean("$g.dnd", dndBox.isChecked).apply()
    }

    private fun refresh() {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val ramFree = (mi.availMem * 100 / mi.totalMem).toInt()
        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val temp = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val level = (b?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0) * 100 /
                maxOf(1, b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100)
        val st = b?.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL

        val ramS = minOf(100f, ramFree * 2.5f)
        val tempS = ((45 - temp) / 10f * 100f).coerceIn(0f, 100f)
        val batS = if (charging) 100f else level.toFloat()
        val total = (0.4f * ramS + 0.3f * tempS + 0.3f * batS).toInt()
        score.text = "$total/100"
        score.setTextColor(when { total >= 75 -> 0xFF00E5A0.toInt(); total >= 50 -> 0xFFFFB84D.toInt(); else -> 0xFFFF5C5C.toInt() })

        val tips = mutableListOf("RAM libre : $ramFree%  ·  Batterie : $level%  ·  Temp. : $temp°C")
        if (ramFree < 20) tips += "⚠️ RAM basse : le décollage fermera les apps en arrière-plan."
        if (temp >= 40f) tips += "⚠️ Téléphone chaud : laissez-le refroidir avant de jouer."
        if (level < 25 && !charging) tips += "⚠️ Batterie faible : branchez le chargeur."
        if (tips.size == 1) tips += "✅ Tout est vert, bon jeu !"
        advice.text = tips.joinToString("\n")
        last.text = prefs().getString("last", null)?.let { "Dernière session : $it" } ?: ""
        val rows = sessions()
        hist.data = rows; hist.invalidate()
        stats.text = if (rows.isEmpty()) "Aucune session pour l'instant."
            else "${rows.size} sessions · ${rows.sumOf { it.mins }} min de jeu au total"
        val ranking = rows.filter { it.pkg.isNotEmpty() }.groupBy { it.pkg }.entries
            .sortedByDescending { e -> e.value.sumOf { it.mins } }.take(4)
        top.text = if (ranking.isEmpty()) "" else "🏆 Vos jeux\n" + ranking.joinToString("\n") { e ->
            val l = e.value
            val m = l.sumOf { it.mins }
            "${labelOf(e.key)} — ${l.size} sess. · $m min · pic moy ${"%.1f".format(l.map { it.temp }.average())}°C" +
                (if (m >= 10) " · ${l.sumOf { it.drop } * 60 / m} %/h" else "")
        }
        updateTip()
        net.text = "📶 ${netType(this)}"
        Thread {
            val ms = pingOnce()
            runOnUiThread {
                net.text = "📶 ${netType(this)} · " + when {
                    ms < 0 -> "pas de réponse"
                    ms > 100 -> "ping $ms ms ⚠️ élevé"
                    else -> "ping $ms ms"
                }
            }
        }.start()
    }

    private fun takeoff() {
        val game = selected
        if (game == null) { Toast.makeText(this, "Choisissez d'abord un jeu", Toast.LENGTH_SHORT).show(); return }
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val overlayOn = prefs().getBoolean("overlay", true)
        if (overlayOn && !Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "Autorisez l'affichage par-dessus les autres apps, puis rappuyez sur Décoller", Toast.LENGTH_LONG).show()
            return
        }
        val autoOn = prefs().getBoolean("autoend", true)
        if (autoOn && !hasUsageAccess(this)) {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS, Uri.parse("package:$packageName")))
            Toast.makeText(this, "Autorisez « Accès aux données d'utilisation » pour Game Booster, puis rappuyez sur Décoller (ou décochez la fin automatique)", Toast.LENGTH_LONG).show()
            return
        }
        if (dndBox.isChecked) {
            val nm0 = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (!nm0.isNotificationPolicyAccessGranted) {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                Toast.makeText(this, "Autorisez l'accès Ne pas déranger, puis rappuyez sur Décoller", Toast.LENGTH_LONG).show()
                return
            }
        }
        val before = freeMb()
        val others = cache.filter { it.second != game }
        Thread { others.forEach { am.killBackgroundProcesses(it.second) } }.start()

        if (dndBox.isChecked) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.isNotificationPolicyAccessGranted) {
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
                prefs().edit().putBoolean("dndSet", true).apply()
            } else startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
        startForegroundService(Intent(this, GuardianService::class.java)
            .putExtra("break", breakValues[spin.selectedItemPosition])
            .putExtra("overlay", overlayOn)
            .putExtra("game", game).putExtra("autoend", autoOn))
        packageManager.getLaunchIntentForPackage(game)?.let { startActivity(it) }
        Handler(Looper.getMainLooper()).postDelayed({
            refresh()
            val gain = freeMb() - before
            if (gain > 0) Toast.makeText(this, "RAM libérée : $gain Mo", Toast.LENGTH_SHORT).show()
        }, 1500)
    }

    private fun landing() {
        startService(Intent(this, GuardianService::class.java).setAction("STOP"))
        if (prefs().getBoolean("dndSet", false)) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.isNotificationPolicyAccessGranted) nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
            prefs().edit().putBoolean("dndSet", false).apply()
        }
        Handler(Looper.getMainLooper()).postDelayed({ refresh() }, 600)
    }
}

/** Mini graphique : une barre par session, hauteur = durée, couleur = chaleur max. */
class HistoryView(ctx: Context) : View(ctx) {
    var data: List<Session> = emptyList()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        if (data.isEmpty()) return
        val maxM = maxOf(1, data.maxOf { it.mins }).toFloat()
        val w = width.toFloat() / data.size
        data.forEachIndexed { i, d ->
            p.color = when { d.temp >= 42f -> 0xFFFF5C5C.toInt(); d.temp >= 38f -> 0xFFFFB84D.toInt(); else -> 0xFF00E5A0.toInt() }
            val h = maxOf(6f, d.mins / maxM * (height - 6))
            c.drawRoundRect(i * w + 6, height - h, (i + 1) * w - 6, height.toFloat(), 8f, 8f, p)
        }
    }
}
