# Game Booster (Android 8.0+)

## Compiler
1. Android Studio (version récente) : File > Open > dossier `GameBooster`.
2. Attendre la synchro Gradle (téléchargement automatique de Gradle 8.7).
3. Brancher le téléphone (débogage USB) et cliquer sur Run, ou Build > Build APK(s).
   Le build release est signé avec la clé de debug : l'APK s'installe directement.

## Test en 2 minutes
- La température et la RAM affichées doivent correspondre à une autre app (ex. CPU-Z).
- « Décoller » : le jeu se lance, la bulle apparaît (autorisation « par-dessus les autres apps » demandée une fois).
- Appui long sur la bulle (ou « Terminer » dans la notification) : la session s'arrête, un bilan apparaît.
- Arrêt automatique après 6 h si la session est oubliée.

## Limites réelles
- Le boost ferme les apps en arrière-plan ; Android en protège beaucoup, le gain de RAM varie.
- FPS et % CPU indisponibles sans root. La fréquence CPU dépend de l'appareil.

## En cas d'erreur
Copiez le message de la fenêtre « Build » d'Android Studio : il indique le fichier et la ligne.

## Nouveautés
- Fin de session automatique : détecte quand vous quittez le jeu (1 min d'absence). Demande « Accès aux données d'utilisation » une fois.
- Ping réel : connexion TCP vers Cloudflare (1.1.1.1). Il mesure la qualité de votre connexion Internet, pas le serveur précis du jeu.
- Conseils et classement construits à partir de vos propres sessions (chaleur, batterie par heure, ping moyen).
