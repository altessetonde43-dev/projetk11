package com.winlator;

import android.app.ActivityManager;
import android.content.Context;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.StatFs;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

/** Lightweight native system monitor for the ProjetK11 desktop. */
public class ProjectK11SystemMonitorActivity extends AppCompatActivity {
    private TextView info;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.projectk11_system_monitor);
        info = findViewById(R.id.k11_monitor_info);
        findViewById(R.id.k11_monitor_refresh).setOnClickListener(v -> refresh());
        findViewById(R.id.k11_monitor_close).setOnClickListener(v -> finish());
        refresh();
    }
    private void refresh() {
        ActivityManager am = (ActivityManager)getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mem = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mem);
        StatFs fs = new StatFs(getFilesDir().getAbsolutePath());
        long free = fs.getAvailableBytes();
        long total = fs.getTotalBytes();
        BatteryManager bm = (BatteryManager)getSystemService(BATTERY_SERVICE);
        int battery = bm != null ? bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) : -1;
        String text = "Mémoire disponible : " + fmt(mem.availMem) + " / " + fmt(mem.totalMem) +
                "\nStockage disponible : " + fmt(free) + " / " + fmt(total) +
                "\nBatterie : " + (battery >= 0 ? battery + "%" : "indisponible") +
                "\nAndroid : " + android.os.Build.VERSION.RELEASE +
                "\nArchitecture : " + android.os.Build.SUPPORTED_ABIS[0] +
                "\nMoteur graphique : XServer / Vulkan / OpenGL selon la configuration";
        info.setText(text);
    }
    private String fmt(long b) {
        if (b >= 1024L*1024*1024) return String.format(java.util.Locale.US, "%.1f Go", b/1073741824.0);
        return String.format(java.util.Locale.US, "%.0f Mo", b/1048576.0);
    }
}
