package com.winlator;

import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.winlator.container.Container;
import com.winlator.container.ContainerManager;

import java.io.*;
import java.util.ArrayList;
import java.util.zip.*;

/** Backup/restore of complete Winlator containers. */
public class ProjectK11BackupActivity extends AppCompatActivity {
    private static final int PICK_RESTORE=2201;
    private ArrayList<Container> containers; private Spinner spinner;
    @Override protected void onCreate(Bundle state){super.onCreate(state);setContentView(R.layout.projectk11_backup); ContainerManager cm=new ContainerManager(this); containers=cm.getContainers(); spinner=findViewById(R.id.k11_backup_container); ArrayList<String> names=new ArrayList<>(); for(Container c:containers)names.add(c.getName()); if(names.isEmpty())names.add("Aucun conteneur"); spinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names)); findViewById(R.id.k11_backup_export).setOnClickListener(v->exportBackup()); findViewById(R.id.k11_backup_import).setOnClickListener(v->pickRestore()); findViewById(R.id.k11_backup_close).setOnClickListener(v->finish());}
    private void exportBackup(){if(containers.isEmpty()){Toast.makeText(this,"Aucun conteneur à sauvegarder",Toast.LENGTH_SHORT).show();return;} Container c=containers.get(spinner.getSelectedItemPosition()); File out=new File(getFilesDir(),"ProjetK11-"+c.id+"-backup.zip"); new Thread(()->{try{zipDir(c.getRootDir(),c.getRootDir(),out);runOnUiThread(()->share(out));}catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Sauvegarde échouée : "+e.getMessage(),Toast.LENGTH_LONG).show());}}).start();}
    private void share(File f){Intent i=new Intent(Intent.ACTION_SEND);i.setType("application/zip");i.putExtra(Intent.EXTRA_STREAM, androidx.core.content.FileProvider.getUriForFile(this,"com.teskino.gaming.FileProvider",f));i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"Exporter la sauvegarde"));}
    private void pickRestore(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/zip");startActivityForResult(i,PICK_RESTORE);}
    @Override protected void onActivityResult(int r,int code,Intent d){super.onActivityResult(r,code,d);if(r!=PICK_RESTORE||code!=RESULT_OK||d==null||d.getData()==null||containers.isEmpty())return; Uri u=d.getData(); Container c=containers.get(spinner.getSelectedItemPosition()); new AlertDialog.Builder(this).setTitle("Restaurer ?").setMessage("Les fichiers du conteneur « "+c.getName()+" » seront remplacés par la sauvegarde.").setNegativeButton("Annuler",null).setPositiveButton("Restaurer",(x,w)->restore(u,c)).show();}
    private void restore(Uri uri,Container c){new Thread(()->{try(InputStream in=getContentResolver().openInputStream(uri); ZipInputStream zin=new ZipInputStream(new BufferedInputStream(in))){if(in==null)throw new IOException("Fichier illisible"); ZipEntry e; File root=c.getRootDir().getCanonicalFile(); while((e=zin.getNextEntry())!=null){File target=new File(root,e.getName()).getCanonicalFile(); if(!target.getPath().startsWith(root.getPath()+File.separator))throw new IOException("Archive invalide"); if(e.isDirectory()){target.mkdirs();continue;} File parent=target.getParentFile();if(parent!=null)parent.mkdirs();try(OutputStream out=new BufferedOutputStream(new FileOutputStream(target))){byte[] b=new byte[65536];int n;while((n=zin.read(b))!=-1)out.write(b,0,n);}} runOnUiThread(()->Toast.makeText(this,"Restauration terminée",Toast.LENGTH_LONG).show());}catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Restauration échouée : "+e.getMessage(),Toast.LENGTH_LONG).show());}}).start();}
    private void zipDir(File root,File file,File out)throws IOException{try(ZipOutputStream z=new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(out)))){add(root,file,z);}}
    private void add(File root,File f,ZipOutputStream z)throws IOException{String rel=root.toURI().relativize(f.toURI()).getPath();if(f.isDirectory()){if(!rel.isEmpty()){z.putNextEntry(new ZipEntry(rel));z.closeEntry();}File[] fs=f.listFiles();if(fs!=null)for(File x:fs)add(root,x,z);}else{z.putNextEntry(new ZipEntry(rel));try(InputStream in=new BufferedInputStream(new FileInputStream(f))){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)z.write(b,0,n);}z.closeEntry();}}
}
