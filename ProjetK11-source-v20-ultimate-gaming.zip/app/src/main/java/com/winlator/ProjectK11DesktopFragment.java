package com.winlator;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;
import android.app.AlertDialog;
import android.provider.OpenableColumns;
import android.database.Cursor;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.winlator.projectk11.AutoConfig;
import com.winlator.container.Container;
import com.winlator.container.ContainerManager;
import com.winlator.core.FileUtils;
import com.winlator.core.WineUtils;

/** ProjetK11 Windows-style desktop shell. The Winlator engine remains underneath. */
public class ProjectK11DesktopFragment extends Fragment {
    private static final int REQUEST_INSTALLER = 1101;
    private Uri pendingInstallerUri;
    public ProjectK11DesktopFragment() { super(R.layout.projectk11_desktop); }

    @Nullable
    @Override
    public View onCreateView(@NonNull android.view.LayoutInflater inflater,
                             @Nullable android.view.ViewGroup parent,
                             @Nullable Bundle state) {
        View root = super.onCreateView(inflater, parent, state);
        AutoConfig.apply(requireContext());

        final View startMenu = root.findViewById(R.id.k11_start_menu);
        final View cursor = root.findViewById(R.id.k11_cursor);
        final View desktop = root.findViewById(R.id.k11_desktop_root);

        Button start = root.findViewById(R.id.k11_start);
        EditText startSearch = root.findViewById(R.id.k11_start_search);
        Button taskbarSearch = root.findViewById(R.id.k11_search);

        start.setOnClickListener(v -> {
            boolean opening = startMenu.getVisibility() != View.VISIBLE;
            startMenu.setVisibility(opening ? View.VISIBLE : View.GONE);
            if (opening) {
                startSearch.clearFocus();
            } else {
                hideKeyboard(startSearch);
            }
        });

        // The taskbar search is a real text field: tapping it opens the Start menu
        // and immediately requests the Android soft keyboard.
        taskbarSearch.setOnClickListener(v -> {
            startMenu.setVisibility(View.VISIBLE);
            startSearch.setFocusableInTouchMode(true);
            startSearch.requestFocus();
            startSearch.postDelayed(() -> showKeyboard(startSearch), 120);
        });

        // Any tap in the search field explicitly asks for the IME. This makes
        // keyboard behaviour reliable across Android 10-15 and OEM keyboards.
        startSearch.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) v.postDelayed(() -> showKeyboard(v), 80);
        });
        startSearch.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH ||
                    (event != null && event.getKeyCode() == android.view.KeyEvent.KEYCODE_ENTER)) {
                hideKeyboard(v);
                return true;
            }
            return false;
        });

        root.findViewById(R.id.k11_install_pc).setOnClickListener(v -> openFileManager());
        root.findViewById(R.id.k11_games).setOnClickListener(v -> openGames());
        root.findViewById(R.id.k11_containers).setOnClickListener(v -> openContainers());
        root.findViewById(R.id.k11_files).setOnClickListener(v -> openFileManager());
        root.findViewById(R.id.k11_youtube).setOnClickListener(v -> openWeb("https://www.youtube.com/"));
        root.findViewById(R.id.k11_google).setOnClickListener(v -> openWeb("https://www.google.com/"));
        root.findViewById(R.id.k11_chrome).setOnClickListener(v -> openWeb("https://www.google.com/chrome/"));
        root.findViewById(R.id.k11_play_store).setOnClickListener(v -> openPlayStore());
        root.findViewById(R.id.k11_settings).setOnClickListener(v -> openSettings());
        root.findViewById(R.id.k11_start_install_pc).setOnClickListener(v -> { startMenu.setVisibility(View.GONE); openFileManager(); });
        root.findViewById(R.id.k11_start_games).setOnClickListener(v -> { startMenu.setVisibility(View.GONE); openGames(); });
        root.findViewById(R.id.k11_start_files).setOnClickListener(v -> { startMenu.setVisibility(View.GONE); openFileManager(); });
        root.findViewById(R.id.k11_start_settings).setOnClickListener(v -> { startMenu.setVisibility(View.GONE); openSettings(); });
        root.findViewById(R.id.k11_start_ultimate).setOnClickListener(v -> { startMenu.setVisibility(View.GONE); startActivity(new Intent(requireContext(), ProjectK11UltimateActivity.class)); });
        root.findViewById(R.id.k11_start_monitor).setOnClickListener(v -> { startMenu.setVisibility(View.GONE); openSystemMonitor(); });
        root.findViewById(R.id.k11_start_game_center).setOnClickListener(v -> { startMenu.setVisibility(View.GONE); openGameCenter(); });
        root.findViewById(R.id.k11_start_graphics).setOnClickListener(v -> { startMenu.setVisibility(View.GONE); openGraphics(); });
        root.findViewById(R.id.k11_start_backup).setOnClickListener(v -> { startMenu.setVisibility(View.GONE); openBackup(); });
        root.findViewById(R.id.k11_start_components).setOnClickListener(v -> { startMenu.setVisibility(View.GONE); startActivity(new Intent(requireContext(), ProjectK11ComponentManagerActivity.class)); });
        root.findViewById(R.id.k11_start_firefox).setOnClickListener(v -> launchExternal("org.mozilla.firefox", "Firefox"));
        root.findViewById(R.id.k11_start_terminal).setOnClickListener(v -> launchExternal("com.termux", "Terminal Linux"));
        root.findViewById(R.id.k11_start_youtube).setOnClickListener(v -> openWeb("https://www.youtube.com/"));
        root.findViewById(R.id.k11_start_google).setOnClickListener(v -> openWeb("https://www.google.com/"));
        root.findViewById(R.id.k11_start_chrome).setOnClickListener(v -> openWeb("https://www.google.com/chrome/"));
        root.findViewById(R.id.k11_start_play_store).setOnClickListener(v -> { startMenu.setVisibility(View.GONE); hideKeyboard(startSearch); openPlayStore(); });

        // Touch-to-cursor layer: move the Windows-style pointer with the finger.
        desktop.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN || event.getAction() == MotionEvent.ACTION_MOVE) {
                cursor.setX(Math.max(0, event.getX() - 8));
                cursor.setY(Math.max(0, event.getY() - 8));
                return true;
            }
            return false;
        });
        return root;
    }


    private void choosePcInstaller() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "application/octet-stream", "application/x-msdownload",
                "application/x-msi", "application/x-msdos-program"
        });
        startActivityForResult(intent, REQUEST_INSTALLER);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_INSTALLER || resultCode != android.app.Activity.RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        String name = getDisplayName(uri);
        if (name == null) name = "programme.exe";
        String lower = name.toLowerCase(java.util.Locale.US);
        if (!(lower.endsWith(".exe") || lower.endsWith(".msi"))) {
            Toast.makeText(requireContext(), "Sélectionne un fichier .exe ou .msi", Toast.LENGTH_LONG).show();
            return;
        }
        pendingInstallerUri = uri;
        ContainerManager cm = new ContainerManager(requireContext());
        java.util.ArrayList<Container> containers = cm.getContainers();
        if (containers.isEmpty()) {
            Toast.makeText(requireContext(), "Crée d'abord un conteneur Windows.", Toast.LENGTH_LONG).show();
            openContainers();
            return;
        }
        String[] names = new String[containers.size()];
        for (int i = 0; i < containers.size(); i++) names[i] = containers.get(i).getName();
        new AlertDialog.Builder(requireContext())
                .setTitle("Installer avec ProjetK11")
                .setMessage("Choisis le conteneur Windows pour « " + name + " ».")
                .setItems(names, (dialog, which) -> installPcFile(containers.get(which), uri, name))
                .setNegativeButton("Annuler", null)
                .show();
    }

    private String getDisplayName(Uri uri) {
        try (Cursor cursor = requireContext().getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) return cursor.getString(0);
        } catch (Throwable ignored) {}
        return uri.getLastPathSegment();
    }

    private void installPcFile(Container container, Uri uri, String originalName) {
        new Thread(() -> {
            try {
                File downloads = new File(container.getUserDir(), "Downloads");
                if (!downloads.exists() && !downloads.mkdirs()) throw new java.io.IOException("Downloads");
                String safeName = originalName.replaceAll("[^a-zA-Z0-9._ -]", "_");
                File installer = new File(downloads, safeName);
                try (java.io.InputStream in = requireContext().getContentResolver().openInputStream(uri);
                     java.io.OutputStream out = new java.io.BufferedOutputStream(new java.io.FileOutputStream(installer))) {
                    if (in == null) throw new java.io.IOException("Impossible de lire le fichier");
                    byte[] buffer = new byte[1024 * 64];
                    int read;
                    while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
                }
                File desktop = new File(container.getUserDir(), "Desktop");
                if (!desktop.exists()) desktop.mkdirs();
                String base = safeName.replaceFirst("(?i)\\.(exe|msi)$", "");
                File shortcut = new File(desktop, base + ".desktop");
                String dosPath = WineUtils.unixToDOSPath(installer.getPath(), container);
                String content = "[Desktop Entry]\n" +
                        "Name=" + base.replace("\n", " ") + "\n" +
                        "Exec=wine \"" + dosPath + "\"\n" +
                        "Type=Application\n" +
                        "Terminal=false\n" +
                        "Categories=Game;Utility;\n" +
                        "[Extra Data]\n" +
                        "projectk11Installer=true\n";
                FileUtils.writeString(shortcut, content);
                requireActivity().runOnUiThread(() -> {
                    Toast.makeText(requireContext(), "Installateur copié. Le raccourci a été créé.", Toast.LENGTH_LONG).show();
                    Intent launch = new Intent(requireContext(), XServerDisplayActivity.class);
                    launch.putExtra("container_id", container.id);
                    launch.putExtra("exec_path", installer.getPath());
                    startActivity(launch);
                });
            } catch (Throwable e) {
                requireActivity().runOnUiThread(() -> Toast.makeText(requireContext(), "Installation impossible : " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    private void showKeyboard(View view) {
        InputMethodManager imm = (InputMethodManager) requireContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT);
    }

    private void hideKeyboard(View view) {
        InputMethodManager imm = (InputMethodManager) requireContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        view.clearFocus();
    }

    private void openFileManager() {
        startActivity(new Intent(requireContext(), ProjectK11FileManagerActivity.class));
    }

    private void openGames() {
        ((MainActivity) requireActivity()).showFragment(new ShortcutsFragment());
    }

    private void openContainers() {
        ((MainActivity) requireActivity()).showFragment(new ContainersFragment());
    }

    private void openSystemMonitor() {
        startActivity(new Intent(requireContext(), ProjectK11SystemMonitorActivity.class));
    }

    private void openGameCenter() { startActivity(new Intent(requireContext(), ProjectK11GameCenterActivity.class)); }
    private void openGraphics() { startActivity(new Intent(requireContext(), ProjectK11GraphicsActivity.class)); }
    private void openBackup() { startActivity(new Intent(requireContext(), ProjectK11BackupActivity.class)); }

    private void openSettings() {
        ((MainActivity) requireActivity()).showFragment(new SettingsFragment());
    }

    private void openWeb(String url) {
        Intent i = new Intent(requireContext(), ProjectK11BrowserActivity.class);
        i.putExtra("url", url);
        startActivity(i);
    }

    private void openPlayStore() {
        try {
            Intent launch = requireContext().getPackageManager().getLaunchIntentForPackage("com.android.vending");
            if (launch != null) {
                startActivity(launch);
                return;
            }
        } catch (Throwable ignored) {
        }
        // If Google Play Store is not installed, open the official Play Store web page.
        openWeb("https://play.google.com/store");
    }

    private void launchExternal(String packageName, String label) {
        try {
            Intent launch = requireContext().getPackageManager().getLaunchIntentForPackage(packageName);
            if (launch != null) {
                startActivity(launch);
            } else {
                Toast.makeText(requireContext(), label + " n'est pas installé sur Android.", Toast.LENGTH_SHORT).show();
            }
        } catch (Throwable e) {
            Toast.makeText(requireContext(), "Impossible d'ouvrir " + label, Toast.LENGTH_SHORT).show();
        }
    }
}
