package com.winlator;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.winlator.box64.Box64Preset;
import com.winlator.container.Container;
import com.winlator.container.ContainerManager;
import com.winlator.container.DXWrappers;
import com.winlator.container.GraphicsDrivers;
import com.winlator.container.Shortcut;
import com.winlator.inputcontrols.ControlsProfile;
import com.winlator.inputcontrols.InputControlsManager;
import com.winlator.projectk11.AutoInputProfile;
import com.winlator.projectk11.GameProfileManager;
import com.winlator.projectk11.SmartOptimizer;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Real game library built on the existing Winlator shortcut system. */
public class ProjectK11GameCenterActivity extends AppCompatActivity {
    private final ArrayList<Shortcut> games = new ArrayList<>();
    private LinearLayout list;
    private EditText search;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.projectk11_game_center);
        list = findViewById(R.id.k11_game_list);
        search = findViewById(R.id.k11_game_search);
        findViewById(R.id.k11_game_refresh).setOnClickListener(v -> loadGames());
        findViewById(R.id.k11_game_close).setOnClickListener(v -> finish());
        search.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int before, int count) { render(s.toString()); }
            public void afterTextChanged(android.text.Editable e) {}
        });
        loadGames();
    }

    @Override protected void onResume() { super.onResume(); if (list != null) loadGames(); }

    private void loadGames() {
        games.clear();
        ContainerManager manager = new ContainerManager(this);
        for (Container c : manager.getContainers()) scan(c, new File(c.getUserDir(), "Desktop"), 0);
        render(search == null ? "" : search.getText().toString());
    }

    private void scan(Container c, File dir, int depth) {
        if (depth > 4 || dir == null || !dir.isDirectory()) return;
        File[] files = dir.listFiles();
        if (files == null) return;
        for (File f : files) {
            if (f.isDirectory()) scan(c, f, depth + 1);
            else if (f.getName().endsWith(".desktop")) games.add(new Shortcut(c, f));
        }
    }

    private void render(String filter) {
        list.removeAllViews();
        String q = filter == null ? "" : filter.trim().toLowerCase(Locale.US);
        int shown = 0;
        for (Shortcut s : games) {
            if (!q.isEmpty() && !s.name.toLowerCase(Locale.US).contains(q) && !s.container.getName().toLowerCase(Locale.US).contains(q)) continue;
            shown++;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(14, 10, 14, 10);
            row.setBackgroundResource(com.winlator.R.drawable.k11_icon_bg);

            TextView title = new TextView(this);
            title.setText(s.name + "\n" + s.container.getName());
            title.setTextColor(0xFFFFFFFF);
            title.setTextSize(17);
            title.setGravity(android.view.Gravity.CENTER_VERTICAL);
            row.addView(title, new LinearLayout.LayoutParams(0, 72, 1));

            Button play = new Button(this);
            play.setText("Jouer");
            play.setOnClickListener(v -> launch(s));
            row.addView(play, new LinearLayout.LayoutParams(110, 64));

            Button optimize = new Button(this);
            optimize.setText("Optimiser");
            optimize.setOnClickListener(v -> { SmartOptimizer.optimizeGame(this, s); Toast.makeText(this, "Jeu optimisé", Toast.LENGTH_SHORT).show(); loadGames(); });
            row.addView(optimize, new LinearLayout.LayoutParams(120, 64));

            Button profile = new Button(this);
            profile.setText("Profil");
            profile.setOnClickListener(v -> editProfile(s));
            row.addView(profile, new LinearLayout.LayoutParams(110, 64));
            list.addView(row, new LinearLayout.LayoutParams(-1, -2));
            LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) row.getLayoutParams();
            lp.setMargins(0, 0, 0, 10); row.setLayoutParams(lp);
        }
        if (shown == 0) {
            TextView empty = new TextView(this);
            empty.setText(games.isEmpty() ? "Aucun jeu installé. Utilise « Installer PC » puis crée/choisis un raccourci." : "Aucun résultat.");
            empty.setTextColor(0xFFE8EAF0); empty.setTextSize(18); empty.setPadding(20, 30, 20, 30);
            list.addView(empty);
        }
    }

    private void launch(Shortcut s) {
        Intent i = new Intent(this, XServerDisplayActivity.class);
        i.putExtra("container_id", s.container.id);
        i.putExtra("shortcut_path", s.file.getPath());
        GameProfileManager.markLaunched(this, s);
        startActivity(i);
    }

    private void editProfile(Shortcut s) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL); box.setPadding(20, 4, 20, 4);

        InputControlsManager icm = new InputControlsManager(this);
        ArrayList<ControlsProfile> profiles = icm.getProfiles(true);
        ArrayList<String> profileNames = new ArrayList<>();
        profileNames.add("Automatique");
        for (ControlsProfile p : profiles) profileNames.add(p.getName());
        Spinner controls = spinner(profileNames);
        String currentControls = s.getExtra("controls_profile", "");
        int selected = 0;
        for (int i = 0; i < profiles.size(); i++) if (profiles.get(i).getName().equals(currentControls)) selected = i + 1;
        controls.setSelection(selected);
        box.addView(label("Contrôles")); box.addView(controls);

        ArrayList<String> presets = new ArrayList<>();
        presets.add("Performance"); presets.add("Équilibré"); presets.add("Stabilité"); presets.add("Conservateur");
        Spinner box64 = spinner(presets);
        String currentPreset = s.getExtra("box64Preset", s.container.getBox64Preset());
        box64.setSelection(presetIndex(currentPreset));
        box.addView(label("Box64")); box.addView(box64);

        ArrayList<String> drivers = new ArrayList<>();
        drivers.add("Turnip + Gladio"); drivers.add("Vortek + Gladio"); drivers.add("Vortek + VirGL");
        Spinner graphics = spinner(drivers);
        String currentGraphics = s.getExtra("graphicsDriver", s.container.getGraphicsDriver());
        graphics.setSelection(graphicsIndex(currentGraphics));
        box.addView(label("Graphismes")); box.addView(graphics);

        ArrayList<String> dx = new ArrayList<>(); dx.add("DXVK"); dx.add("WineD3D");
        Spinner dxw = spinner(dx);
        dxw.setSelection("wined3d".equals(s.getExtra("dxwrapper", s.container.getDXWrapper())) ? 1 : 0);
        box.addView(label("DirectX")); box.addView(dxw);

        ArrayList<String> sizes = new ArrayList<>(); sizes.add("1280x720"); sizes.add("1600x900"); sizes.add("1920x1080");
        Spinner size = spinner(sizes);
        String currentSize = s.getExtra("screenSize", s.container.getScreenSize());
        for (int i = 0; i < sizes.size(); i++) if (sizes.get(i).equals(currentSize)) size.setSelection(i);
        box.addView(label("Résolution")); box.addView(size);

        new AlertDialog.Builder(this).setTitle("Profil — " + s.name).setView(box)
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Enregistrer", (d, w) -> {
                String cp = controls.getSelectedItemPosition() == 0 ? "" : profiles.get(controls.getSelectedItemPosition()-1).getName();
                s.putExtra("controls_profile", cp.isEmpty() ? null : cp);
                s.putExtra("box64Preset", presetId((String) box64.getSelectedItem()));
                s.putExtra("graphicsDriver", graphicsId(graphics.getSelectedItemPosition()));
                s.putExtra("dxwrapper", dxw.getSelectedItemPosition() == 1 ? DXWrappers.WINED3D : DXWrappers.DXVK);
                s.putExtra("screenSize", (String) size.getSelectedItem());
                s.saveData();
                Toast.makeText(this, "Profil enregistré", Toast.LENGTH_SHORT).show();
            }).show();
    }

    private TextView label(String t) { TextView v = new TextView(this); v.setText(t); v.setTextColor(0xFFE8EAF0); v.setTextSize(14); v.setPadding(0, 10, 0, 4); return v; }
    private Spinner spinner(List<String> items) { Spinner s = new Spinner(this); s.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items)); return s; }
    private int presetIndex(String id) { if (Box64Preset.PERFORMANCE.equals(id)) return 0; if (Box64Preset.STABILITY.equals(id)) return 2; if (Box64Preset.CONSERVATIVE.equals(id)) return 3; return 1; }
    private String presetId(String name) { if (name.startsWith("Performance")) return Box64Preset.PERFORMANCE; if (name.startsWith("Stabilité")) return Box64Preset.STABILITY; if (name.startsWith("Conservateur")) return Box64Preset.CONSERVATIVE; return Box64Preset.INTERMEDIATE; }
    private int graphicsIndex(String id) { if (id != null && id.startsWith(GraphicsDrivers.TURNIP)) return 0; if (id != null && id.contains(GraphicsDrivers.VIRGL)) return 2; return 1; }
    private String graphicsId(int i) { if (i == 0) return GraphicsDrivers.TURNIP+","+GraphicsDrivers.GLADIO; if (i == 2) return GraphicsDrivers.VORTEK+","+GraphicsDrivers.VIRGL; return GraphicsDrivers.VORTEK+","+GraphicsDrivers.GLADIO; }
}
