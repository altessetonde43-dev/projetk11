package com.winlator;

import android.content.Context;
import com.winlator.core.RuntimeAssets;
import java.io.File;

public final class ProjectK11Runtime {
    private ProjectK11Runtime() {}
    public static final String PREF_URL = "projectk11_runtime_url";
    public static final String DEFAULT_URL = "https://github.com/altessetonde43-dev/projetk11/releases/download/Projetk11/ProjetK11-runtime-v1.zip";
    public static boolean isReady(Context context) {
        return RuntimeAssets.exists(context, "rootfs.tzst") && RuntimeAssets.exists(context, "rootfs_patches.tzst") && RuntimeAssets.exists(context, "container_pattern.tzst");
    }
    public static File archive(Context context) { return new File(context.getCacheDir(), "ProjetK11-runtime-v1.zip"); }
}
