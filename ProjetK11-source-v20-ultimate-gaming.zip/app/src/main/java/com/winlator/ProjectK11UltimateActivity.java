package com.winlator;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.winlator.container.Container;
import com.winlator.container.ContainerManager;
import com.winlator.container.Shortcut;
import com.winlator.projectk11.DiagnosticsManager;
import com.winlator.projectk11.GameBooster;
import com.winlator.projectk11.SmartOptimizer;
import java.io.File;
import java.util.ArrayList;

/** Unified V15/V16/V17 control center. */
public class ProjectK11UltimateActivity extends AppCompatActivity {
    private TextView status;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.projectk11_ultimate);
        status = findViewById(R.id.k11_ultimate_status);
        findViewById(R.id.k11_ultimate_games).setOnClickListener(v -> startActivity(new Intent(this, ProjectK11GameCenterActivity.class)));
        findViewById(R.id.k11_ultimate_graphics).setOnClickListener(v -> startActivity(new Intent(this, ProjectK11GraphicsActivity.class)));
        findViewById(R.id.k11_ultimate_components).setOnClickListener(v -> startActivity(new Intent(this, ProjectK11ComponentManagerActivity.class)));
        findViewById(R.id.k11_ultimate_backup).setOnClickListener(v -> startActivity(new Intent(this, ProjectK11BackupActivity.class)));
        findViewById(R.id.k11_ultimate_monitor).setOnClickListener(v -> startActivity(new Intent(this, ProjectK11SystemMonitorActivity.class)));
        findViewById(R.id.k11_ultimate_booster).setOnClickListener(v -> boosterDialog());
        findViewById(R.id.k11_ultimate_optimize).setOnClickListener(v -> optimizeAll());
        findViewById(R.id.k11_ultimate_diagnostic).setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Diagnostic").setMessage(DiagnosticsManager.run(this)).setPositiveButton("OK", null).show());
        findViewById(R.id.k11_ultimate_close).setOnClickListener(v -> finish());
        refresh();
    }
    private void refresh() {
        int games = 0, containers = 0;
        try {
            ContainerManager cm = new ContainerManager(this);
            containers = cm.getContainers().size();
            for (Container c : cm.getContainers()) games += countShortcuts(new File(c.getUserDir(), "Desktop"), 0);
        } catch (Throwable ignored) {}
        status.setText("Runtime : " + (ProjectK11Runtime.isReady(this) ? "PRÊT" : "À TÉLÉCHARGER") +
                "\nConteneurs : " + containers + "   •   Jeux : " + games +
                "\nGame Booster : " + (GameBooster.enabled(this) ? "ACTIF" : "DÉSACTIVÉ") +
                "\nArchitecture : " + (android.os.Build.SUPPORTED_ABIS.length > 0 ? android.os.Build.SUPPORTED_ABIS[0] : "inconnue"));
    }
    private int countShortcuts(File dir, int depth) {
        if (dir == null || depth > 4 || !dir.isDirectory()) return 0;
        File[] fs = dir.listFiles(); if (fs == null) return 0; int n = 0;
        for (File f : fs) n += f.isDirectory() ? countShortcuts(f, depth + 1) : (f.getName().endsWith(".desktop") ? 1 : 0);
        return n;
    }
    private void optimizeAll() {
        new Thread(() -> {
            try {
                ContainerManager cm = new ContainerManager(this);
                int count = 0;
                for (Container c : cm.getContainers()) {
                    SmartOptimizer.optimizeContainer(this, c);
                    count += optimizeDir(c, new File(c.getUserDir(), "Desktop"), 0);
                }
                final int done = count;
                runOnUiThread(() -> { status.setText(DiagnosticsManager.run(this) + "\nJeux optimisés : " + done); });
            } catch (Throwable e) { runOnUiThread(() -> status.setText("Optimisation impossible : " + e.getMessage())); }
        }, "ProjetK11-Optimizer").start();
    }
    private int optimizeDir(Container c, File dir, int depth) {
        if (dir == null || depth > 4 || !dir.isDirectory()) return 0;
        File[] fs = dir.listFiles(); if (fs == null) return 0; int n = 0;
        for (File f : fs) { if (f.isDirectory()) n += optimizeDir(c, f, depth + 1); else if (f.getName().endsWith(".desktop")) { try { SmartOptimizer.optimizeGame(this, new Shortcut(c, f)); n++; } catch (Throwable ignored) {} } }
        return n;
    }
    private void boosterDialog() {
        final boolean[] enabled = { GameBooster.enabled(this) };
        final boolean[] hud = { GameBooster.hud(this) };
        String[] items = {"Activer Game Booster", "Afficher HUD"};
        boolean[] checked = {enabled[0], hud[0]};
        new AlertDialog.Builder(this).setTitle("Game Booster").setMultiChoiceItems(items, checked, (d, which, isChecked) -> { if (which == 0) enabled[0] = isChecked; else hud[0] = isChecked; })
                .setPositiveButton("Enregistrer", (d,w) -> { GameBooster.set(this, enabled[0], hud[0]); refresh(); }).setNegativeButton("Annuler", null).show();
    }
    @Override protected void onResume() { super.onResume(); refresh(); }
}
