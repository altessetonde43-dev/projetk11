package com.winlator.core;

import android.content.Context;
import java.io.*;

/** Accesses heavy runtime payloads downloaded after APK installation, with asset fallback. */
public final class RuntimeAssets {
    private RuntimeAssets() {}
    public static File root(Context context) {
        File dir = new File(context.getFilesDir(), "runtime_assets");
        if (!dir.isDirectory()) dir.mkdirs();
        return dir;
    }
    public static File resolve(Context context, String path) {
        return new File(root(context), path);
    }
    public static boolean exists(Context context, String path) {
        return resolve(context, path).exists();
    }
    public static InputStream open(Context context, String path) throws IOException {
        File f = resolve(context, path);
        if (f.isFile()) return new BufferedInputStream(new FileInputStream(f));
        return context.getAssets().open(path);
    }
    public static String[] list(Context context, String path) throws IOException {
        File f = resolve(context, path);
        if (f.isDirectory()) {
            String[] list = f.list();
            return list == null ? new String[0] : list;
        }
        return context.getAssets().list(path);
    }
    public static long length(Context context, String path) throws IOException {
        File f = resolve(context, path);
        if (f.isFile()) return f.length();
        try (InputStream in = context.getAssets().open(path)) {
            return in.available();
        }
    }
}
