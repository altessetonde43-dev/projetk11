package com.winlator;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import com.winlator.core.HttpUtils;
import com.winlator.core.RuntimeAssets;
import java.io.*;
import java.util.zip.*;

/** Downloads the heavy runtime after the small APK is installed. */
public class ProjectK11ComponentManagerActivity extends AppCompatActivity {
    private static final int PICK_ZIP = 4401;
    private TextView status; private ProgressBar progress; private EditText url;
    @Override protected void onCreate(Bundle b){ super.onCreate(b); setContentView(R.layout.projectk11_components);
        status=findViewById(R.id.k11_runtime_status); progress=findViewById(R.id.k11_runtime_progress); url=findViewById(R.id.k11_runtime_url);
        String saved=getSharedPreferences("projectk11",0).getString(ProjectK11Runtime.PREF_URL,ProjectK11Runtime.DEFAULT_URL); if(saved==null||saved.trim().isEmpty()){saved=ProjectK11Runtime.DEFAULT_URL; getSharedPreferences("projectk11",0).edit().putString(ProjectK11Runtime.PREF_URL,saved).apply();} url.setText(saved); refresh();
        findViewById(R.id.k11_runtime_download).setOnClickListener(v->downloadFromUrl());
        findViewById(R.id.k11_runtime_file).setOnClickListener(v->pickZip());
        findViewById(R.id.k11_runtime_save_url).setOnClickListener(v->{getSharedPreferences("projectk11",0).edit().putString(ProjectK11Runtime.PREF_URL,url.getText().toString().trim()).apply(); Toast.makeText(this,"URL enregistrée",Toast.LENGTH_SHORT).show();});
        findViewById(R.id.k11_runtime_close).setOnClickListener(v->finish());
    }
    private void refresh(){ boolean ok=ProjectK11Runtime.isReady(this); status.setText(ok?"✅ Données principales installées — ProjetK11 est prêt.":"⚠️ Les données principales ne sont pas encore installées. L'APK reste léger jusqu'à leur téléchargement."); progress.setProgress(ok?100:0); }
    private void downloadFromUrl(){ String u=url.getText().toString().trim(); if(u.isEmpty()){new AlertDialog.Builder(this).setTitle("URL nécessaire").setMessage("Héberge le fichier ProjetK11-runtime-v1.zip sur ton serveur/GitHub, puis colle son URL ici.").setPositiveButton("OK",null).show();return;} File out=ProjectK11Runtime.archive(this); status.setText("Téléchargement du runtime…"); HttpUtils.download(this,u,out,ok->{ if(ok) installArchive(out); else {status.setText("❌ Téléchargement échoué"); Toast.makeText(this,"Téléchargement échoué",Toast.LENGTH_LONG).show();}}); }
    private void pickZip(){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/zip"); startActivityForResult(i,PICK_ZIP); }
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d); if(r==PICK_ZIP&&c==RESULT_OK&&d!=null&&d.getData()!=null){ new Thread(()->{try{File out=ProjectK11Runtime.archive(this); try(InputStream in=getContentResolver().openInputStream(d.getData()); OutputStream o=new FileOutputStream(out)){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)o.write(b,0,n);} runOnUiThread(()->installArchive(out));}catch(Exception e){runOnUiThread(()->Toast.makeText(this,"ZIP illisible : "+e.getMessage(),Toast.LENGTH_LONG).show());}}).start();}}
    private void installArchive(File zip){ new Thread(()->{try{File root=RuntimeAssets.root(this); File tmp=new File(getFilesDir(),"runtime_assets.tmp"); if(tmp.exists())delete(tmp); tmp.mkdirs(); try(ZipInputStream zin=new ZipInputStream(new BufferedInputStream(new FileInputStream(zip)))){ZipEntry e; while((e=zin.getNextEntry())!=null){String name=e.getName().replace('\\','/'); if(name.startsWith("/")||name.contains("../"))throw new IOException("Archive invalide"); File target=new File(tmp,name); if(e.isDirectory()){target.mkdirs();continue;} File parent=target.getParentFile();if(parent!=null)parent.mkdirs();try(OutputStream out=new BufferedOutputStream(new FileOutputStream(target))){byte[] b=new byte[65536];int n;while((n=zin.read(b))!=-1)out.write(b,0,n);}}} if(!new File(tmp,"rootfs.tzst").isFile())throw new IOException("rootfs.tzst manquant"); if(root.exists())delete(root); if(!tmp.renameTo(root))throw new IOException("Installation impossible"); zip.delete(); runOnUiThread(()->{refresh(); Toast.makeText(this,"Données ProjetK11 installées",Toast.LENGTH_LONG).show();});}catch(Exception e){runOnUiThread(()->{status.setText("❌ Installation échouée"); Toast.makeText(this,"Installation échouée : "+e.getMessage(),Toast.LENGTH_LONG).show();});}}).start(); }
    private static void delete(File f){ if(f.isDirectory()){File[] xs=f.listFiles();if(xs!=null)for(File x:xs)delete(x);} f.delete(); }
}
