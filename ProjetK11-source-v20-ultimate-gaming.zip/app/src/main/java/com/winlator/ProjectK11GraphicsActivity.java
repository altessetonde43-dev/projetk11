package com.winlator;

import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.winlator.box64.Box64Preset;
import com.winlator.container.Container;
import com.winlator.container.ContainerManager;
import com.winlator.container.DXWrappers;
import com.winlator.container.GraphicsDrivers;

import java.util.ArrayList;

/** Quick graphics/performance center using the real container settings. */
public class ProjectK11GraphicsActivity extends AppCompatActivity {
    private ArrayList<Container> containers;
    private Spinner containerSpinner, vulkanSpinner, openglSpinner, dxSpinner, boxSpinner, hudSpinner;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state); setContentView(R.layout.projectk11_graphics);
        ContainerManager cm = new ContainerManager(this); containers = cm.getContainers();
        containerSpinner = findViewById(R.id.k11_graphics_container); vulkanSpinner = findViewById(R.id.k11_graphics_vulkan);
        openglSpinner = findViewById(R.id.k11_graphics_opengl); dxSpinner = findViewById(R.id.k11_graphics_dx); boxSpinner = findViewById(R.id.k11_graphics_box64); hudSpinner = findViewById(R.id.k11_graphics_hud);
        ArrayList<String> names = new ArrayList<>(); for (Container c: containers) names.add(c.getName()); if (names.isEmpty()) names.add("Aucun conteneur");
        set(containerSpinner, names);
        set(vulkanSpinner, list("Turnip", "Vortek")); set(openglSpinner, list("Gladio", "VirGL", "Zink")); set(dxSpinner, list("DXVK", "WineD3D"));
        set(boxSpinner, list("Performance", "Équilibré", "Stabilité", "Conservateur")); set(hudSpinner, list("Désactivé", "Simple", "Complet"));
        containerSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){ public void onNothingSelected(android.widget.AdapterView<?> p){} public void onItemSelected(android.widget.AdapterView<?> p, android.view.View v,int pos,long id){load(pos);} });
        findViewById(R.id.k11_graphics_save).setOnClickListener(v -> save()); findViewById(R.id.k11_graphics_auto).setOnClickListener(v -> { if(!containers.isEmpty()){ com.winlator.projectk11.AutoConfig.optimize(this, containers.get(containerSpinner.getSelectedItemPosition())); load(containerSpinner.getSelectedItemPosition()); Toast.makeText(this,"Optimisation automatique appliquée",Toast.LENGTH_SHORT).show(); }});
        findViewById(R.id.k11_graphics_close).setOnClickListener(v -> finish());
        if(!containers.isEmpty()) load(0);
    }
    private ArrayList<String> list(String... a){ArrayList<String> x=new ArrayList<>(); for(String s:a)x.add(s); return x;}
    private void set(Spinner s, ArrayList<String> a){s.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,a));}
    private void load(int pos){ if(pos<0||pos>=containers.size())return; Container c=containers.get(pos); String[] g=GraphicsDrivers.parseIdentifiers(c.getGraphicsDriver()); vulkanSpinner.setSelection(g[0].equals(GraphicsDrivers.TURNIP)?0:1); openglSpinner.setSelection(g[1].equals(GraphicsDrivers.GLADIO)?0:g[1].equals(GraphicsDrivers.VIRGL)?1:2); dxSpinner.setSelection(c.getDXWrapper().equals(DXWrappers.WINED3D)?1:0); boxSpinner.setSelection(box(c.getBox64Preset())); hudSpinner.setSelection(c.getHUDMode()); }
    private int box(String s){if(Box64Preset.PERFORMANCE.equals(s))return 0;if(Box64Preset.STABILITY.equals(s))return 2;if(Box64Preset.CONSERVATIVE.equals(s))return 3;return 1;}
    private void save(){if(containers.isEmpty())return; Container c=containers.get(containerSpinner.getSelectedItemPosition()); String vk=vulkanSpinner.getSelectedItemPosition()==0?GraphicsDrivers.TURNIP:GraphicsDrivers.VORTEK; String gl=openglSpinner.getSelectedItemPosition()==0?GraphicsDrivers.GLADIO:openglSpinner.getSelectedItemPosition()==1?GraphicsDrivers.VIRGL:GraphicsDrivers.ZINK; c.setGraphicsDriver(vk+","+gl); c.setDXWrapper(dxSpinner.getSelectedItemPosition()==1?DXWrappers.WINED3D:DXWrappers.DXVK); String[] p={Box64Preset.PERFORMANCE,Box64Preset.INTERMEDIATE,Box64Preset.STABILITY,Box64Preset.CONSERVATIVE}; c.setBox64Preset(p[boxSpinner.getSelectedItemPosition()]); c.setHUDMode((byte)hudSpinner.getSelectedItemPosition()); c.saveData(); Toast.makeText(this,"Profil graphique enregistré pour "+c.getName(),Toast.LENGTH_SHORT).show();}
}
