package com.winlator;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AccelerateDecelerateInterpolator;

import java.util.Random;

/** Animated ProjectK11 startup screen. Kept lightweight: all effects are drawn in real time. */
public class ProjectK11SplashActivity extends Activity {
    private static final long SPLASH_DURATION_MS = 4200L;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean opened = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setNavigationBarColor(Color.BLACK);
        setContentView(new SplashView());

        handler.postDelayed(new Runnable() {
            @Override public void run() { openMain(); }
        }, SPLASH_DURATION_MS);
    }

    private void openMain() {
        if (opened || isFinishing()) return;
        opened = true;
        startActivity(new Intent(this, MainActivity.class));
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        finish();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    private final class SplashView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        private final Random random = new Random(11);
        private final float[] px = new float[70];
        private final float[] py = new float[70];
        private final float[] ps = new float[70];
        private final ValueAnimator animator;
        private float progress;

        SplashView() {
            super(ProjectK11SplashActivity.this);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            for (int i = 0; i < px.length; i++) {
                px[i] = random.nextFloat();
                py[i] = random.nextFloat();
                ps[i] = 0.5f + random.nextFloat() * 2.5f;
            }
            animator = ValueAnimator.ofFloat(0f, 1f);
            animator.setDuration(SPLASH_DURATION_MS);
            animator.setInterpolator(new AccelerateDecelerateInterpolator());
            animator.addUpdateListener(animation -> {
                progress = (Float) animation.getAnimatedValue();
                invalidate();
            });
            animator.start();
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            final float w = getWidth();
            final float h = getHeight();
            final float cx = w * 0.5f;
            final float cy = h * 0.44f;

            canvas.drawColor(Color.rgb(2, 4, 12));

            // Soft blue/orange energy haze.
            paint.setShader(new RadialGradient(cx - w * .12f, cy, w * .55f,
                    new int[]{0x6640A9FF, 0x22115BFF, 0x00000000}, null, Shader.TileMode.CLAMP));
            canvas.drawRect(0, 0, w, h, paint);
            paint.setShader(new RadialGradient(cx + w * .18f, cy + h * .04f, w * .42f,
                    new int[]{0x44FF8A18, 0x18005280, 0x00000000}, null, Shader.TileMode.CLAMP));
            canvas.drawRect(0, 0, w, h, paint);
            paint.setShader(null);

            // Animated particles.
            for (int i = 0; i < px.length; i++) {
                float x = px[i] * w;
                float y = (py[i] + progress * (0.08f + (i % 5) * .012f)) % 1f * h;
                int alpha = (int)(70 + 150 * (0.5f + 0.5f * (float)Math.sin(progress * 14 + i)));
                paint.setColor((i & 1) == 0 ? Color.argb(alpha, 50, 185, 255) : Color.argb(alpha, 255, 145, 35));
                paint.setShadowLayer(8f, 0, 0, paint.getColor());
                canvas.drawCircle(x, y, ps[i], paint);
                paint.clearShadowLayer();
            }

            float reveal = Math.min(1f, progress * 1.55f);
            float ring = Math.min(w, h) * (0.20f + 0.025f * (float)Math.sin(progress * 10));
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(4f);
            paint.setShader(new LinearGradient(cx - ring, cy, cx + ring, cy,
                    new int[]{0xFF18AFFF, 0xFF7DE8FF, 0xFFFF8A1C}, null, Shader.TileMode.CLAMP));
            paint.setShadowLayer(24f, 0, 0, 0xFF20B8FF);
            canvas.drawCircle(cx, cy, ring * reveal, paint);
            paint.clearShadowLayer();
            paint.setShader(null);

            // Sweeping energy arcs.
            paint.setStrokeWidth(2.5f);
            paint.setColor(0xFF2CC8FF);
            paint.setShadowLayer(16f, 0, 0, 0xFF1EAFFF);
            canvas.drawArc(cx - ring * 1.45f, cy - ring * .62f, cx + ring * 1.45f, cy + ring * .62f,
                    -25 + progress * 360, 105, false, paint);
            paint.setColor(0xFFFF8A1C);
            paint.setShadowLayer(16f, 0, 0, 0xFFFF6A00);
            canvas.drawArc(cx - ring * 1.45f, cy - ring * .62f, cx + ring * 1.45f, cy + ring * .62f,
                    155 + progress * 360, 82, false, paint);
            paint.clearShadowLayer();
            paint.setStyle(Paint.Style.FILL);

            // Main title.
            textPaint.setTypeface(android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD));
            textPaint.setTextAlign(Paint.Align.CENTER);
            textPaint.setTextSize(Math.min(w * .115f, 82f));
            textPaint.setShader(new LinearGradient(cx - w * .32f, cy, cx + w * .32f, cy,
                    new int[]{0xFF5BD9FF, 0xFFFFFFFF, 0xFFFFA126}, null, Shader.TileMode.CLAMP));
            textPaint.setShadowLayer(28f, 0, 0, 0xFF18AFFF);
            canvas.drawText("PROJETK11", cx, cy + textPaint.getTextSize() * .28f, textPaint);
            textPaint.clearShadowLayer();
            textPaint.setShader(null);

            // Creator credit animates in after the title.
            float creditAlpha = Math.max(0f, Math.min(1f, (progress - .42f) * 2.4f));
            textPaint.setAlpha((int)(creditAlpha * 255));
            textPaint.setTextSize(Math.min(w * .038f, 28f));
            textPaint.setLetterSpacing(.12f);
            textPaint.setColor(Color.WHITE);
            textPaint.setShadowLayer(12f, 0, 0, 0xFF2CAEFF);
            canvas.drawText("ŒUVRE DE KEVIN ALTESSE", cx, cy + ring * .92f, textPaint);
            textPaint.clearShadowLayer();
            textPaint.setAlpha(255);
            textPaint.setLetterSpacing(0f);

            // Loading line.
            float barW = Math.min(w * .58f, 620f);
            float barY = h * .86f;
            paint.setColor(0x3320B9FF);
            canvas.drawRoundRect(cx - barW / 2, barY, cx + barW / 2, barY + 7, 6, 6, paint);
            paint.setShader(new LinearGradient(cx - barW / 2, barY, cx + barW / 2, barY,
                    new int[]{0xFF1BC8FF, 0xFF6EE7FF, 0xFFFF8A1C}, null, Shader.TileMode.CLAMP));
            paint.setShadowLayer(12f, 0, 0, 0xFF18B9FF);
            canvas.drawRoundRect(cx - barW / 2, barY, cx - barW / 2 + barW * Math.min(1f, progress * 1.15f), barY + 7, 6, 6, paint);
            paint.clearShadowLayer();
            paint.setShader(null);
        }
    }
}
