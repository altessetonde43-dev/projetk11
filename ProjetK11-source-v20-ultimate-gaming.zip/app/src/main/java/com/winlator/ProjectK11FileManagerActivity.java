package com.winlator;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.winlator.container.Container;
import com.winlator.container.ContainerManager;
import com.winlator.core.FileUtils;
import com.winlator.core.WineUtils;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Locale;

/**
 * In-app Android storage browser. The user grants ProjetK11 access to one storage
 * folder through the Android Storage Access Framework; the app then browses that
 * folder without sending the user back to the system picker for every EXE.
 */
public class ProjectK11FileManagerActivity extends Activity {
    private static final int REQUEST_TREE = 4101;
    private static final String PREFS = "projectk11";
    private static final String KEY_TREE_URI = "projectk11_storage_tree_uri";

    private TextView title;
    private TextView path;
    private TextView status;
    private LinearLayout list;
    private Button accessButton;
    private Button upButton;
    private Button installButton;
    private Button closeButton;

    private Uri treeUri;
    private Uri currentUri;
    private Uri selectedUri;
    private String selectedName;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.projectk11_file_manager);
        title = findViewById(R.id.k11_files_title);
        path = findViewById(R.id.k11_files_path);
        status = findViewById(R.id.k11_files_status);
        list = findViewById(R.id.k11_files_list);
        accessButton = findViewById(R.id.k11_files_access);
        upButton = findViewById(R.id.k11_files_up);
        installButton = findViewById(R.id.k11_files_install);
        closeButton = findViewById(R.id.k11_files_close);

        accessButton.setOnClickListener(v -> requestStorageAccess());
        upButton.setOnClickListener(v -> goUp());
        installButton.setOnClickListener(v -> installSelected());
        closeButton.setOnClickListener(v -> finish());

        loadSavedAccess();
    }

    private void loadSavedAccess() {
        String saved = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_TREE_URI, null);
        if (saved == null || saved.isEmpty()) {
            showPermissionState();
            return;
        }
        try {
            treeUri = Uri.parse(saved);
            getContentResolver().takePersistableUriPermission(treeUri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            currentUri = treeUri;
            showBrowser();
        } catch (Throwable e) {
            clearSavedAccess();
            showPermissionState();
        }
    }

    private void requestStorageAccess() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION |
                Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        startActivityForResult(intent, REQUEST_TREE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_TREE || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            getContentResolver().takePersistableUriPermission(uri, flags);
            treeUri = uri;
            currentUri = uri;
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_TREE_URI, uri.toString()).apply();
            Toast.makeText(this, "Accès aux fichiers autorisé pour ProjetK11.", Toast.LENGTH_LONG).show();
            showBrowser();
        } catch (Throwable e) {
            Toast.makeText(this, "Autorisation impossible : " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void showPermissionState() {
        title.setText("📁 Gestionnaire de fichiers ProjetK11");
        path.setText("Accès non autorisé");
        status.setText("Pour installer un .EXE/.MSI directement depuis ProjetK11, autorise l'application à accéder au dossier contenant tes fichiers. L'autorisation est conservée pour les prochaines utilisations.");
        list.removeAllViews();
        accessButton.setVisibility(View.VISIBLE);
        upButton.setVisibility(View.GONE);
        installButton.setVisibility(View.GONE);
    }

    private void showBrowser() {
        accessButton.setVisibility(View.VISIBLE);
        upButton.setVisibility(View.VISIBLE);
        installButton.setVisibility(selectedUri == null ? View.GONE : View.VISIBLE);
        status.setText("Sélectionne un dossier pour l'ouvrir ou un .EXE/.MSI pour l'installer.");
        loadChildren(currentUri);
    }

    private void loadChildren(Uri parentUri) {
        list.removeAllViews();
        path.setText("📂 " + displayName(parentUri));
        selectedUri = null;
        selectedName = null;
        installButton.setVisibility(View.GONE);

        new Thread(() -> {
            ArrayList<Entry> entries = new ArrayList<>();
            Cursor cursor = null;
            try {
                String documentId = DocumentsContract.getDocumentId(parentUri);
                Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(parentUri, documentId);
                cursor = getContentResolver().query(childrenUri,
                        new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                                DocumentsContract.Document.COLUMN_MIME_TYPE},
                        null, null, null);
                if (cursor != null) {
                    while (cursor.moveToNext()) {
                        String id = cursor.getString(0);
                        String name = cursor.getString(1);
                        String mime = cursor.getString(2);
                        Uri child = DocumentsContract.buildDocumentUriUsingTree(parentUri, id);
                        entries.add(new Entry(child, name == null ? "Sans nom" : name, mime));
                    }
                }
            } catch (Throwable e) {
                runOnUiThread(() -> status.setText("❌ Impossible de lire ce dossier. Vérifie l'autorisation d'accès."));
            } finally {
                if (cursor != null) cursor.close();
            }
            Collections.sort(entries, Comparator.comparing((Entry e) -> !e.isDirectory()).thenComparing(e -> e.name.toLowerCase(Locale.US)));
            runOnUiThread(() -> renderEntries(entries));
        }).start();
    }

    private void renderEntries(ArrayList<Entry> entries) {
        list.removeAllViews();
        if (entries.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("Dossier vide");
            empty.setTextColor(0xFFBFC4CC);
            empty.setTextSize(17);
            empty.setPadding(20, 30, 20, 30);
            list.addView(empty);
            return;
        }
        for (Entry entry : entries) {
            Button row = new Button(this);
            row.setAllCaps(false);
            row.setGravity(android.view.Gravity.START | android.view.Gravity.CENTER_VERTICAL);
            row.setText((entry.isDirectory() ? "📁  " : iconFor(entry.name) + "  ") + entry.name);
            row.setTextSize(16);
            row.setMinHeight(56);
            row.setOnClickListener(v -> {
                if (entry.isDirectory()) {
                    currentUri = entry.uri;
                    loadChildren(currentUri);
                } else {
                    selectFile(entry);
                }
            });
            list.addView(row);
        }
    }

    private void selectFile(Entry entry) {
        selectedUri = entry.uri;
        selectedName = entry.name;
        path.setText("📄 " + entry.name);
        if (isInstaller(entry.name)) {
            status.setText("Installateur sélectionné. Appuie sur « Installer » pour choisir le conteneur Windows.");
            installButton.setVisibility(View.VISIBLE);
        } else {
            status.setText("Fichier sélectionné : " + entry.name + "\nSeuls les fichiers .EXE et .MSI peuvent être installés ici.");
            installButton.setVisibility(View.GONE);
        }
    }

    private void goUp() {
        if (currentUri == null || treeUri == null) return;
        if (currentUri.toString().equals(treeUri.toString())) return;
        String docId;
        String rootId;
        try {
            docId = DocumentsContract.getDocumentId(currentUri);
            rootId = DocumentsContract.getTreeDocumentId(treeUri);
            int slash = docId.lastIndexOf('/');
            if (slash <= 0 || docId.equals(rootId)) {
                currentUri = treeUri;
            } else {
                String parentId = docId.substring(0, slash);
                currentUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, parentId);
            }
            loadChildren(currentUri);
        } catch (Throwable e) {
            currentUri = treeUri;
            loadChildren(currentUri);
        }
    }

    private void installSelected() {
        if (selectedUri == null || !isInstaller(selectedName)) return;
        ContainerManager cm = new ContainerManager(this);
        ArrayList<Container> containers = cm.getContainers();
        if (containers.isEmpty()) {
            Toast.makeText(this, "Crée d'abord un conteneur Windows.", Toast.LENGTH_LONG).show();
            return;
        }
        String[] names = new String[containers.size()];
        for (int i = 0; i < containers.size(); i++) names[i] = containers.get(i).getName();
        new AlertDialog.Builder(this)
                .setTitle("Installer avec ProjetK11")
                .setMessage("Choisis le conteneur Windows pour « " + selectedName + " ».")
                .setItems(names, (dialog, which) -> copyAndLaunch(containers.get(which), selectedUri, selectedName))
                .setNegativeButton("Annuler", null)
                .show();
    }

    private void copyAndLaunch(Container container, Uri uri, String originalName) {
        new Thread(() -> {
            try {
                File downloads = new File(container.getUserDir(), "Downloads");
                if (!downloads.exists() && !downloads.mkdirs()) throw new java.io.IOException("Downloads");
                String safeName = originalName.replaceAll("[^a-zA-Z0-9._ -]", "_");
                File installer = new File(downloads, safeName);
                try (InputStream in = new BufferedInputStream(getContentResolver().openInputStream(uri));
                     java.io.OutputStream out = new BufferedOutputStream(new FileOutputStream(installer))) {
                    if (in == null) throw new java.io.IOException("Impossible de lire le fichier");
                    byte[] buffer = new byte[65536];
                    int n;
                    while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                }
                File desktop = new File(container.getUserDir(), "Desktop");
                if (!desktop.exists()) desktop.mkdirs();
                String base = safeName.replaceFirst("(?i)\\.(exe|msi)$", "");
                File shortcut = new File(desktop, base + ".desktop");
                String dosPath = WineUtils.unixToDOSPath(installer.getPath(), container);
                String content = "[Desktop Entry]\\n" +
                        "Name=" + base.replace("\\n", " ") + "\\n" +
                        "Exec=wine \\\"" + dosPath + "\\\"\\n" +
                        "Type=Application\\nTerminal=false\\nCategories=Game;Utility;\\n" +
                        "[Extra Data]\\nprojectk11Installer=true\\n";
                FileUtils.writeString(shortcut, content);
                runOnUiThread(() -> {
                    Toast.makeText(this, "Installateur copié dans le conteneur. Lancement…", Toast.LENGTH_LONG).show();
                    Intent launch = new Intent(this, XServerDisplayActivity.class);
                    launch.putExtra("container_id", container.id);
                    launch.putExtra("exec_path", installer.getPath());
                    startActivity(launch);
                });
            } catch (Throwable e) {
                runOnUiThread(() -> Toast.makeText(this, "Installation impossible : " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    private boolean isInstaller(String name) {
        String lower = name == null ? "" : name.toLowerCase(Locale.US);
        return lower.endsWith(".exe") || lower.endsWith(".msi");
    }

    private String iconFor(String name) {
        String n = name == null ? "" : name.toLowerCase(Locale.US);
        if (n.endsWith(".exe")) return "🧩";
        if (n.endsWith(".msi")) return "📦";
        if (n.endsWith(".zip") || n.endsWith(".7z") || n.endsWith(".rar")) return "🗜️";
        if (n.endsWith(".iso")) return "💿";
        return "📄";
    }

    private String displayName(Uri uri) {
        try {
            String id = DocumentsContract.getDocumentId(uri);
            if (id != null && id.contains(":")) return id.substring(id.indexOf(':') + 1);
            return id;
        } catch (Throwable ignored) { return "Stockage"; }
    }

    private void clearSavedAccess() {
        try {
            if (treeUri != null) getContentResolver().releasePersistableUriPermission(treeUri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        } catch (Throwable ignored) {}
        treeUri = null;
        currentUri = null;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(KEY_TREE_URI).apply();
    }

    private static final class Entry {
        final Uri uri;
        final String name;
        final String mime;
        Entry(Uri uri, String name, String mime) { this.uri = uri; this.name = name; this.mime = mime; }
        boolean isDirectory() { return DocumentsContract.Document.MIME_TYPE_DIR.equals(mime); }
    }
}
