package com.winlator.projectk11;

import android.app.ActivityManager;
import android.content.Context;
import android.os.StatFs;
import com.winlator.container.ContainerManager;

/** Lightweight diagnostic checks for the launcher/runtime. */
public final class DiagnosticsManager {
    private DiagnosticsManager() {}
    public static String run(Context c) {
        StringBuilder b = new StringBuilder();
        b.append("ProjetK11 Diagnostic\n\n");
        b.append("Runtime : ").append(ProjectK11Runtime.isReady(c) ? "OK" : "MANQUANT").append('\n');
        b.append("Architecture : ").append(android.os.Build.SUPPORTED_ABIS.length > 0 ? android.os.Build.SUPPORTED_ABIS[0] : "inconnue").append('\n');
        ActivityManager am = (ActivityManager)c.getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        if (am != null) { am.getMemoryInfo(mi); b.append("RAM disponible : ").append(fmt(mi.availMem)).append('\n'); }
        StatFs fs = new StatFs(c.getFilesDir().getAbsolutePath());
        b.append("Stockage libre : ").append(fmt(fs.getAvailableBytes())).append('\n');
        try { b.append("Conteneurs : ").append(new ContainerManager(c).getContainers().size()).append('\n'); } catch (Throwable e) { b.append("Conteneurs : erreur\n"); }
        b.append("Android : ").append(android.os.Build.VERSION.RELEASE).append('\n');
        return b.toString();
    }
    private static String fmt(long n) { return n >= 1073741824L ? String.format(java.util.Locale.US, "%.1f Go", n / 1073741824.0) : String.format(java.util.Locale.US, "%.0f Mo", n / 1048576.0); }
}
