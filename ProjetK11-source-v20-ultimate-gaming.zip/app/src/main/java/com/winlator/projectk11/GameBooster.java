package com.winlator.projectk11;

import android.content.Context;
import android.content.SharedPreferences;

/** Stores Game Booster preferences used by the launcher and game profiles. */
public final class GameBooster {
    private static final String PREF = "projectk11_booster_v1";
    private GameBooster() {}
    public static boolean enabled(Context c) { return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean("enabled", true); }
    public static boolean hud(Context c) { return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean("hud", false); }
    public static void set(Context c, boolean enabled, boolean hud) { c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putBoolean("enabled", enabled).putBoolean("hud", hud).apply(); }
}
