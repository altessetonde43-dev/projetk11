package com.winlator.projectk11;

import android.view.View;

/** Touch-friendly helpers for the desktop shell. */
public final class DesktopWindowManager {
    private DesktopWindowManager() {}
    public static void show(View v) { if (v != null) v.setVisibility(View.VISIBLE); }
    public static void hide(View v) { if (v != null) v.setVisibility(View.GONE); }
    public static void toggle(View v) { if (v != null) v.setVisibility(v.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE); }
}
