package com.winlator.projectk11;

import android.content.Context;
import android.content.SharedPreferences;
import com.winlator.container.Shortcut;

/** Persistent per-game profile metadata built on Winlator shortcut extras. */
public final class GameProfileManager {
    private GameProfileManager() {}
    private static final String PREF = "projectk11_game_profiles_v1";
    private static SharedPreferences prefs(Context c) { return c.getSharedPreferences(PREF, Context.MODE_PRIVATE); }

    public static void markLaunched(Context c, Shortcut s) {
        String key = key(s);
        prefs(c).edit().putLong(key + ".last", System.currentTimeMillis()).putInt(key + ".count", launches(c, s) + 1).apply();
    }
    public static int launches(Context c, Shortcut s) { return prefs(c).getInt(key(s) + ".count", 0); }
    public static long lastLaunch(Context c, Shortcut s) { return prefs(c).getLong(key(s) + ".last", 0L); }
    private static String key(Shortcut s) { return Integer.toHexString((s.container.id + "|" + s.file.getPath()).hashCode()); }
}
