package com.winlator.projectk11;

import android.content.Context;

import com.winlator.box64.Box64Preset;
import com.winlator.container.Container;
import com.winlator.container.ContainerManager;
import com.winlator.container.DXWrappers;
import com.winlator.container.GraphicsDrivers;
import com.winlator.core.GPUHelper;

import org.json.JSONObject;

import java.util.Locale;

/** ProjetK11 automatic first-run optimizer. */
public final class AutoConfig {
    private static final String PREF = "projectk11_autoconfig_v1";
    private AutoConfig() {}

    public static void apply(Context context) {
        final android.content.SharedPreferences p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        if (p.getBoolean("done", false)) return;
        new Thread(() -> {
            try {
                ContainerManager manager = new ContainerManager(context);
                if (manager.getContainers().isEmpty()) {
                    JSONObject data = new JSONObject();
                    data.put("name", "ProjetK11");
                    manager.createContainerAsync(data, c -> {
                        if (c != null) {
                            optimize(context, c);
                            p.edit().putBoolean("done", true).apply();
                        }
                    });
                } else {
                    for (Container c : manager.getContainers()) optimize(context, c);
                    p.edit().putBoolean("done", true).apply();
                }
            } catch (Throwable ignored) {
                // Never block the app if an optional optimization is unavailable.
            }
        }, "ProjetK11-AutoConfig").start();
    }

    public static void optimize(Context context, Container c) {
        boolean adreno = GPUHelper.getAdrenoModelId(context) > 0;
        c.setGraphicsDriver((adreno ? GraphicsDrivers.TURNIP : GraphicsDrivers.VORTEK) + "," + GraphicsDrivers.DEFAULT_OPENGL_DRIVER);
        c.setBox64Preset(Box64Preset.PERFORMANCE);
        c.setDXWrapper(DXWrappers.DXVK);

        String env = c.getEnvVars();
        env = put(env, "BOX64_DYNAREC_BIGBLOCK", "3");
        env = put(env, "BOX64_DYNAREC_STRONGMEM", "3");
        env = put(env, "MESA_VK_WSI_PRESENT_MODE", "mailbox");

        // Conservative cache/thread defaults: do not hard-code RAM allocation.
        env = put(env, "MESA_SHADER_CACHE_DISABLE", "false");
        env = put(env, "MESA_SHADER_CACHE_MAX_SIZE", "512MB");
        c.setEnvVars(env);
        c.putExtra("projectk11_auto", "1");
        c.saveData();
    }

    public static String detectGame(String exe) {
        String n = exe == null ? "" : exe.toLowerCase(Locale.US);
        if (n.contains("gta5") || n.contains("gtav")) return "gta";
        if (n.contains("fifa") || n.contains("efootball")) return "gamepad";
        if (n.contains("doom") || n.contains("quake") || n.contains("csgo") || n.contains("valorant")) return "fps";
        return "generic";
    }

    private static String put(String vars, String key, String value) {
        String[] parts = (vars == null ? "" : vars).trim().split("\\s+");
        StringBuilder out = new StringBuilder();
        boolean found = false;
        for (String part : parts) {
            if (part.isEmpty()) continue;
            if (part.startsWith(key + "=")) {
                if (!found) { out.append(key).append('=').append(value).append(' '); found = true; }
            } else out.append(part).append(' ');
        }
        if (!found) out.append(key).append('=').append(value);
        return out.toString().trim();
    }
}
