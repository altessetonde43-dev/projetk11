package com.winlator.projectk11;

import android.content.Context;

/** Centralized UI preference for future desktop themes. */
public final class ThemeManager {
    private ThemeManager() {}
    public static final String DARK = "dark";
    public static String get(Context c) { return c.getSharedPreferences("projectk11_ui", Context.MODE_PRIVATE).getString("theme", DARK); }
    public static void set(Context c, String theme) { c.getSharedPreferences("projectk11_ui", Context.MODE_PRIVATE).edit().putString("theme", theme).apply(); }
}
