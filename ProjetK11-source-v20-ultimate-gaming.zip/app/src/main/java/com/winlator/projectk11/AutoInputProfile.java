package com.winlator.projectk11;

import android.content.Context;

import com.winlator.inputcontrols.ControlsProfile;
import com.winlator.inputcontrols.InputControlsManager;

import java.util.Locale;

/** Chooses a compatible built-in touch profile when a shortcut has no explicit profile. */
public final class AutoInputProfile {
    private AutoInputProfile() {}

    public static ControlsProfile choose(Context context, String executable) {
        InputControlsManager manager = new InputControlsManager(context);
        String name = executable == null ? "" : executable.toLowerCase(Locale.ENGLISH);

        // Existing Winlator profiles are used so the input path stays native.
        String wanted;
        if (containsAny(name, "fifa", "efootball", "pes", "nba", "rocketleague")) {
            wanted = "Virtual Gamepad";
        }
        else if (containsAny(name, "gta", "gtav", "gta5", "rdr", "witcher", "eldenring")) {
            wanted = "Virtual Gamepad";
        }
        else if (containsAny(name, "doom", "quake", "csgo", "valorant", "cod", "counter-strike")) {
            wanted = "FPS";
        }
        else {
            wanted = "FPS";
        }

        for (ControlsProfile profile : manager.getProfiles(true)) {
            if (wanted.equalsIgnoreCase(profile.getName())) return profile;
        }
        return null;
    }

    private static boolean containsAny(String value, String... needles) {
        for (String needle : needles) if (value.contains(needle)) return true;
        return false;
    }
}
