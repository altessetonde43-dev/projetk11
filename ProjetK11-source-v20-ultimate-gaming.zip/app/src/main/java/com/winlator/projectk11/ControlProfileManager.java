package com.winlator.projectk11;

import com.winlator.container.Shortcut;

/** Per-game control-profile helper. */
public final class ControlProfileManager {
    private ControlProfileManager() {}
    public static void applyAuto(Shortcut s) {
        // Use the existing native AutoInputProfile chooser from the caller when needed.
        // This helper intentionally does not replace an explicitly selected profile.
        if (s.getExtra("controls_profile", "").isEmpty()) {
            s.putExtra("controls_profile", "FPS");
            s.saveData();
        }
    }
    public static String get(Shortcut s) { return s.getExtra("controls_profile", "Automatique"); }
}
