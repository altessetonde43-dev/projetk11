package com.winlator.projectk11;

import android.content.Context;
import com.winlator.box64.Box64Preset;
import com.winlator.container.Container;
import com.winlator.container.DXWrappers;
import com.winlator.container.GraphicsDrivers;
import com.winlator.container.Shortcut;
import com.winlator.core.GPUHelper;

/** Applies safe performance defaults without hard-coding RAM limits. */
public final class SmartOptimizer {
    private SmartOptimizer() {}
    public static void optimizeContainer(Context context, Container c) { AutoConfig.optimize(context, c); }
    public static void optimizeGame(Context context, Shortcut s) {
        Container c = s.container;
        AutoConfig.optimize(context, c);
        String type = AutoConfig.detectGame(s.path == null ? s.name : s.path);
        s.putExtra("projectk11_smart", "1");
        s.putExtra("box64Preset", Box64Preset.PERFORMANCE);
        s.putExtra("dxwrapper", DXWrappers.DXVK);
        s.putExtra("screenSize", s.getExtra("screenSize", c.getScreenSize()));
        s.putExtra("controls_profile", type.equals("fps") ? "FPS" : type.equals("gamepad") || type.equals("gta") ? "Virtual Gamepad" : "FPS");
        boolean adreno = GPUHelper.getAdrenoModelId(context) > 0;
        s.putExtra("graphicsDriver", (adreno ? GraphicsDrivers.TURNIP : GraphicsDrivers.VORTEK) + "," + GraphicsDrivers.DEFAULT_OPENGL_DRIVER);
        s.saveData();
    }
}
